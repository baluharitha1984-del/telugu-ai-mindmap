import { Project } from './types';

export const INITIAL_PROJECT: Project = {
  id: 'neon-clock',
  name: 'Retro Neon Clock',
  category: 'Interactive Visuals',
  html: `<!-- Retro Digital Glowing Neon Clock -->
<div class="clock-container">
  <div class="glow-orb"></div>
  <div class="glow-orb secondary"></div>
  
  <div class="glass-board">
    <div class="app-header">
      <span class="status-dot"></span>
      <span class="header-title">LIVE NEON CLOCK</span>
    </div>
    
    <div class="time-display">
      <span id="hours">00</span>
      <span class="colon">:</span>
      <span id="minutes">00</span>
      <span class="colon">:</span>
      <span id="seconds">00</span>
      <span id="ampm" class="ampm">AM</span>
    </div>
    
    <div class="date-display" id="date">Loading Today's Date...</div>
    
    <div class="controls-row">
      <button class="interactive-btn" onclick="toggleAnimation()">Toggle Neon Swirl</button>
      <button class="interactive-btn accent" onclick="changeTheme()">Switch Mood</button>
    </div>
  </div>
</div>`,
  css: `/* Custom Glassmorphic Styling for the Neon Clock */
:root {
  --neon-cyan: #00f0ff;
  --neon-pink: #ff007f;
  --neon-purple: #9d4edd;
  --bg-dark: #0a0e17;
  --glass-bg: rgba(15, 23, 42, 0.65);
}

body {
  margin: 0;
  padding: 0;
  background-color: var(--bg-dark);
  color: #f8fafc;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  overflow: hidden;
  transition: background 0.8s ease, color 0.5s ease;
}

/* Alternate light mood preset */
body.light-theme {
  --bg-dark: #f1f5f9;
  --glass-bg: rgba(255, 255, 255, 0.8);
  --neon-cyan: #0284c7;
  --neon-pink: #db2777;
  --neon-purple: #7c3aed;
  color: #0f172a;
}

.clock-container {
  position: relative;
  width: 100%;
  max-width: 480px;
  padding: 20px;
  box-sizing: border-box;
}

/* Floating background glow effects */
.glow-orb {
  position: absolute;
  width: 250px;
  height: 250px;
  border-radius: 50%;
  background: radial-gradient(circle, var(--neon-cyan) 0%, transparent 70%);
  top: -40px;
  left: -40px;
  opacity: 0.35;
  filter: blur(40px);
  animation: floatOrb 12s infinite alternate ease-in-out;
}

.glow-orb.secondary {
  background: radial-gradient(circle, var(--neon-pink) 0%, transparent 70%);
  bottom: -40px;
  right: -40px;
  top: auto;
  left: auto;
  opacity: 0.3;
  animation: floatOrb 15s infinite alternate-reverse ease-in-out;
}

@keyframes floatOrb {
  0% { transform: translate(0, 0) scale(1); }
  100% { transform: translate(30px, 40px) scale(1.15); }
}

/* Glassmorphic card frame */
.glass-board {
  position: relative;
  background: var(--glass-bg);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 24px;
  padding: 35px 25px;
  backdrop-filter: blur(16px);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
  text-align: center;
  transition: all 0.3s ease;
}

body.light-theme .glass-board {
  border: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
}

.app-header {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  margin-bottom: 25px;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: var(--neon-cyan);
  box-shadow: 0 0 8px var(--neon-cyan);
  animation: pulse 1.5s infinite;
}

.header-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 2px;
  color: var(--neon-cyan);
  transition: color 0.3s ease;
}

/* Clock numbers styles */
.time-display {
  font-size: 52px;
  font-weight: 800;
  letter-spacing: -1px;
  font-family: 'JetBrains Mono', 'Fira Code', monospace;
  margin-bottom: 12px;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 2px;
  text-shadow: 0 0 20px rgba(0, 240, 255, 0.15);
}

.colon {
  color: var(--neon-purple);
  animation: pulse 1s infinite;
}

.ampm {
  font-size: 16px;
  font-weight: 700;
  color: var(--neon-pink);
  margin-left: 8px;
  align-self: flex-end;
  padding-bottom: 8px;
}

.date-display {
  font-size: 14px;
  font-weight: 500;
  opacity: 0.65;
  letter-spacing: 0.5px;
  margin-bottom: 30px;
}

/* Custom interactive inputs */
.controls-row {
  display: flex;
  gap: 12px;
  justify-content: center;
}

.interactive-btn {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: inherit;
  padding: 10px 18px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.interactive-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  transform: translateY(-2px);
  border-color: var(--neon-cyan);
}

.interactive-btn.accent {
  background: var(--neon-purple);
  border-color: transparent;
  color: white;
}

.interactive-btn.accent:hover {
  background: var(--neon-pink);
  box-shadow: 0 0 15px rgba(255, 0, 127, 0.4);
}

body.light-theme .interactive-btn {
  background: rgba(0, 0, 0, 0.03);
  border: 1px solid rgba(0, 0, 0, 0.08);
}

body.light-theme .interactive-btn:hover {
  background: rgba(0, 0, 0, 0.07);
}

@keyframes pulse {
  0%, 100% { opacity: 0.3; }
  50% { opacity: 1; }
}`,
  javascript: `// Interactive Neon Clock Mechanics

function updateClock() {
  const now = new Date();
  
  // Hours
  let hours = now.getHours();
  const ampmStr = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // convert 0 to 12
  const hoursStr = String(hours).padStart(2, '0');
  
  // Minutes / Seconds
  const minutesStr = String(now.getMinutes()).padStart(2, '0');
  const secondsStr = String(now.getSeconds()).padStart(2, '0');
  
  // Update elements
  document.getElementById('hours').innerText = hoursStr;
  document.getElementById('minutes').innerText = minutesStr;
  document.getElementById('seconds').innerText = secondsStr;
  document.getElementById('ampm').innerText = ampmStr;
  
  // Format Date beautifully
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const dateStr = now.toLocaleDateString(undefined, options);
  document.getElementById('date').innerText = dateStr;
}

// Run immediately & set interval
updateClock();
setInterval(updateClock, 1000);

// Interaction functions
let swirlPaused = false;
function toggleAnimation() {
  swirlPaused = !swirlPaused;
  const orbs = document.querySelectorAll('.glow-orb');
  orbs.forEach(orb => {
    orb.style.animationPlayState = swirlPaused ? 'paused' : 'running';
  });
  
  const title = document.querySelector('.header-title');
  title.innerText = swirlPaused ? "SWIRL PAUSED" : "LIVE NEON CLOCK";
}

function changeTheme() {
  document.body.classList.toggle('light-theme');
  const isLight = document.body.classList.contains('light-theme');
  console.log("Visual atmosphere set to: " + (isLight ? "Daylight Mode" : "Cosmic Dark Mode"));
}`,
};

export const PRESET_PROJECTS: Project[] = [
  INITIAL_PROJECT,
  {
    id: 'bouncing-balls',
    name: 'Physics Canvas Gravity Box',
    category: 'Games & Fun',
    html: `<!-- Gravity Particle Playground -->
<div class="canvas-wrapper">
  <div class="hud">
    <div class="hud-item font-mono">Balls Active: <span id="ball-count">0</span></div>
    <div class="hud-item font-mono">Gravity: <span id="gravity-status">ON (0.4)</span></div>
  </div>
  
  <canvas id="gravityCanvas"></canvas>
  
  <div class="controls-panel">
    <button class="action-btn" onclick="addBalls(10)">+10 Particles</button>
    <button class="action-btn" onclick="toggleGravity()">Toggle Gravity</button>
    <button class="action-btn danger-btn" onclick="clearCanvas()">Clear Sandbox</button>
  </div>
</div>`,
    css: `/* Canvas Grid styling */
body {
  margin: 0;
  padding: 0;
  background: #0f172a;
  color: #e2e8f0;
  font-family: system-ui, -apple-system, sans-serif;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.canvas-wrapper {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

#gravityCanvas {
  flex-grow: 1;
  background: radial-gradient(circle at center, #1e293b 0%, #0f172a 100%);
  cursor: crosshair;
}

/* Information Layout overlay */
.hud {
  position: absolute;
  top: 15px;
  left: 15px;
  display: flex;
  gap: 15px;
  pointer-events: none;
}

.hud-item {
  background: rgba(15, 23, 42, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.08);
  font-size: 11px;
  font-weight: 700;
  padding: 8px 16px;
  border-radius: 8px;
  text-transform: uppercase;
  letter-spacing: 1px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.25);
}

/* Control footer bar */
.controls-panel {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 10px;
  background: rgba(15, 23, 42, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.1);
  padding: 10px 16px;
  border-radius: 16px;
  backdrop-filter: blur(10px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.4);
  max-width: 90vw;
}

.action-btn {
  background: #2563eb;
  color: white;
  border: none;
  font-size: 11px;
  font-weight: 700;
  padding: 10px 14px;
  border-radius: 8px;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s ease;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.action-btn:hover {
  background: #3b82f6;
  transform: translateY(-1px);
}

.action-btn.danger-btn {
  background: rgba(239, 68, 68, 0.2);
  border: 1px solid rgba(239, 68, 68, 0.4);
  color: #fca5a5;
}

.action-btn.danger-btn:hover {
  background: rgba(239, 68, 68, 0.4);
}

@media (max-width: 480px) {
  .controls-panel {
    flex-direction: row;
    padding: 8px;
    gap: 6px;
  }
  .action-btn {
    padding: 8px 10px;
    font-size: 10px;
  }
}`,
    javascript: `// Interactive Physics Sandbox Engine
const canvas = document.getElementById('gravityCanvas');
const ctx = canvas.getContext('2d');

let balls = [];
let gravity = 0.4;
let friction = 0.98;
let useGravity = true;

// Set correct size relative to bounds
function resize() {
  canvas.width = canvas.parentElement.clientWidth;
  canvas.height = canvas.parentElement.clientHeight;
}
window.addEventListener('resize', resize);
resize();

class Ball {
  constructor(x, y) {
    this.x = x || Math.random() * canvas.width;
    this.y = y || Math.random() * (canvas.height / 2);
    this.radius = Math.random() * 15 + 8;
    this.vx = (Math.random() - 0.5) * 8;
    this.vy = (Math.random() - 0.5) * 8;
    
    // Choose beautiful color
    const colors = ['#f43f5e', '#3b82f6', '#10b981', '#a855f7', '#f59e0b', '#06b6d4', '#ec4899'];
    this.color = colors[Math.floor(Math.random() * colors.length)];
  }
  
  update() {
    if (useGravity) {
      this.vy += gravity;
    }
    
    this.x += this.vx;
    this.y += this.vy;
    
    // Wall bounce
    if (this.x + this.radius > canvas.width) {
      this.x = canvas.width - this.radius;
      this.vx = -this.vx * friction;
    } else if (this.x - this.radius < 0) {
      this.x = this.radius;
      this.vx = -this.vx * friction;
    }
    
    // Floor & ceiling bounce
    if (this.y + this.radius > canvas.height) {
      this.y = canvas.height - this.radius;
      this.vy = -this.vy * friction;
      this.vx *= friction; // Apply extra roll friction on floor
    } else if (this.y - this.radius < 0) {
      this.y = this.radius;
      this.vy = -this.vy * friction;
    }
  }
  
  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.shadowBlur = 10;
    ctx.shadowColor = this.color;
    ctx.fill();
    ctx.closePath();
    ctx.shadowBlur = 0; // reset
  }
}

// Particle managers
function addBalls(count, x, y) {
  for (let i = 0; i < count; i++) {
    balls.push(new Ball(x, y));
  }
  updateHUD();
}

function toggleGravity() {
  useGravity = !useGravity;
  document.getElementById('gravity-status').innerText = useGravity ? "ON (0.4)" : "OFF (Zero-G)";
  // Give sudden slight thrust to prevent settling
  if (!useGravity) {
    balls.forEach(b => {
      b.vx += (Math.random() - 0.5) * 5;
      b.vy += (Math.random() - 0.5) * 5;
    });
  }
}

function clearCanvas() {
  balls = [];
  updateHUD();
}

function updateHUD() {
  document.getElementById('ball-count').innerText = balls.length;
}

// Spawn on interactive cursor tap
canvas.addEventListener('mousedown', (e) => {
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  addBalls(5, x, y);
});

canvas.addEventListener('touchstart', (e) => {
  if (e.touches.length > 0) {
    const rect = canvas.getBoundingClientRect();
    const x = e.touches[0].clientX - rect.left;
    const y = e.touches[0].clientY - rect.top;
    addBalls(3, x, y);
  }
}, {passive: true});

// Animation Loop
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  balls.forEach(ball => {
    ball.update();
    ball.draw();
  });
  
  requestAnimationFrame(animate);
}

// Start with standard particles
addBalls(25);
animate();`,
  },
  {
    id: 'cool-color-generator',
    name: 'Interactive Palette Architect',
    category: 'Utility Tools',
    html: `<!-- Color Architect Playground -->
<div class="app-dashboard">
  <div class="dashboard-head">
    <h2>PALETTE GENERATOR</h2>
    <p>Generate matching warm palette swatches. Tap to copy HEX codes.</p>
  </div>
  
  <div class="palette-swatch-ring" id="palette-grid">
    <!-- Rendered dynamically -->
  </div>
  
  <div class="foot-bar">
    <button class="roll-btn" onclick="generateNewPalette()">Shuffle Colors</button>
    <div id="toast" class="toast-popup">Copied code!</div>
  </div>
</div>`,
    css: `/* Color Generator layout rules */
body {
  margin: 0;
  padding: 0;
  background: #020617;
  color: #f8fafc;
  font-family: system-ui, -apple-system, sans-serif;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  box-sizing: border-box;
}

.app-dashboard {
  width: 90%;
  max-width: 550px;
  padding: 24px;
  background: #0b1329;
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: 20px;
  box-shadow: 0 10px 40px rgba(0,0,0,0.5);
  text-align: center;
}

.dashboard-head h2 {
  font-size: 20px;
  font-weight: 800;
  letter-spacing: 2px;
  color: #22d3ee;
  margin: 0 0 4px 0;
}

.dashboard-head p {
  font-size: 11px;
  color: #94a3b8;
  margin: 0 0 24px 0;
}

.palette-swatch-ring {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 12px;
  min-height: 140px;
  margin-bottom: 24px;
}

.swatch-card {
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,0.05);
  cursor: pointer;
  transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.swatch-card:hover {
  transform: translateY(-8px) scale(1.05);
}

.swatch-color {
  flex-grow: 1;
  min-height: 100px;
  transition: background 0.4s ease;
}

.swatch-hex {
  font-size: 10px;
  font-weight: 700;
  font-family: monospace;
  padding: 10px 2px;
  background: rgba(0,0,0,0.3);
  letter-spacing: 0.5px;
}

.foot-bar {
  position: relative;
}

.roll-btn {
  background: linear-gradient(135deg, #06b6d4, #3b82f6);
  border: none;
  color: white;
  padding: 12px 30px;
  font-size: 12px;
  font-weight: 700;
  border-radius: 12px;
  cursor: pointer;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
  transition: all 0.2s ease;
}

.roll-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5);
}

.toast-popup {
  position: absolute;
  bottom: -45px;
  left: 50%;
  transform: translateX(-50%) translateY(10px);
  background: #10b981;
  color: white;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 16px;
  border-radius: 20px;
  opacity: 0;
  pointer-events: none;
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.toast-popup.active {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}

@media(max-width: 500px) {
  .palette-swatch-ring {
    grid-template-columns: repeat(5, 1fr);
    gap: 6px;
  }
  .swatch-hex {
    font-size: 8px;
    padding: 6px 1px;
  }
}`,
    javascript: `// Beautiful Color Palette Sandbox Mechanics

const colorsGrid = document.getElementById('palette-grid');

function generateNewPalette() {
  colorsGrid.innerHTML = '';
  
  // Choose random starting base hue from beautiful spectrum
  const baseHue = Math.floor(Math.random() * 360);
  
  for (let i = 0; i < 5; i++) {
    // Generate beautiful harmonious colors using HSL distribution
    const hue = (baseHue + (i * 35)) % 360;
    const saturation = 70 + Math.floor(Math.random() * 20); // 70-90%
    const lightness = 45 + Math.floor(Math.random() * 25);  // 45-70%
    
    const hex = hslToHex(hue, saturation, lightness);
    createSwatch(hex);
  }
}

function createSwatch(hex) {
  const card = document.createElement('div');
  card.className = 'swatch-card';
  card.onclick = () => copyToClipboard(hex);
  
  const colorArea = document.createElement('div');
  colorArea.className = 'swatch-color';
  colorArea.style.backgroundColor = hex;
  
  const hexLabel = document.createElement('div');
  hexLabel.className = 'swatch-hex';
  hexLabel.innerText = hex.toUpperCase();
  
  card.appendChild(colorArea);
  card.appendChild(hexLabel);
  colorsGrid.appendChild(card);
}

// Convert HSL to Hex color codes safely
function hslToHex(h, s, l) {
  l /= 100;
  const a = s * Math.min(l, 1 - l) / 100;
  const f = n => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return \`#\${f(0)}\${f(8)}\${f(4)}\`;
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text.toUpperCase()).then(() => {
    const toast = document.getElementById('toast');
    toast.innerText = "COPIED HEX: " + text.toUpperCase();
    toast.classList.add('active');
    
    setTimeout(() => {
      toast.classList.remove('active');
    }, 1800);
  });
}

// Init automatically
generateNewPalette();`,
  },
  {
    id: 'snake-game',
    name: 'Retro Neon Snake Adventure',
    category: 'Games & Fun',
    html: `<!-- Retro Neon Snake -->
<div class="arcade-cabinet">
  <div class="cabinet-header">
    <div class="neon-title font-mono font-bold">NEON SNAKE</div>
    <div class="scores-panel font-mono text-xs">
      <div>SCORE: <span id="current-score" class="text-fuchsia-400 font-bold">0</span></div>
      <div>HIGH: <span id="high-score" class="text-emerald-400">0</span></div>
    </div>
  </div>

  <div class="canvas-container relative w-full bg-black border-2 border-purple-900 rounded-xl overflow-hidden aspect-square">
    <canvas id="gameCanvas" width="400" height="400" class="block w-full h-full"></canvas>
    <div id="game-overlay" class="absolute inset-0 bg-black/90 flex flex-col justify-center items-center gap-4 transition-all">
      <div id="overlay-text" class="text-cyan-400 font-mono font-bold text-lg tracking-wide text-center">PRESS PLAY TO START</div>
      <button class="play-btn font-mono font-bold text-xs bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-2.5 rounded-xl shadow-[0_4px_15px_rgba(168,85,247,0.4)] hover:scale-105 transition-all cursor-pointer" id="btn-start" onclick="startGame()">PLAY GAME</button>
    </div>
  </div>

  <div class="mobile-directions-pad flex flex-col items-center gap-1 mt-2">
    <div class="pad-row flex gap-1">
      <button class="pad-btn cursor-pointer w-12 h-10 bg-indigo-950 border border-indigo-800 text-indigo-300 rounded-lg flex items-center justify-center font-bold active:scale-95 transition-all" onclick="changeDirection('UP')">▲</button>
    </div>
    <div class="pad-row flex gap-1 items-center">
      <button class="pad-btn cursor-pointer w-12 h-10 bg-indigo-950 border border-indigo-800 text-indigo-300 rounded-lg flex items-center justify-center font-bold active:scale-95 transition-all" onclick="changeDirection('LEFT')">◀</button>
      <div class="pad-center w-12 h-10"></div>
      <button class="pad-btn cursor-pointer w-12 h-10 bg-indigo-950 border border-indigo-800 text-indigo-300 rounded-lg flex items-center justify-center font-bold active:scale-95 transition-all" onclick="changeDirection('RIGHT')">▶</button>
    </div>
    <div class="pad-row flex gap-1">
      <button class="pad-btn cursor-pointer w-12 h-10 bg-indigo-950 border border-indigo-800 text-indigo-300 rounded-lg flex items-center justify-center font-bold active:scale-95 transition-all" onclick="changeDirection('DOWN')">▼</button>
    </div>
  </div>
</div>`,
    css: `/* Retro Arcade Styling */
body {
  margin: 0;
  padding: 0;
  background-color: #03000a;
  color: #fff;
  font-family: 'Inter', system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.arcade-cabinet {
  background: #090314;
  border: 3px solid #3b0764;
  border-radius: 20px;
  padding: 20px;
  box-shadow: 0 0 30px rgba(168, 85, 247, 0.3);
  max-width: 440px;
  width: 90%;
  display: flex;
  flex-direction: column;
  gap: 15px;
}`,
    javascript: `// Retro Snake Interaction Code

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const gridCount = 20;
const gridSize = canvas.width / gridCount;

let snake = [{x: 10, y: 10}];
let food = {x: 15, y: 15};
let dx = 1;
let dy = 0;
let score = 0;
let highScore = localStorage.getItem('snake_high_score') || 0;
let gameInterval = null;
let gameSpeed = 110;
let isGameActive = false;

document.getElementById('high-score').innerText = highScore;

function startGame() {
  snake = [
    {x: 10, y: 10},
    {x: 9, y: 10},
    {x: 8, y: 10}
  ];
  dx = 1;
  dy = 0;
  score = 0;
  document.getElementById('current-score').innerText = score;
  document.getElementById('game-overlay').style.display = 'none';
  
  generateFood();
  if (gameInterval) clearInterval(gameInterval);
  isGameActive = true;
  gameInterval = setInterval(gameStep, gameSpeed);
  console.log("Snake Game Started!");
}

function generateFood() {
  food.x = Math.floor(Math.random() * gridCount);
  food.y = Math.floor(Math.random() * gridCount);
  
  // Make sure food is not on snake
  for (let part of snake) {
    if (part.x === food.x && part.y === food.y) {
      generateFood();
      break;
    }
  }
}

function gameStep() {
  // Move snake
  const head = {x: snake[0].x + dx, y: snake[0].y + dy};
  
  // Wall collision check
  if (head.x < 0 || head.x >= gridCount || head.y < 0 || head.y >= gridCount) {
    gameOver();
    return;
  }
  
  // Self collision check
  for (let part of snake) {
    if (part.x === head.x && part.y === head.y) {
      gameOver();
      return;
    }
  }
  
  snake.unshift(head);
  
  // Food dynamic eating
  if (head.x === food.x && head.y === food.y) {
    score += 10;
    document.getElementById('current-score').innerText = score;
    generateFood();
  } else {
    snake.pop();
  }
  
  draw();
}

function draw() {
  // Clear canvas
  ctx.fillStyle = '#05010b';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Grid Lines
  ctx.strokeStyle = '#120524';
  ctx.lineWidth = 0.5;
  for (let i = 0; i < gridCount; i++) {
    ctx.beginPath();
    ctx.moveTo(i * gridSize, 0);
    ctx.lineTo(i * gridSize, canvas.height);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(0, i * gridSize);
    ctx.lineTo(canvas.width, i * gridSize);
    ctx.stroke();
  }
  
  // Draw Snake
  snake.forEach((part, index) => {
    ctx.fillStyle = index === 0 ? '#d946ef' : '#a855f7';
    ctx.shadowBlur = index === 0 ? 8 : 4;
    ctx.shadowColor = '#d946ef';
    ctx.fillRect(part.x * gridSize + 1, part.y * gridSize + 1, gridSize - 2, gridSize - 2);
  });
  
  // Draw Food
  ctx.fillStyle = '#10b981';
  ctx.shadowBlur = 12;
  ctx.shadowColor = '#10b981';
  ctx.beginPath();
  ctx.arc(food.x * gridSize + gridSize/2, food.y * gridSize + gridSize/2, gridSize/3, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.shadowBlur = 0; // reset
}

function changeDirection(dir) {
  if (!isGameActive) return;
  if (dir === 'UP' && dy !== 1) { dx = 0; dy = -1; }
  if (dir === 'DOWN' && dy !== -1) { dx = 0; dy = 1; }
  if (dir === 'LEFT' && dx !== 1) { dx = -1; dy = 0; }
  if (dir === 'RIGHT' && dx !== -1) { dx = 1; dy = 0; }
}

// Arrow Keys support
window.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowUp') changeDirection('UP');
  if (e.key === 'ArrowDown') changeDirection('DOWN');
  if (e.key === 'ArrowLeft') changeDirection('LEFT');
  if (e.key === 'ArrowRight') changeDirection('RIGHT');
});

function gameOver() {
  clearInterval(gameInterval);
  isGameActive = false;
  
  console.log("Game Over! Score: " + score);
  if (score > highScore) {
    highScore = score;
    localStorage.setItem('snake_high_score', highScore);
    document.getElementById('high-score').innerText = highScore;
  }
  
  document.getElementById('overlay-text').innerText = 'GAME OVER\\nSCORE: ' + score;
  document.getElementById('btn-start').innerText = 'RESTART';
  document.getElementById('game-overlay').style.display = 'flex';
}

// Init draw
draw();`,
  },
  {
    id: 'pomodoro-timer',
    name: 'Pomodoro Focus Soundscape',
    category: 'Productivity Apps',
    html: `<!-- Pomodoro Focus Planner -->
<div class="pomodoro-app">
  <div class="header">
    <div class="brand">FocusFlow</div>
    <div class="badge font-mono" id="focus-streak">Streak: 0</div>
  </div>

  <div class="circular-timer">
    <svg class="progress-svg" viewBox="0 0 200 200">
      <circle class="bg-circle" cx="100" cy="100" r="85"></circle>
      <circle class="progress-bar" id="progress-indicator" cx="100" cy="100" r="85"></circle>
    </svg>
    <div class="timer-center">
      <span id="timer-label" class="timer-digits font-mono">25:00</span>
      <span id="timer-state" class="timer-state">FOCUS</span>
    </div>
  </div>

  <div class="controls">
    <button class="primary-btn shrink-0 cursor-pointer" id="btn-toggle-timer" onclick="toggleTimer()">START</button>
    <button class="secondary-btn shrink-0 cursor-pointer" onclick="resetTimer()">RESET</button>
  </div>

  <div class="ambient-sounds">
    <div class="sound-title font-mono">BG AUDIO SIMULATOR</div>
    <div class="sound-selectors">
      <button class="sound-btn active cursor-pointer" id="sound-silent" onclick="setSound('silent')">None</button>
      <button class="sound-btn cursor-pointer" id="sound-rain" onclick="setSound('rain')">🌧️ Rain</button>
      <button class="sound-btn cursor-pointer" id="sound-waves" onclick="setSound('waves')">🌊 Ocean</button>
    </div>
  </div>
</div>`,
    css: `/* Pomodoro styled layout */
body {
  margin: 0;
  padding: 0;
  background-color: #0b111e;
  color: #fff;
  font-family: system-ui, -apple-system, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.pomodoro-app {
  background: #111827;
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 24px;
  padding: 30px;
  max-width: 360px;
  width: 90%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.brand {
  font-size: 18px;
  font-weight: 800;
  color: #6366f1;
}

.badge {
  font-size: 10px;
  background: #1e1b4b;
  color: #818cf8;
  padding: 4px 10px;
  border-radius: 99px;
  font-weight: bold;
}

.circular-timer {
  position: relative;
  width: 200px;
  height: 200px;
}

.progress-svg {
  transform: rotate(-90deg);
  width: 100%;
  height: 100%;
}

.bg-circle {
  fill: none;
  stroke: #1f2937;
  stroke-width: 8px;
}

.progress-bar {
  fill: none;
  stroke: #4f46e5;
  stroke-width: 8px;
  stroke-dasharray: 534;
  stroke-dashoffset: 0;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.3s ease;
}

.timer-center {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.timer-digits {
  font-size: 36px;
  font-weight: bold;
  letter-spacing: -1px;
}

.timer-state {
  font-size: 11px;
  letter-spacing: 2.5px;
  color: #94a3b8;
  font-weight: 700;
  margin-top: 2px;
}

.controls {
  display: flex;
  gap: 12px;
  width: 100%;
}

.primary-btn {
  flex: 2;
  background: #4f46e5;
  color: #fff;
  border: none;
  font-family: inherit;
  font-size: 13px;
  font-weight: bold;
  padding: 12px;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
  letter-spacing: 1px;
}

.primary-btn:hover {
  background: #6366f1;
}

.secondary-btn {
  flex: 1;
  background: #1f2937;
  color: #f3f4f6;
  border: 1px solid #374151;
  font-family: inherit;
  font-size: 13px;
  font-weight: bold;
  padding: 12px;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.secondary-btn:hover {
  background: #374151;
  color: #fff;
}

.ambient-sounds {
  width: 100%;
  text-align: center;
}

.sound-title {
  font-size: 10px;
  color: #6b7280;
  letter-spacing: 1.5px;
  margin-bottom: 10px;
}

.sound-selectors {
  display: flex;
  gap: 8px;
  justify-content: center;
}

.sound-btn {
  background: #1f2937;
  border: 1px solid #374151;
  color: #9ca3af;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.sound-btn:hover {
  color: #fff;
  border-color: #4b5563;
}

.sound-btn.active {
  background: #312e81;
  color: #a5b4fc;
  border-color: #6366f1;
}

@keyframes flash {
  50% { opacity: 0.5; }
}
.timer-center.flashing {
  animation: flash 1s infinite;
}
`,
    javascript: `// Interactive Focus Timer Engine

let initialMinutes = 25;
let totalSeconds = initialMinutes * 60;
let timeRemaining = totalSeconds;
let isRunning = false;
let timerMode = 'FOCUS'; // or 'BREAK'
let intervalId = null;
let currentStreak = 0;

const fullStrokeLength = 534; // match circle dasharray

function updateUI() {
  const mins = Math.floor(timeRemaining / 60);
  const secs = timeRemaining % 60;
  document.getElementById('timer-label').innerText = 
    String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
  
  // Progress circular offset
  const ratio = timeRemaining / totalSeconds;
  const offset = fullStrokeLength * (1 - ratio);
  document.getElementById('progress-indicator').style.strokeDashoffset = offset;
}

function toggleTimer() {
  const btn = document.getElementById('btn-toggle-timer');
  if (isRunning) {
    clearInterval(intervalId);
    isRunning = false;
    btn.innerText = 'START';
    btn.style.background = '#4f46e5';
    console.log("Timer focused paused.");
  } else {
    isRunning = true;
    btn.innerText = 'PAUSE';
    btn.style.background = '#e11d48';
    console.log("Timer focused started.");
    intervalId = setInterval(tick, 1000);
  }
}

function tick() {
  if (timeRemaining <= 0) {
    clearInterval(intervalId);
    isRunning = false;
    document.getElementById('btn-toggle-timer').innerText = 'START';
    document.getElementById('btn-toggle-timer').style.background = '#4f46e5';
    
    if (timerMode === 'FOCUS') {
      console.log("COMPLETED focus block! Time for a short rest.");
      currentStreak += 1;
      document.getElementById('focus-streak').innerText = 'Streak: ' + currentStreak;
      triggerAlarm();
      
      // Auto switch to short break
      timerMode = 'BREAK';
      initialMinutes = 5;
      totalSeconds = initialMinutes * 60;
      timeRemaining = totalSeconds;
      document.getElementById('timer-state').innerText = 'BREAK';
      document.getElementById('timer-state').style.color = '#10b981';
      document.getElementById('progress-indicator').style.stroke = '#10b981';
    } else {
      console.log("Break finished! Let's get back to work.");
      triggerAlarm();
      
      timerMode = 'FOCUS';
      initialMinutes = 25;
      totalSeconds = initialMinutes * 60;
      timeRemaining = totalSeconds;
      document.getElementById('timer-state').innerText = 'FOCUS';
      document.getElementById('timer-state').style.color = '#94a3b8';
      document.getElementById('progress-indicator').style.stroke = '#4f46e5';
    }
    
    updateUI();
    return;
  }
  
  timeRemaining -= 1;
  updateUI();
}

function resetTimer() {
  clearInterval(intervalId);
  isRunning = false;
  document.getElementById('btn-toggle-timer').innerText = 'START';
  document.getElementById('btn-toggle-timer').style.background = '#4f46e5';
  
  timerMode = 'FOCUS';
  initialMinutes = 25;
  totalSeconds = initialMinutes * 60;
  timeRemaining = totalSeconds;
  document.getElementById('timer-state').innerText = 'FOCUS';
  document.getElementById('timer-state').style.color = '#94a3b8';
  document.getElementById('progress-indicator').style.stroke = '#4f46e5';
  updateUI();
  console.log("Timer Reset.");
}

function triggerAlarm() {
  // Flash circular timer center
  const center = document.querySelector('.timer-center');
  center.classList.add('flashing');
  setTimeout(() => center.classList.remove('flashing'), 5000);
}

function setSound(type) {
  document.querySelectorAll('.sound-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('sound-' + type).classList.add('active');
  console.log("Ambience Sound Simulator set to: " + type.toUpperCase());
}

// Initial draw progress
updateUI();`,
  }
];
