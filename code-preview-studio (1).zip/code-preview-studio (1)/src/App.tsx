import React, { useState, useEffect, useRef } from 'react';
import JSZip from 'jszip';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  RotateCcw, 
  Trash2, 
  Save, 
  FolderOpen, 
  Moon, 
  Sun, 
  Monitor, 
  Tablet, 
  Smartphone, 
  Laptop,
  Sparkles, 
  Copy, 
  Download, 
  Code, 
  Check, 
  ExternalLink, 
  RefreshCw, 
  Palette,
  Github, 
  X, 
  HelpCircle, 
  Plus, 
  Flame, 
  Info,
  ChevronDown,
  Clock,
  History,
  ChevronRight,
  PlusCircle,
  FileCode,
  AlertCircle,
  Maximize2,
  Minimize2,
  Archive,
  Mic,
  Wand2,
  Cpu,
  Globe,
  Languages,
  Home,
  Settings,
  Menu,
  Layers
} from 'lucide-react';
import { Project, EditorTab, ProjectVersion, VersionType } from './types';
import { PRESET_PROJECTS, INITIAL_PROJECT } from './presets';
import { TEMPLATE_CALCULATOR, TEMPLATE_NOTES, TEMPLATE_QUIZ, TEMPLATE_TODO } from './customTemplates';


const BLANK_TEMPLATE = {
  html: `<!-- Starter HTML Blueprint -->
<div class="card-workspace shadow-xl">
  <div class="header-band">
    <span class="pulse-indicator"></span>
    <h3>HELLO DIRECTIVE</h3>
  </div>
  <div class="card-interior text-center">
    <h2>Welcome to your clean space!</h2>
    <p>Use modern style guidelines, Tailwind utilities and Javascript to write beautiful previews.</p>
    <button class="action-btn" onclick="sayHello()">Trigger Interactive Log</button>
  </div>
</div>`,
  css: `/* Workspace typography and core element presets */
body {
  margin: 0;
  padding: 0;
  background-color: #0b0f19;
  color: #f1f5f9;
  font-family: "Space Grotesk", 'Inter', system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.card-workspace {
  background: rgba(17, 24, 39, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 20px;
  max-width: 440px;
  width: 90%;
  padding: 24px;
  backdrop-filter: blur(12px);
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
}

.header-band {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 20px;
  letter-spacing: 1.5px;
  color: #818cf8;
  font-size: 11px;
  font-weight: 800;
}

.pulse-indicator {
  width: 8px;
  height: 8px;
  background: #4f46e5;
  border-radius: 50%;
  box-shadow: 0 0 10px #4f46e5;
}

h2 {
  font-size: 20px;
  font-weight: 700;
  color: #fff;
  margin-top: 0;
}

p {
  font-size: 13px;
  color: #94a3b8;
  line-height: 1.6;
  margin-bottom: 24px;
}

.action-btn {
  background: #4f46e5;
  color: #fff;
  border: none;
  font-size: 12px;
  font-weight: 7500;
  padding: 10px 18px;
  border-radius: 10px;
  cursor: pointer;
  box-shadow: 0 4px 14px rgba(79, 70, 229, 0.3);
  transition: all 0.2s ease;
}

.action-btn:hover {
  background: #5f55fa;
  transform: translateY(-1px);
}`,
  javascript: `// Interactive user script mechanics
function sayHello() {
  console.log("Good day! Sandbox elements running smoothly code triggers! 🚀");
  const randNum = Math.floor(Math.random() * 100);
  console.log("Random calculation vector output: " + randNum);
}`
};

const compileTemplateSrcDoc = (template: Project) => {
  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>App Template Preview</title>
        <!-- Tailwind CSS Support -->
        <script src="https://cdn.tailwindcss.com"></script>
        <!-- Font styling and icon frameworks -->
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;550&display=swap" rel="stylesheet">
        <style>
          /* Normalize scrollbar within iframe previews */
          ::-webkit-scrollbar {
            width: 4px;
            height: 4px;
          }
          ::-webkit-scrollbar-track {
            background: transparent;
          }
          ::-webkit-scrollbar-thumb {
            background: rgba(156, 163, 175, 0.45);
            border-radius: 4px;
          }
          ${template.css || ''}
        </style>
      </head>
      <body>
        ${template.html || ''}
        <script>
          // Safe error interception setup
          window.onerror = function(message, source, lineno, colno, error) {
            console.error("Template Runtime Error:", message, "Line:", lineno);
            return false;
          };
          try {
            ${template.javascript || ''}
          } catch(err) {
            console.error("Script exception caught:", err.message);
          }
        </script>
      </body>
    </html>
  `;
};


interface ValidationResult {
  passed: boolean;
  jsValid: boolean;
  jsError?: string;
  htmlValid: boolean;
  htmlError?: string;
  missingIds: { id: string; tag: string }[];
  addedIds: string[];
  calculatorIntact: boolean;
  missingCalculatorElements: string[];
  severity: 'success' | 'warning' | 'error';
}

const validateAppCodes = (
  origHtml: string,
  origCss: string,
  origJs: string,
  newHtml: string,
  newCss: string,
  newJs: string
): ValidationResult => {
  let jsValid = true;
  let jsError = "";
  let htmlValid = true;
  let htmlError = "";
  
  // 1. JavaScript Compilation / Syntax Check
  try {
    if (newJs) {
      new Function(newJs);
    }
  } catch (err: any) {
    jsValid = false;
    jsError = err.message || String(err);
  }

  // 2. HTML DOM Parsing & Structure Check
  const parser = new DOMParser();
  let origDoc: Document | null = null;
  let newDoc: Document | null = null;
  const missingIds: { id: string; tag: string }[] = [];
  const addedIds: string[] = [];
  let calculatorIntact = true;
  const missingCalculatorElements: string[] = [];

  try {
    origDoc = parser.parseFromString(origHtml || "", "text/html");
    newDoc = parser.parseFromString(newHtml || "", "text/html");
    
    const parserErrors = newDoc.getElementsByTagName("parsererror");
    if (parserErrors.length > 0) {
      htmlValid = false;
      htmlError = parserErrors[0].textContent || "Malformed HTML syntax.";
    }
  } catch (err: any) {
    htmlValid = false;
    htmlError = err.message || String(err);
  }

  // 3. ID Preservation Checks
  if (origDoc && newDoc) {
    const origElements = Array.from(origDoc.querySelectorAll("[id]"));
    const newElements = Array.from(newDoc.querySelectorAll("[id]"));
    
    const origIds = origElements.map(el => ({ id: el.id, tag: el.tagName.toLowerCase() })).filter(item => Boolean(item.id));
    const newIds = new Set(newElements.map(el => el.id).filter(Boolean));

    for (const item of origIds) {
      if (!newIds.has(item.id)) {
        missingIds.push(item);
      }
    }

    const origIdSet = new Set(origIds.map(o => o.id));
    for (const el of newElements) {
      if (el.id && !origIdSet.has(el.id)) {
        addedIds.push(el.id);
      }
    }

    // 4. Calculator Buttons & Logic Check
    const origHasCalculator = origIds.some(item => 
      item.id.toLowerCase().includes("calc") || 
      item.id.toLowerCase().includes("display") || 
      item.id.toLowerCase().includes("screen") || 
      item.id.toLowerCase().includes("result") ||
      item.id.toLowerCase().includes("equal") ||
      (item.tag === "button" && /^[0-9+/*=\-C()]$/.test(item.id))
    );

    if (origHasCalculator) {
      for (const item of origIds) {
        const idLower = item.id.toLowerCase();
        const isCalcElement = idLower.includes("calc") || 
                              idLower.includes("btn") || 
                              idLower.includes("display") || 
                              idLower.includes("screen") || 
                              idLower.includes("result") || 
                              idLower.includes("equal") ||
                              /^[0-9+/*=\-C()]$/.test(item.id);
        if (isCalcElement && !newIds.has(item.id)) {
          missingCalculatorElements.push(item.id);
        }
      }
      if (missingCalculatorElements.length > 0) {
        calculatorIntact = false;
      }
    }
  }

  let severity: 'success' | 'warning' | 'error' = 'success';
  if (!jsValid || !htmlValid) {
    severity = 'error';
  } else {
    // 5. Check if it's a minor change
    let isMinorChange = false;
    if (origDoc && newDoc) {
      const origElementsCount = origDoc.querySelectorAll("[id]").length;
      // Considered minor if 3 or fewer elements are removed, or it's less than 20% of original elements
      if (missingIds.length <= 3 || (origElementsCount > 0 && (missingIds.length / origElementsCount) < 0.20)) {
        isMinorChange = true;
      }
    }
    if (!isMinorChange && (missingIds.length > 0 || !calculatorIntact)) {
      severity = 'warning';
    }
  }

  const passed = jsValid && htmlValid && severity !== 'error';

  return {
    passed,
    jsValid,
    jsError,
    htmlValid,
    htmlError,
    missingIds,
    addedIds,
    calculatorIntact,
    missingCalculatorElements,
    severity
  };
};


export default function App() {
  // Core Code States
  const [html, setHtml] = useState(INITIAL_PROJECT.html);
  const [css, setCss] = useState(INITIAL_PROJECT.css);
  const [js, setJs] = useState(INITIAL_PROJECT.javascript);
  
  // App Navigation & Interactive Preferences
  const [selectedTab, setSelectedTab] = useState<EditorTab>('html');
  const [activeProjectId, setActiveProjectId] = useState<string>(INITIAL_PROJECT.id);
  const [activeProjectName, setActiveProjectName] = useState<string>(INITIAL_PROJECT.name);
  
  // Recent projects state
  const [recentProjectIds, setRecentProjectIds] = useState<string[]>(() => {
    const stored = localStorage.getItem('cps_recent_project_ids');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error("Failed to parse stored recent project ids", e);
      }
    }
    return [INITIAL_PROJECT.id];
  });

  // Project creator states
  const [showNewProjectModal, setShowNewProjectModal] = useState<boolean>(false);
  const [newProjectNameVal, setNewProjectNameVal] = useState<string>('');
  const [newProjectTemplate, setNewProjectTemplate] = useState<string>('blank');
  const [recentDropdownOpen, setRecentDropdownOpen] = useState<boolean>(false);
  const [menuDropdownOpen, setMenuDropdownOpen] = useState<boolean>(false);
  const [activeMenuDropdown, setActiveMenuDropdown] = useState<'file' | 'ai' | 'templates' | 'tools' | 'settings' | 'tools_mobile' | null>(null);
  const [exportDropdownOpen, setExportDropdownOpen] = useState<boolean>(false);
  const [exportExpanded, setExportExpanded] = useState<boolean>(false);
  const [deleteConfirmProjectId, setDeleteConfirmProjectId] = useState<string | null>(null);

  // PWA states and installation configurations
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [isFullScreenPreview, setIsFullScreenPreview] = useState<boolean>(false);
  const [mobileActiveView, setMobileActiveView] = useState<'editor' | 'preview'>('preview');
  const [mobileNavTab, setMobileNavTab] = useState<'prompt' | 'templates' | 'editor' | 'preview' | 'more'>('prompt');
  const [settingsDropdownOpen, setSettingsDropdownOpen] = useState<boolean>(false);
  const [isMobile, setIsMobile] = useState<boolean>(false);

  // Inline rename mode states
  const [isRenamingName, setIsRenamingName] = useState<boolean>(false);
  const [editProjectNameVal, setEditProjectNameVal] = useState<string>('');

  // AI App Builder States
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [isListeningVoice, setIsListeningVoice] = useState<boolean>(false);
  const [activeVoiceTarget, setActiveVoiceTarget] = useState<'main' | 'refine'>('main');
  const [voiceLanguage, setVoiceLanguage] = useState<'en-US' | 'te-IN'>('en-US');
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [currentAiStep, setCurrentAiStep] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('All Apps');
  const [showRefinerModal, setShowRefinerModal] = useState<boolean>(false);
  const [refinerPrompt, setRefinerPrompt] = useState<string>('');
  const [showDiffModal, setShowDiffModal] = useState<boolean>(false);



  // Android App Packaging Assistant States
  const [showAndroidPackagerModal, setShowAndroidPackagerModal] = useState<boolean>(false);
  const [packagerAppName, setPackagerAppName] = useState<string>('');
  const [packagerAppID, setPackagerAppID] = useState<string>('');
  const [packagerActiveTab, setPackagerActiveTab] = useState<'analyze' | 'config' | 'export' | 'docs' | 'playStoreReady'>('analyze');

  // Android Google Play Store Ready states
  const [playStoreThemeBg, setPlayStoreThemeBg] = useState<string>('#0b0f19');
  const [playStoreThemePrimary, setPlayStoreThemePrimary] = useState<string>('#4f46e5');
  const [playStoreIsImmersive, setPlayStoreIsImmersive] = useState<boolean>(true);
  const [playStoreIsHardwareAccelerated, setPlayStoreIsHardwareAccelerated] = useState<boolean>(true);
  const [playStoreIsBackButtonIntercepted, setPlayStoreIsBackButtonIntercepted] = useState<boolean>(true);
  const [playStoreIconShape, setPlayStoreIconShape] = useState<'circle' | 'squircle' | 'rounded-rect'>('squircle');
  const [playStoreIconText, setPlayStoreIconText] = useState<string>('');
  const [playStoreIconBgColor, setPlayStoreIconBgColor] = useState<string>('#4f46e5');
  const [playStoreIconTextColor, setPlayStoreIconTextColor] = useState<string>('#ffffff');
  const [playStoreIsCompiling, setPlayStoreIsCompiling] = useState<boolean>(false);
  const [playStoreCompileLogs, setPlayStoreCompileLogs] = useState<string[]>([]);
  const [playStoreDownloadUrl, setPlayStoreDownloadUrl] = useState<string | null>(null);
  const [playStoreDownloadFilename, setPlayStoreDownloadFilename] = useState<string>('');
  const [playStoreGithubActionsWorkflow, setPlayStoreGithubActionsWorkflow] = useState<boolean>(true);
  const [projectTypeOverride, setProjectTypeOverride] = useState<'AUTO' | 'PWA' | 'HTML' | 'Android'>('AUTO');

  useEffect(() => {
    if (showAndroidPackagerModal) {
      setPackagerAppName(activeProjectName);
      const cleanId = activeProjectName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'myapp';
      setPackagerAppID(`com.company.${cleanId}`);
      
      const initials = activeProjectName
        .split(/[^a-zA-Z]/)
        .filter(Boolean)
        .map(word => word[0])
        .join('')
        .toUpperCase()
        .slice(0, 3) || 'APP';
      setPlayStoreIconText(initials);
      
      setPlayStoreIsCompiling(false);
      setPlayStoreCompileLogs([]);
      setPlayStoreDownloadUrl(null);
    }
  }, [showAndroidPackagerModal, activeProjectName]);

  const [diffTab, setDiffTab] = useState<'html' | 'css' | 'js'>('html');
  const [diffData, setDiffData] = useState<{
    originalName: string;
    newName: string;
    originalHtml: string;
    newHtml: string;
    originalCss: string;
    newCss: string;
    originalJs: string;
    newJs: string;
    explanation: string;
  } | null>(null);

  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [overrideSafety, setOverrideSafety] = useState<boolean>(false);

  useEffect(() => {
    if (diffData) {
      const res = validateAppCodes(
        diffData.originalHtml,
        diffData.originalCss,
        diffData.originalJs,
        diffData.newHtml,
        diffData.newCss,
        diffData.newJs
      );
      setValidationResult(res);
    } else {
      setValidationResult(null);
    }
    setOverrideSafety(false);
  }, [diffData]);

  // Auto-Save Configuration state
  const [isAutoSave, setIsAutoSave] = useState<boolean>(() => {
    const stored = localStorage.getItem('cps_auto_save');
    return stored ? stored === 'true' : true;
  });

  // App Templates Gallery States
  const [showTemplatesGallery, setShowTemplatesGallery] = useState<boolean>(false);
  const [selectedGalleryTemplate, setSelectedGalleryTemplate] = useState<Project>(PRESET_PROJECTS[0] || INITIAL_PROJECT);
  const [galleryCategory, setGalleryCategory] = useState<string>('All Apps');
  const [gallerySearchQuery, setGallerySearchQuery] = useState<string>('');
  const [galleryAiPrompt, setGalleryAiPrompt] = useState<string>('');
  const [galleryMobileTab, setGalleryMobileTab] = useState<'catalog' | 'preview'>('catalog');

  // Version History States
  const [activeVersions, setActiveVersions] = useState<ProjectVersion[]>([]);
  const [showVersionsPanel, setShowVersionsPanel] = useState<boolean>(false);
  const [expandedVersionId, setExpandedVersionId] = useState<string | null>(null);

  // Sync active project versions
  useEffect(() => {
    if (!activeProjectId) {
      setActiveVersions([]);
      return;
    }
    const stored = localStorage.getItem(`cps_versions_${activeProjectId}`);
    if (stored) {
      try {
        setActiveVersions(JSON.parse(stored));
      } catch (e) {
        setActiveVersions([]);
      }
    } else {
      setActiveVersions([]);
    }
  }, [activeProjectId]);

  // Version saving engine with limits & safety boundaries
  const recordVersion = (
    type: VersionType,
    versionName?: string,
    customHtml?: string,
    customCss?: string,
    customJs?: string,
    customProjectId?: string
  ) => {
    const pId = customProjectId || activeProjectId;
    if (!pId) return;

    // Use current states unless customized
    const h = customHtml !== undefined ? customHtml : html;
    const c = customCss !== undefined ? customCss : css;
    const j = customJs !== undefined ? customJs : js;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateStr = new Date().toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
    const timestamp = `${timeStr} (${dateStr})`;

    const newVersion: ProjectVersion = {
      id: 'ver_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      projectId: pId,
      timestamp,
      html: h,
      css: c,
      javascript: j,
      name: versionName || (type === 'initial' ? 'Initial Creation' : type === 'auto' ? 'Auto-Save Copy' : type === 'ai' ? 'AI Refactored' : 'Manual Savepoint'),
      type
    };

    // Load existing versions
    let currentVers: ProjectVersion[] = [];
    const stored = localStorage.getItem(`cps_versions_${pId}`);
    if (stored) {
      try {
        currentVers = JSON.parse(stored);
      } catch (e) {}
    }

    // Check if the latest version is identical to prevent useless duplicates
    if (currentVers.length > 0) {
      const last = currentVers[0];
      if (last.html === h && last.css === c && last.javascript === j) {
        if (type === 'manual' && versionName) {
          last.name = versionName;
          localStorage.setItem(`cps_versions_${pId}`, JSON.stringify(currentVers));
          if (pId === activeProjectId) {
            setActiveVersions(currentVers);
          }
        }
        return;
      }

      // If last version is auto, throttle auto versions within 45s so fast typing updates the same auto-save node 
      if (type === 'auto' && last.type === 'auto') {
        const lastTime = parseInt(last.id.split('_')[1]);
        if (Date.now() - lastTime < 45000) {
          last.html = h;
          last.css = c;
          last.javascript = j;
          last.timestamp = timestamp;
          localStorage.setItem(`cps_versions_${pId}`, JSON.stringify(currentVers));
          if (pId === activeProjectId) {
            setActiveVersions(currentVers);
          }
          return;
        }
      }
    }

    // Prepend and trim to maximum 15 items per sandbox project instance
    const updated = [newVersion, ...currentVers].slice(0, 15);
    localStorage.setItem(`cps_versions_${pId}`, JSON.stringify(updated));
    if (pId === activeProjectId) {
      setActiveVersions(updated);
    }
  };

  // Restore action
  const restoreVersion = (version: ProjectVersion) => {
    // Save current active screen modified code in an auto-save backup so they don't lose current work!
    recordVersion('auto', 'Pre-Restore Backup', html, css, js);

    // Apply recovered fields
    setHtml(version.html);
    setCss(version.css);
    setJs(version.javascript);

    triggerLocalFeedback(`Restored version from ${version.timestamp}!`);

    // Auto update preview in background
    setTimeout(() => {
      compilePreview();
    }, 100);
  };
  
  // Realtime saving transaction status
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'dirty' | 'idle'>('saved');

  // Audit Status Panel States
  const [showAuditPanel, setShowAuditPanel] = useState<boolean>(false);
  const [auditStepValidation, setAuditStepValidation] = useState<'idle' | 'pending' | 'success' | 'failed'>('idle');
  const [auditStepValidationMsg, setAuditStepValidationMsg] = useState<string>('');
  const [auditStepProjType, setAuditStepProjType] = useState<'idle' | 'pending' | 'success' | 'failed'>('idle');
  const [auditStepProjTypeMsg, setAuditStepProjTypeMsg] = useState<string>('');
  const [auditStepWorkflow, setAuditStepWorkflow] = useState<'idle' | 'pending' | 'success' | 'failed'>('idle');
  const [auditStepWorkflowMsg, setAuditStepWorkflowMsg] = useState<string>('');
  const [auditStepExport, setAuditStepExport] = useState<'idle' | 'pending' | 'success' | 'failed'>('idle');
  const [auditStepExportMsg, setAuditStepExportMsg] = useState<string>('');
  const [auditLogs, setAuditLogs] = useState<string[]>([]);
  const logsContainerRef = useRef<HTMLDivElement>(null);

  // GitHub CI Compiler States & Wizard configurations
  const [showGithubWizard, setShowGithubWizard] = useState<boolean>(false);
  const [githubToken, setGithubToken] = useState<string>(() => localStorage.getItem('github_token') || '');
  const [githubOwner, setGithubOwner] = useState<string>(() => localStorage.getItem('github_owner') || '');
  const [githubRepo, setGithubRepo] = useState<string>(() => localStorage.getItem('github_repo') || '');
  const [githubWorkflow, setGithubWorkflow] = useState<string>(() => localStorage.getItem('github_workflow') || 'android-build.yml');
  const [githubBranch, setGithubBranch] = useState<string>(() => localStorage.getItem('github_branch') || 'main');
  const [testConnectionStatus, setTestConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');
  const [testConnectionMsg, setTestConnectionMsg] = useState<string>('');
  const [compiledArtifacts, setCompiledArtifacts] = useState<{ id: number; name: string; url: string; }[]>([]);

  const saveGithubSettings = (token: string, owner: string, repo: string, workflow: string = 'android-build.yml', branch: string = 'main') => {
    localStorage.setItem('github_token', token);
    localStorage.setItem('github_owner', owner);
    localStorage.setItem('github_repo', repo);
    localStorage.setItem('github_workflow', workflow);
    localStorage.setItem('github_branch', branch);
    
    setGithubToken(token);
    setGithubOwner(owner);
    setGithubRepo(repo);
    setGithubWorkflow(workflow);
    setGithubBranch(branch);
  };

  const testGithubConnection = async (token: string, owner: string, repo: string) => {
    if (!token || !owner || !repo) {
      return { success: false, message: "Token, Owner, and Repository Name are all required." };
    }
    try {
      const res = await fetch(`https://api.github.com/repos/${owner}/${repo}`, {
        headers: {
          "Authorization": `token ${token.trim()}`,
          "Accept": "application/vnd.github+json"
        }
      });
      if (res.ok) {
        const data = await res.json();
        return { 
          success: true, 
          message: `Repository connected: ${data.full_name}. Default branch: ${data.default_branch}.` 
        };
      } else {
        const errData = await res.json().catch(() => ({}));
        const errDetail = errData.message || res.statusText;
        return { success: false, message: `Access validation failed (${res.status}): ${errDetail}` };
      }
    } catch (err: any) {
      return { success: false, message: `Network request error: ${err.message}` };
    }
  };

  const handleTestGithubConnection = async () => {
    if (!githubToken || !githubOwner || !githubRepo) {
      setTestConnectionStatus('failed');
      setTestConnectionMsg('Please enter your Personal Access Token, Username/Org, and Repository Name.');
      return;
    }
    setTestConnectionStatus('testing');
    setTestConnectionMsg('Establishing connection to GitHub API...');
    
    const result = await testGithubConnection(githubToken, githubOwner, githubRepo);
    if (result.success) {
      setTestConnectionStatus('success');
      setTestConnectionMsg(result.message);
      saveGithubSettings(githubToken.trim(), githubOwner.trim(), githubRepo.trim(), githubWorkflow, githubBranch);
    } else {
      setTestConnectionStatus('failed');
      setTestConnectionMsg(result.message);
    }
  };

  const addAuditLog = (msg: string) => {
    setAuditLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const handleAndroidPlayStoreAuditAndBuild = async (e: any) => {
    if (e && typeof e.preventDefault === 'function') {
      e.preventDefault();
    }
    setActiveMenuDropdown(null);

    // Ensure all state changes are saved to localStorage before starting the build
    if (githubToken || githubOwner || githubRepo) {
      saveGithubSettings(githubToken.trim(), githubOwner.trim(), githubRepo.trim(), githubWorkflow, githubBranch);
    }

    let token = githubToken.trim() || localStorage.getItem('github_token') || '';
    let owner = githubOwner.trim() || localStorage.getItem('github_owner') || '';
    let repo = githubRepo.trim() || localStorage.getItem('github_repo') || '';
    let workflow = githubWorkflow.trim() || localStorage.getItem('github_workflow') || 'android-build.yml';
    let branch = githubBranch.trim() || localStorage.getItem('github_branch') || 'main';

    if (!token || !owner || !repo) {
      // If PAT setup missing, show wizard config modal instead of direct failure
      setShowGithubWizard(true);
      triggerLocalFeedback("Awaiting GitHub Credential setup parameters...");
      return;
    }

    setAuditLogs([]);
    setCompiledArtifacts([]);
    setShowAuditPanel(true);
    
    setAuditStepValidation('idle');
    setAuditStepValidationMsg('');
    setAuditStepProjType('idle');
    setAuditStepProjTypeMsg('');
    setAuditStepWorkflow('idle');
    setAuditStepWorkflowMsg('');
    setAuditStepExport('idle');
    setAuditStepExportMsg('');

    const sleepLocal = (ms: number) => new Promise(r => setTimeout(r, ms));

    // Step 1: Head tags check & Responsive Layout Validation with Auto Viewport Fix
    setAuditStepValidation('pending');
    setAuditStepValidationMsg('Analyzing viewport scale and layout responsiveness configurations...');
    addAuditLog('Initializing project layout checks...');
    await sleepLocal(600);

    const checkViewportResult = analyzeProjectForMobile();
    let hasViewport = checkViewportResult.hasViewport;
    let score = checkViewportResult.score;
    let detectedType = checkViewportResult.detectedType;
    let effectiveType = checkViewportResult.effectiveType;

    if (!hasViewport) {
      addAuditLog('[Auto-Fix] Missing mobile viewport tag inside HTML <head>. Restructuring tags now...');
      setAuditStepValidationMsg('Automatically injecting viewport scale target to index.html Document...');
      await sleepLocal(900);

      let updatedHtml = html;
      const viewportTag = '\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">';
      if (updatedHtml.toLowerCase().includes('<head>')) {
        updatedHtml = updatedHtml.replace(/<head>/i, `<head>${viewportTag}`);
      } else if (updatedHtml.toLowerCase().includes('<html>')) {
        updatedHtml = updatedHtml.replace(/<html>/i, `<html>\n<head>${viewportTag}\n</head>`);
      } else {
        updatedHtml = `<head>${viewportTag}\n</head>\n` + updatedHtml;
      }
      setHtml(updatedHtml);
      
      triggerLocalFeedback("Automatically injected missing viewport scale tag!");
      recordVersion('manual', 'Auto-injected Mobile Viewport Tag', updatedHtml, css, js);
      addAuditLog('[Auto-Fix] Viewport meta tag successfully injected into document head block.');
      
      await sleepLocal(400);
      const reCheck = analyzeProjectForMobile();
      hasViewport = reCheck.hasViewport;
      score = reCheck.score;
      detectedType = reCheck.detectedType;
      effectiveType = reCheck.effectiveType;
    }

    addAuditLog(`Mobile usability score calculated: ${score}/100.`);
    setAuditStepValidation('success');
    setAuditStepValidationMsg(`Assessed layout design score: ${score}/100. Has Viewport: Yes (Injected)`);
    addAuditLog('Responsive layout checks completed.');

    // Step 2: Project Classification scans
    setAuditStepProjType('pending');
    setAuditStepProjTypeMsg('Determining workspace layout blueprint type...');
    addAuditLog('Scouting workspace directories and files...');
    await sleepLocal(600);

    addAuditLog(`Detected file layout ecosystem: ${detectedType}`);
    addAuditLog(`Effective packaging classification: ${effectiveType}`);
    setAuditStepProjType('success');
    setAuditStepProjTypeMsg(`Ecosystem target: ${effectiveType}`);

    // Step 3: Github actions & OAuth validation check before dispatch run
    setAuditStepWorkflow('pending');
    setAuditStepWorkflowMsg('Verifying GitHub API access and connection permissions...');
    addAuditLog('Testing remote GitHub connectivity...');
    await sleepLocal(600);

    const testRes = await testGithubConnection(token, owner, repo);
    if (!testRes.success) {
      addAuditLog(`Error: GitHub connectivity validation failed. ${testRes.message}`);
      setAuditStepWorkflow('failed');
      setAuditStepWorkflowMsg(`Access Error: ${testRes.message}`);
      setAuditStepExport('failed');
      setAuditStepExportMsg('Cloud build aborted due to connection issues.');
      
      await sleepLocal(1800);
      setShowAuditPanel(false);
      setShowGithubWizard(true);
      return;
    }

    addAuditLog('GitHub connectivity approved! Repository exists and is fully reachable.');
    addAuditLog('Dispatching POST trigger payload to GitHub Webhook Actions endpoint...');
    setAuditStepWorkflowMsg('Dispatching CI action workflow events...');

    try {
      const dispatchUrl = `https://api.github.com/repos/${owner}/${repo}/actions/workflows/${workflow}/dispatches`;
      const dispatchRes = await fetch(dispatchUrl, {
        method: "POST",
        headers: {
          "Authorization": `token ${token}`,
          "Accept": "application/vnd.github+json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ref: branch
        })
      });

      if (!dispatchRes.ok) {
        const errText = await dispatchRes.text();
        throw new Error(`Dispatch failed (${dispatchRes.status}): ${errText}`);
      }

      addAuditLog('Actions workflow dispatched. Polling for remote execution run...');
      setAuditStepWorkflowMsg('Workflow dispatched. Awaiting compilation start...');

      let runId = null;
      const maxFindAttempts = 10;
      const runsUrl = `https://api.github.com/repos/${owner}/${repo}/actions/runs?event=workflow_dispatch`;

      for (let attempt = 1; attempt <= maxFindAttempts; attempt++) {
        await sleepLocal(3000);
        addAuditLog(`Searching for compiling run (attempt ${attempt}/${maxFindAttempts})...`);
        
        const runsRes = await fetch(runsUrl, {
          headers: {
            "Authorization": `token ${token}`,
            "Accept": "application/vnd.github+json"
          }
        });

        if (!runsRes.ok) continue;

        const data = await runsRes.json();
        const latestRun = data.workflow_runs?.[0];

        if (latestRun) {
          const createdTime = new Date(latestRun.created_at).getTime();
          const now = new Date().getTime();
          if (now - createdTime < 120000) {
            runId = latestRun.id;
            addAuditLog(`Located active GitHub run ID: ${runId}`);
            break;
          }
        }
      }

      if (!runId) {
        addAuditLog('Actions workflow triggered but tracker timed out. Inspect your GitHub repo Actions tab manual logs.');
        setAuditStepWorkflow('success');
        setAuditStepWorkflowMsg('Dispatched! Check workflow details at GitHub.');
        setAuditStepExport('success');
        setAuditStepExportMsg('Dispatched securely. Track output bundle artifacts on GitHub repository.');
        return;
      }

      addAuditLog('Tracked active compiling run! Polling continuous compiler actions...');
      setAuditStepWorkflowMsg(`CI Build Compiling (Run ID: ${runId})...`);
      
      let isCompleted = false;
      const maxPollAttempts = 60;
      let pollCount = 0;

      setAuditStepExport('pending');
      setAuditStepExportMsg('Monitoring live compilation milestones...');

      while (!isCompleted && pollCount < maxPollAttempts) {
        pollCount++;
        await sleepLocal(5000);

        const runStatusUrl = `https://api.github.com/repos/${owner}/${repo}/actions/runs/${runId}`;
        const statusRes = await fetch(runStatusUrl, {
           headers: {
            "Authorization": `token ${token}`,
            "Accept": "application/vnd.github+json"
           }
        });

        if (!statusRes.ok) continue;

        const runData = await statusRes.json();
        const currentStatus = runData.status;
        const currentConclusion = runData.conclusion;

        addAuditLog(`Action Compilation Status: [${currentStatus}] | conclusion: [${currentConclusion || 'running'}]`);
        setAuditStepWorkflowMsg(`CI packaging status: ${currentStatus}...`);

        if (currentStatus === 'completed') {
          isCompleted = true;
          if (currentConclusion === 'success') {
            addAuditLog('Build succeeded with green check! Downloading output build artifacts metadata...');
            setAuditStepWorkflow('success');
            setAuditStepWorkflowMsg('Build successful! Remote assets compiled securely.');

            const artifactsUrl = `https://api.github.com/repos/${owner}/${repo}/actions/runs/${runId}/artifacts`;
            const artRes = await fetch(artifactsUrl, {
               headers: {
                "Authorization": `token ${token}`,
                "Accept": "application/vnd.github+json"
               }
            });

            if (artRes.ok) {
              const artData = await artRes.json();
              const artifacts = artData.artifacts || [];
              
              if (artifacts.length > 0) {
                const apkArtifacts = artifacts.filter((a: any) => a.name.toLowerCase().includes('apk'));
                const aabArtifacts = artifacts.filter((a: any) => a.name.toLowerCase().includes('aab') || a.name.toLowerCase().includes('bundle'));
                
                const resolvedList = artifacts.map((art: any) => ({
                  id: art.id,
                  name: art.name,
                  url: `https://github.com/${owner}/${repo}/actions/runs/${runId}/artifacts/${art.id}`
                }));
                setCompiledArtifacts(resolvedList);

                let linksMessage = "";
                if (apkArtifacts.length > 0) {
                  linksMessage += "📦 APK:\n";
                  apkArtifacts.forEach((a: any) => {
                    linksMessage += `- ${a.name}: https://github.com/${owner}/${repo}/actions/runs/${runId}/artifacts/${a.id}\n`;
                  });
                }
                if (aabArtifacts.length > 0) {
                  linksMessage += "📦 AAB:\n";
                  aabArtifacts.forEach((a: any) => {
                    linksMessage += `- ${a.name}: https://github.com/${owner}/${repo}/actions/runs/${runId}/artifacts/${a.id}\n`;
                  });
                }

                setAuditStepExport('success');
                setAuditStepExportMsg(`${artifacts.length} package file(s) available.`);
                addAuditLog('Output package bundles successfully resolved.');
                alert(`GitHub Action Compiler Succeeded!\n\n${linksMessage}`);
              } else {
                setAuditStepExport('success');
                setAuditStepExportMsg('Compiled successfully. Download files from your repo Action page.');
              }
            } else {
              setAuditStepExport('success');
              setAuditStepExportMsg('Compiled successfully.');
            }
          } else {
            setAuditStepWorkflow('failed');
            setAuditStepWorkflowMsg(`Workflow job failed: ${currentConclusion}`);
            setAuditStepExport('failed');
            setAuditStepExportMsg('CI Compilation failed.');
            addAuditLog(`Error: Continuous compiling flow returned failure exit code: [${currentConclusion}].`);
            alert(`GitHub Action failed (${currentConclusion}). View build logs:\nhttps://github.com/${owner}/${repo}/actions/runs/${runId}`);
          }
        }
      }

    } catch (err: any) {
      console.error("Workflow trigger error:", err);
      addAuditLog(`Exception: ${err.message}`);
      
      const is404 = err.message && (err.message.includes('404') || err.message.toLowerCase().includes('not found'));
      if (is404) {
        addAuditLog('⚠️ Troubleshooting GitHub 404 (Not Found):');
        addAuditLog(`1. Inside your repository "${owner}/${repo}", the workflow file must exist on branch "${branch}".`);
        addAuditLog(`2. It must be placed under the folder path: .github/workflows/${workflow}`);
        addAuditLog('3. Make sure you export your Android ZIP package from the top exporter bar, unzip it, commit, and push the .github/ folder to your GitHub repo.');
      }

      setAuditStepWorkflow('failed');
      setAuditStepWorkflowMsg(is404 ? `Workflow file "${workflow}" not found on branch "${branch}"` : 'Failed to trigger run workflow.');
      setAuditStepExport('failed');
      setAuditStepExportMsg(is404 ? 'Workflow file not found.' : 'Export flow aborted.');
      
      if (is404) {
        alert(`GitHub API returned 404 (Not Found):\n\nThis means GitHub cannot find the workflow file "${workflow}" under ".github/workflows/" in your branch "${branch}".\n\nTo fix:\n1. Ensure you exported the Android project bundle.\n2. Ensure the ".github/workflows/${workflow}" file is committed and pushed to "${branch}".\n3. Click "Edit Build Settings" under the Audit panel to verify or change your settings.`);
      } else {
        alert(`Runtime dispatch issue: ${err.message}`);
      }
    }
  };

  // Theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const stored = localStorage.getItem('cps_dark_mode');
    return stored ? stored === 'true' : true;
  });

  // Settings & Modes
  const [autoRun, setAutoRun] = useState<boolean>(true);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [editorHeight, setEditorHeight] = useState<number>(380); // in pixels
  const [showConsole, setShowConsole] = useState<boolean>(true);
  
  // CDN Configuration integrations
  const [useTailwind, setUseTailwind] = useState<boolean>(true);
  const [useFontAwesome, setUseFontAwesome] = useState<boolean>(false);
  const [useGoogleFonts, setUseGoogleFonts] = useState<boolean>(true);
  
  // Projects Management
  const [projects, setProjects] = useState<Project[]>(() => {
    const stored = localStorage.getItem('cps_projects');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.length > 0) return parsed;
      } catch (e) {
        console.error("Failed to parse stored projects", e);
      }
    }
    return PRESET_PROJECTS;
  });

  // Modals & Slidouts
  const [showLoadPanel, setShowLoadPanel] = useState<boolean>(false);
  const [showSaveAsModal, setShowSaveAsModal] = useState<boolean>(false);
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  
  // Input fields
  const [newProjectName, setNewProjectName] = useState<string>('');
  
  // Sandbox execution key & outputs
  const [previewKey, setPreviewKey] = useState<number>(0);
  const [renderedCode, setRenderedCode] = useState<string>('');
  const [consoleLogs, setConsoleLogs] = useState<{ type: 'log' | 'error' | 'system'; text: string; time: string }[]>([]);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // Refs for editor synchronization and dragging
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineGutterRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const isResizingRef = useRef<boolean>(false);
  const startDragYRef = useRef<number>(0);
  const startHeightRef = useRef<number>(0);

  // Refs to track absolute latest input values, fully mitigating template closure delays
  const htmlRef = useRef(html);
  const cssRef = useRef(css);
  const jsRef = useRef(js);

  useEffect(() => {
    htmlRef.current = html;
  }, [html]);

  useEffect(() => {
    cssRef.current = css;
  }, [css]);

  useEffect(() => {
    jsRef.current = js;
  }, [js]);

  // Handle mobile responsive width detection
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Handle local storage persisting
  useEffect(() => {
    localStorage.setItem('cps_projects', JSON.stringify(projects));
  }, [projects]);

  // Auto scroll mobile audit logs to base
  useEffect(() => {
    if (logsContainerRef.current) {
      logsContainerRef.current.scrollTop = logsContainerRef.current.scrollHeight;
    }
  }, [auditLogs, showAuditPanel]);

  // Handle local storage recents persisting
  useEffect(() => {
    localStorage.setItem('cps_recent_project_ids', JSON.stringify(recentProjectIds));
  }, [recentProjectIds]);

  // Touch project helper to manage Recents history lists
  const touchProject = (id: string | undefined) => {
    if (!id) return;
    setRecentProjectIds(prev => {
      const filtered = prev.filter(item => item !== id);
      return [id, ...filtered].slice(0, 5); // Keep top 5 unique
    });
  };

  useEffect(() => {
    localStorage.setItem('cps_dark_mode', String(isDarkMode));
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Sync scroll of lines gutter with textarea
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (lineGutterRef.current) {
      lineGutterRef.current.scrollTop = e.currentTarget.scrollTop;
    }
  };

  // Keyboard enhancements
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Intercept Tab presses inside textareas
    if (e.key === 'Tab') {
      e.preventDefault();
      const textarea = e.currentTarget;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const value = textarea.value;
      const spaces = '  '; // 2 spaces standard indents

      const updatedVal = value.substring(0, start) + spaces + value.substring(end);
      
      if (selectedTab === 'html') setHtml(updatedVal);
      else if (selectedTab === 'css') setCss(updatedVal);
      else if (selectedTab === 'javascript') setJs(updatedVal);

      // Restore cursor position in the next tick
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + spaces.length;
      }, 0);
    }
  };

  // Combined code logic compiler
  const compilePreview = () => {
    setConsoleLogs([{ type: 'system', text: 'Initializing Sandbox Compilation...', time: new Date().toLocaleTimeString() }]);
    
    const currentHtml = htmlRef.current;
    const currentCss = cssRef.current;
    const currentJs = jsRef.current;

    // Build the dynamic helper scripts for CDN integrations
    const tailwindCdn = useTailwind ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
    const fontAwesomeCdn = useFontAwesome ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
    const googleFontsCdn = useGoogleFonts ? '<link rel="preload" href="https://fonts.googleapis.com" rel="dns-prefetch"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;450;600;800&family=JetBrains+Mono:wght@400;700&display=swap">' : '';

    const assembledMarkup = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        ${googleFontsCdn}
        ${fontAwesomeCdn}
        ${tailwindCdn}
        <style>
          /* User Custom CSS */
          ${currentCss}
        </style>
      </head>
      <body>
        ${currentHtml}
        
        <!-- Parent-Console bridge client -->
        <script>
          (function() {
            // Guarantee DOMContentLoaded/load triggers successfully because sandbox loads instantly
            const originalAddEventListener = document.addEventListener;
            document.addEventListener = function(type, listener, options) {
              if (type === 'DOMContentLoaded') {
                setTimeout(() => {
                  try {
                    listener(new Event('DOMContentLoaded'));
                  } catch(e) {
                    console.error("DOMContentLoaded handler failed:", e);
                  }
                }, 4);
              } else {
                originalAddEventListener.call(document, type, listener, options);
              }
            };

            const originalWindowAddEventListener = window.addEventListener;
            window.addEventListener = function(type, listener, options) {
              if (type === 'load') {
                setTimeout(() => {
                  try {
                    listener(new Event('load'));
                  } catch(e) {
                    console.error("Window onload handler failed:", e);
                  }
                }, 10);
              } else {
                originalWindowAddEventListener.call(window, type, listener, options);
              }
            };

            const originalLog = console.log;
            const originalError = console.error;
            
            console.log = function(...args) {
              const formattedMsg = args.map(arg => {
                if (typeof arg === 'object') {
                  try { return JSON.stringify(arg); } catch(e) { return '[Object]'; }
                }
                return String(arg);
              }).join(' ');
              
              window.parent.postMessage({ type: 'CONSOLE_LOG', text: formattedMsg }, '*');
              originalLog.apply(console, args);
            };

            console.error = function(...args) {
              const formattedMsg = args.map(arg => String(arg)).join(' ');
              window.parent.postMessage({ type: 'CONSOLE_ERROR', text: formattedMsg }, '*');
              originalError.apply(console, args);
            };

            window.onerror = function(message, source, lineno, colno, error) {
              window.parent.postMessage({ 
                type: 'CONSOLE_ERROR', 
                text: message + " (Line " + lineno + ")"
              }, '*');
              return false;
            };
          })();
        </script>
        
        <!-- User Custom JS -->
        <script>
          try {
            ${currentJs}
          } catch(e) {
            console.error(e.message);
          }
        </script>
      </body>
      </html>
    `;
    
    setRenderedCode(assembledMarkup);
    setPreviewKey(prev => prev + 1);
  };

  // Trigger preview on initial view
  useEffect(() => {
    compilePreview();
    touchProject(activeProjectId);
  }, []);

  // Synchronize PWA Service Worker loading, offline alerts & home screen install events
  useEffect(() => {
    // 1. Register PWA Service Worker
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then((reg) => {
            console.log('App PWA Service Worker registered with scope:', reg.scope);
          })
          .catch((err) => {
            console.warn('App PWA Service Worker registration failed:', err);
          });
      });
    }

    // 2. Capture the beforeinstallprompt offer of the browser
    const handleInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleInstallPrompt as any);

    // 3. Keep track when application installer achieves home screen install
    const handleAppInstalled = () => {
      setIsInstallable(false);
      setDeferredPrompt(null);
      triggerLocalFeedback('Success! AI App Builder installed on Home Screen.');
    };

    window.addEventListener('appinstalled', handleAppInstalled);

    // 4. Track Network online/offline triggers safely
    const updateOnlineStatus = () => {
      setIsOffline(!navigator.onLine);
      if (navigator.onLine) {
        triggerLocalFeedback('Back Online! Workspace synchronized.');
      } else {
        triggerLocalFeedback('Offline Mode Active. Cache assets loaded.');
      }
    };

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleInstallPrompt as any);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', updateOnlineStatus);
      window.removeEventListener('offline', updateOnlineStatus);
    };
  }, []);

  // Handler to request Native Android / Chrome installation
  const triggerNativePwaInstall = async () => {
    if (!deferredPrompt) {
      triggerLocalFeedback('PWA installation is not supported or already cached.');
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      triggerLocalFeedback('App installation started!');
    }
    setDeferredPrompt(null);
    setIsInstallable(false);
  };

  // Instant compile on CDN toggle changes
  useEffect(() => {
    compilePreview();
  }, [useTailwind, useFontAwesome, useGoogleFonts]);

  // Handle Auto-compiling logic with a debounced effect
  useEffect(() => {
    if (!autoRun) return;
    const delayTimer = setTimeout(() => {
      compilePreview();
    }, 1200);

    return () => clearTimeout(delayTimer);
  }, [html, css, js, autoRun]);

  // Keep track of dirty state vs saved state
  useEffect(() => {
    const currentProj = projects.find(p => p.id === activeProjectId);
    if (currentProj) {
      if (currentProj.html !== html || currentProj.css !== css || currentProj.javascript !== js) {
        setSaveStatus('dirty');
      } else {
        setSaveStatus('saved');
      }
    } else {
      setSaveStatus('dirty');
    }
  }, [html, css, js, activeProjectId, projects]);

  // Debounced Auto-Save controller
  useEffect(() => {
    if (!isAutoSave) return;

    // Check if the current workspace content is different from stored content
    const currentProj = projects.find(p => p.id === activeProjectId);
    if (currentProj) {
      if (currentProj.html === html && currentProj.css === css && currentProj.javascript === js) {
        setSaveStatus('saved');
        return;
      }
    }

    setSaveStatus('saving');

    const saveTimer = setTimeout(() => {
      const isPreset = PRESET_PROJECTS.some(p => p.id === activeProjectId);
      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + " " + new Date().toLocaleDateString([], { month: 'short', day: 'numeric' });

      if (isPreset) {
        // If current project is a preset, auto-clone it so they don't lose changes
        const newId = 'user_proj_' + Date.now();
        const cloneName = `${activeProjectName} (Copy)`;
        const clonedProj: Project = {
          id: newId,
          name: cloneName,
          html,
          css,
          javascript: js,
          updatedAt: timestamp
        };

        setProjects(prev => [clonedProj, ...prev]);
        setActiveProjectId(newId);
        setActiveProjectName(cloneName);
        setSaveStatus('saved');
        touchProject(newId);
        triggerLocalFeedback('Auto-cloned preset to your sandbox!');
        recordVersion('initial', 'Initial Auto-Clone (Preset Copy)', html, css, js, newId);
      } else {
        // Update user project in place
        setProjects(prev => prev.map(p => {
          if (p.id === activeProjectId) {
            return {
              ...p,
              html,
              css,
              javascript: js,
              updatedAt: timestamp
            };
          }
          return p;
        }));
        setSaveStatus('saved');
        touchProject(activeProjectId);
        recordVersion('auto', 'Auto-Save Copy', html, css, js);
      }
    }, 1500); // 1.5s delay to buffer inputs

    return () => clearTimeout(saveTimer);
  }, [html, css, js, isAutoSave, activeProjectId, activeProjectName, projects]);

  // Action to submit project name changes inline
  const handleRenameSubmit = () => {
    const trimmed = editProjectNameVal.trim();
    if (!trimmed || trimmed === activeProjectName) {
      setIsRenamingName(false);
      return;
    }

    const isPreset = PRESET_PROJECTS.some(p => p.id === activeProjectId);
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + " " + new Date().toLocaleDateString([], { month: 'short', day: 'numeric' });

    if (isPreset) {
      // Clones preset instantly with requested name
      const newId = 'user_proj_' + Date.now();
      const newProj: Project = {
        id: newId,
        name: trimmed,
        html,
        css,
        javascript: js,
        updatedAt: timestamp
      };
      setProjects(prev => [newProj, ...prev]);
      setActiveProjectId(newId);
      setActiveProjectName(trimmed);
      triggerLocalFeedback('Cloned & Renamed preset!');
    } else {
      // Inline update name inside list
      setProjects(prev => prev.map(p => {
        if (p.id === activeProjectId) {
          return {
            ...p,
            name: trimmed,
            updatedAt: timestamp
          };
        }
        return p;
      }));
      setActiveProjectName(trimmed);
      triggerLocalFeedback('Project Renamed!');
    }
    setIsRenamingName(false);
  };

  // Listen to visual debug logs sent from Sandbox iframe
  useEffect(() => {
    const handleMessageEvent = (event: MessageEvent) => {
      if (event.data && event.data.type) {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        if (event.data.type === 'CONSOLE_LOG') {
          setConsoleLogs(prev => [...prev, { type: 'log', text: event.data.text, time: timeStr }]);
        } else if (event.data.type === 'CONSOLE_ERROR') {
          setConsoleLogs(prev => [...prev, { type: 'error', text: event.data.text, time: timeStr }]);
        }
      }
    };

    window.addEventListener('message', handleMessageEvent);
    return () => window.removeEventListener('message', handleMessageEvent);
  }, []);

  // Utility actions
  const triggerClear = () => {
    setHtml('');
    setCss('');
    setJs('');
    setConsoleLogs([{ type: 'system', text: 'Workspace cleared.', time: new Date().toLocaleTimeString() }]);
    setShowClearConfirm(false);
  };

  // Save current hotkey effect listener
  useEffect(() => {
    const handleSaveHotkey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSaveCurrent();
      }
    };
    window.addEventListener('keydown', handleSaveHotkey);
    return () => window.removeEventListener('keydown', handleSaveHotkey);
  }, [html, css, js, activeProjectId, activeProjectName, projects]);

  const getProjectById = (id: string): Project | undefined => {
    const userFound = projects.find(p => p.id === id);
    if (userFound) return userFound;
    return PRESET_PROJECTS.find(p => p.id === id);
  };

  const createNewProject = (name: string, templateKey: string) => {
    const trimmedName = name.trim() || 'Untitled Project';
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + " " + new Date().toLocaleDateString([], { month: 'short', day: 'numeric' });
    
    let htmlContent = '';
    let cssContent = '';
    let jsContent = '';

    if (templateKey === 'blank') {
      htmlContent = BLANK_TEMPLATE.html;
      cssContent = BLANK_TEMPLATE.css;
      jsContent = BLANK_TEMPLATE.javascript;
    } else {
      const templateMatched = PRESET_PROJECTS.find(p => p.id === templateKey);
      if (templateMatched) {
        htmlContent = templateMatched.html;
        cssContent = templateMatched.css;
        jsContent = templateMatched.javascript;
      } else {
        htmlContent = BLANK_TEMPLATE.html;
        cssContent = BLANK_TEMPLATE.css;
        jsContent = BLANK_TEMPLATE.javascript;
      }
    }

    const newId = 'user_proj_' + Date.now();
    const newProj: Project = {
      id: newId,
      name: trimmedName,
      html: htmlContent,
      css: cssContent,
      javascript: jsContent,
      updatedAt: timestamp
    };

    setProjects(prev => [newProj, ...prev]);
    setActiveProjectId(newId);
    setActiveProjectName(trimmedName);
    setHtml(htmlContent);
    setCss(cssContent);
    setJs(jsContent);
    setSaveStatus('saved');
    
    // Add to recent projects index
    setRecentProjectIds(prev => {
      const filtered = prev.filter(item => item !== newId);
      return [newId, ...filtered].slice(0, 5);
    });
    
    setShowNewProjectModal(false);
    triggerLocalFeedback(`Created project "${trimmedName}"!`);
    
    setTimeout(() => {
      compilePreview();
    }, 120);
  };

  const handleLoadTemplateDirectly = (templateName: 'calc' | 'notes' | 'quiz' | 'todo') => {
    let tObj;
    let label = '';
    
    if (templateName === 'calc') {
      tObj = {
        id: 'user_calc_' + Date.now(),
        name: 'Calculator App',
        html: TEMPLATE_CALCULATOR.html,
        css: TEMPLATE_CALCULATOR.css,
        javascript: TEMPLATE_CALCULATOR.javascript
      };
      label = 'Calculator App';
    } else if (templateName === 'notes') {
      tObj = {
        id: 'user_notes_' + Date.now(),
        name: 'Sticky Notes App',
        html: TEMPLATE_NOTES.html,
        css: TEMPLATE_NOTES.css,
        javascript: TEMPLATE_NOTES.javascript
      };
      label = 'Sticky Notes App';
    } else if (templateName === 'quiz') {
      tObj = {
        id: 'user_quiz_' + Date.now(),
        name: 'Interactive Quiz App',
        html: TEMPLATE_QUIZ.html,
        css: TEMPLATE_QUIZ.css,
        javascript: TEMPLATE_QUIZ.javascript
      };
      label = 'Interactive Quiz App';
    } else if (templateName === 'todo') {
      tObj = {
        id: 'user_todo_' + Date.now(),
        name: 'Focus To-Do App',
        html: TEMPLATE_TODO.html,
        css: TEMPLATE_TODO.css,
        javascript: TEMPLATE_TODO.javascript
      };
      label = 'Focus To-Do App';
    }

    if (tObj) {
      loadProject(tObj);
      triggerLocalFeedback(`Loaded ${label} Space successfully!`);
    }
  };

  const loadProject = (project: Project) => {
    setHtml(project.html);
    setCss(project.css);
    setJs(project.javascript);
    setActiveProjectId(project.id);
    setActiveProjectName(project.name);
    setShowLoadPanel(false);
    
    // Touch to put on Recent projects history
    touchProject(project.id);

    // Push loaded system flag
    setConsoleLogs([
      { type: 'system', text: `Loaded Project: "${project.name}"`, time: new Date().toLocaleTimeString() }
    ]);
    
    // Auto trigger immediate preview compile
    setTimeout(() => {
      compilePreview();
    }, 100);
  };

  const handleEditTemplateWithAi = (template: Project, instruction: string) => {
    // 1. Instantly load the project into local workspace editor state fields
    setHtml(template.html);
    setCss(template.css);
    setJs(template.javascript);
    setActiveProjectId(template.id);
    setActiveProjectName(template.name);
    
    // Push loaded system flag
    setConsoleLogs([
      { type: 'system', text: `Loaded template baseline for AI Refinement: "${template.name}"`, time: new Date().toLocaleTimeString() }
    ]);
    
    // Register recent history
    touchProject(template.id);

    // 2. Hide Templates Gallery
    setShowTemplatesGallery(false);

    // 3. Kickoff AI refactoring generator on this specific baseline state structure
    handleAiGenerate(true, instruction, {
      html: template.html,
      css: template.css,
      js: template.javascript,
      name: template.name
    });
  };

  const startVoiceRecognition = (target: 'main' | 'refine' = 'main') => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      triggerLocalFeedback("Voice inputs are not supported in your browser viewport.");
      return;
    }
    
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = voiceLanguage;
    recognition.interimResults = false;
    
    recognition.onstart = () => {
      setIsListeningVoice(true);
      setActiveVoiceTarget(target);
      const isTe = voiceLanguage === 'te-IN';
      triggerLocalFeedback(isTe ? "రికార్డింగ్ ప్రారంభమైంది... మాట్లాడండి" : "Speech recognition active... Speak now!");
    };
    
    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event);
      setIsListeningVoice(false);
      triggerLocalFeedback(`Voice error: ${event.error || 'Check permissions'}`);
    };
    
    recognition.onend = () => {
      setIsListeningVoice(false);
    };
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      const isTe = voiceLanguage === 'te-IN';
      if (target === 'refine') {
        setRefinerPrompt(prev => prev ? `${prev} ${transcript}` : transcript);
      } else {
        setAiPrompt(prev => prev ? `${prev} ${transcript}` : transcript);
      }
      triggerLocalFeedback(isTe ? "వాయిస్ పట్టుబడింది!" : "Captured voice instructions!");
    };
    
    recognition.start();
  };

  const handleAiGenerate = async (
    isEditExisting: boolean = false, 
    customPrompt?: string,
    overrideBaseline?: { html: string; css: string; js: string; name: string }
  ) => {
    const promptToUse = (customPrompt || aiPrompt || '').trim();
    if (!promptToUse) {
      triggerLocalFeedback("Please write an instruction prompt.");
      return;
    }
    
    setIsGeneratingAi(true);
    setCurrentAiStep("Informing Gemini Engine...");
    
    const stages = [
      "Analyzing layout requirements...",
      "Configuring Tailwind style configurations...",
      "Drafting elegant structure panels...",
      "Formulating fully physical mechanics...",
      "Compiling complete interactive triggers...",
      "Verifying sandbox compilation output...",
    ];
    
    let stageId = 0;
    const interval = setInterval(() => {
      if (stageId < stages.length) {
        setCurrentAiStep(stages[stageId]);
        stageId++;
      }
    }, 2250);

    const baseHtml = isEditExisting ? (overrideBaseline ? overrideBaseline.html : html) : '';
    const baseCss = isEditExisting ? (overrideBaseline ? overrideBaseline.css : css) : '';
    const baseJs = isEditExisting ? (overrideBaseline ? overrideBaseline.js : js) : '';
    const baseName = isEditExisting ? (overrideBaseline ? overrideBaseline.name : activeProjectName) : 'Empty';

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptToUse,
          currentHtml: baseHtml,
          currentCss: baseCss,
          currentJs: baseJs,
          category: activeCategory,
          templateName: baseName,
        }),
      });
      
      clearInterval(interval);
      
      if (!res.ok) {
        let errMsg = "Server model failure.";
        try {
          const errorData = await res.json();
          errMsg = errorData.error || errMsg;
        } catch (_) {
          try {
            const txt = await res.text();
            if (txt && (txt.includes("<!doctype") || txt.includes("<html") || txt.includes("<!DOCTYPE"))) {
              errMsg = `Server encountered an issue (${res.status}). Detailed diagnostic HTML was returned. Please retry in a few moments.`;
            } else {
              errMsg = txt || `Server returned code ${res.status}`;
            }
          } catch (textErr) {
            errMsg = `Server core error code ${res.status}`;
          }
        }
        throw new Error(errMsg);
      }
      
      let appData;
      try {
        appData = await res.json();
      } catch (jsonErr) {
        throw new Error("Unable to parse generation results. The response from the server was not formatted as valid JSON.");
      }
      
      // Handle AI Clarification Seek Request
      if (appData.clarificationRequired) {
        setIsGeneratingAi(false);
        setCurrentAiStep('');
        setShowRefinerModal(false);
        setRefinerPrompt('');
        
        setConsoleLogs(prev => [
          { type: 'error', text: `⚠️ CLARIFICATION SEEK: ${appData.clarificationMessage || 'Your prompt is unclear or conflicts with existing functionality.'}`, time: new Date().toLocaleTimeString() },
          ...prev
        ]);
        
        alert(`AI App Builder Seeks Clarification:\n\n${appData.clarificationMessage || 'The request is unclear or conflicts with existing app functionality. Please specify your modifications more clearly.'}`);
        triggerLocalFeedback("Awaiting user clarification...");
        return;
      }

      setCurrentAiStep("Parsing compiled segments...");
      
      const generatedName = appData.appName || baseName || "Interactive App Builder Result";
      
      if (isEditExisting) {
        // Stage original and proposed code inside diffData
        setDiffData({
          originalName: baseName,
          newName: generatedName,
          originalHtml: baseHtml,
          newHtml: appData.html || '',
          originalCss: baseCss,
          newCss: appData.css || '',
          originalJs: baseJs,
          newJs: appData.javascript || '',
          explanation: appData.explanation || ''
        });
        
        // Hide initial refactoring setup, prompt user with difference viewer
        setShowRefinerModal(false);
        setRefinerPrompt('');
        
        setIsGeneratingAi(false);
        setCurrentAiStep('');
        
        // Open Diff Modal
        setShowDiffModal(true);
        triggerLocalFeedback("Modifications compiled! Reviewing changes...");
      } else {
        // Standard flow: Apply directly and create a brand new project node
        setHtml(appData.html || '');
        setCss(appData.css || '');
        setJs(appData.javascript || '');
        setActiveProjectName(generatedName);
        
        const generatedProjId = 'ai_' + Date.now();
        setActiveProjectId(generatedProjId);

        const newProjNode: Project = {
          id: generatedProjId,
          name: generatedName,
          html: appData.html || '',
          css: appData.css || '',
          javascript: appData.javascript || '',
          category: activeCategory,
          updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setProjects(prev => [newProjNode, ...prev]);

        // Record initial generated version checkpoint
        recordVersion('auto', 'AI Generated System', appData.html || '', appData.css || '', appData.javascript || '', generatedProjId);

        setConsoleLogs([
          { type: 'system', text: `✨ AI Successfully Generated: "${generatedName}"`, time: new Date().toLocaleTimeString() }
        ]);
        
        setTimeout(() => {
          setIsGeneratingAi(false);
          setAiPrompt('');
          setCurrentAiStep('');
          compilePreview();
          triggerLocalFeedback(`Generated "${generatedName}" successfully!`);
        }, 400);
      }

    } catch (err: any) {
      clearInterval(interval);
      setIsGeneratingAi(false);
      setCurrentAiStep('');
      console.error(err);
      triggerLocalFeedback(`AI Refinement failed: ${err.message || 'Check model setup'}`);
    }
  };

  const handleSaveCurrent = () => {
    // If it's a pre-built system preset, force user to Save As new project instead of modifying
    const isPreset = PRESET_PROJECTS.some(p => p.id === activeProjectId);
    if (isPreset) {
      setNewProjectName(`${activeProjectName} (Copy)`);
      setShowSaveAsModal(true);
      return;
    }

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + " " + new Date().toLocaleDateString([], { month: 'short', day: 'numeric' });

    // Save directly to active ID with secure fallback fallback insertion if it was missing
    setProjects(prev => {
      const exists = prev.some(p => p.id === activeProjectId);
      if (exists) {
        return prev.map(p => {
          if (p.id === activeProjectId) {
            return {
              ...p,
              html,
              css,
              javascript: js,
              updatedAt: timestamp
            };
          }
          return p;
        });
      } else {
        const fallbackName = activeProjectName || 'Untitled Project';
        const newProjId = activeProjectId || ('user_proj_' + Date.now());
        const newProj: Project = {
          id: newProjId,
          name: fallbackName,
          html,
          css,
          javascript: js,
          updatedAt: timestamp
        };
        return [newProj, ...prev];
      }
    });

    // Clean active states
    setSaveStatus('saved');

    // Register recent activity
    touchProject(activeProjectId);

    // Record version manual checkpoint
    recordVersion('manual', 'Manual Savepoint');

    // Trigger clear feedback confirmation
    triggerLocalFeedback(`Saved "${activeProjectName}" successfully!`);
  };

  const handleSaveAsModalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = newProjectName.trim();
    if (!finalName) return;

    const newId = 'user_proj_' + Date.now();
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + " " + new Date().toLocaleDateString([], { month: 'short', day: 'numeric' });
    const newProj: Project = {
      id: newId,
      name: finalName,
      html,
      css,
      javascript: js,
      updatedAt: timestamp
    };

    setProjects(prev => [newProj, ...prev]);
    setActiveProjectId(newId);
    setActiveProjectName(newProj.name);
    setShowSaveAsModal(false);
    
    // Reset save states to saved
    setSaveStatus('saved');

    // Put to Recents listing
    touchProject(newId);

    // Record initial version
    recordVersion('initial', 'Initial Saved Copy', html, css, js, newId);

    triggerLocalFeedback(`Saved "${newProj.name}" successfully!`);
  };

  const triggerLocalFeedback = (msg: string) => {
    setCopyFeedback(msg);
    setTimeout(() => {
      setCopyFeedback(null);
    }, 2500);
  };

  const deleteUserProject = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent loading it
    setProjects(prev => prev.filter(p => p.id !== id));
    
    // Clean from recent list
    setRecentProjectIds(prev => prev.filter(pId => pId !== id));

    if (activeProjectId === id) {
      setActiveProjectId(INITIAL_PROJECT.id);
      setActiveProjectName(INITIAL_PROJECT.name);
      setHtml(INITIAL_PROJECT.html);
      setCss(INITIAL_PROJECT.css);
      setJs(INITIAL_PROJECT.javascript);
      setTimeout(() => {
        compilePreview();
      }, 100);
    }
  };

  const handleResetWorkspace = () => {
    if (window.confirm("Are you sure you want to reset the active workspace code modules? This resets HTML/CSS/JS to the default blank canvas. Current unsaved inputs will be cleared.")) {
      setHtml(BLANK_TEMPLATE.html);
      setCss(BLANK_TEMPLATE.css);
      setJs(BLANK_TEMPLATE.javascript);
      triggerLocalFeedback("Workspace reverted to blank starter template!");
      setTimeout(() => {
        compilePreview();
      }, 100);
    }
  };

  // Drag Resizer handlers
  const handleDragStart = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    isResizingRef.current = true;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    startDragYRef.current = clientY;
    startHeightRef.current = editorHeight;
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
  };

  useEffect(() => {
    const handleDragMove = (e: MouseEvent | TouchEvent) => {
      if (!isResizingRef.current) return;
      
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const deltaY = clientY - startDragYRef.current;
      const targetHeight = Math.max(180, Math.min(800, startHeightRef.current + deltaY));
      setEditorHeight(targetHeight);
    };

    const handleDragEnd = () => {
      if (isResizingRef.current) {
        isResizingRef.current = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
      }
    };

    window.addEventListener('mousemove', handleDragMove);
    window.addEventListener('mouseup', handleDragEnd);
    window.addEventListener('touchmove', handleDragMove);
    window.addEventListener('touchend', handleDragEnd);

    return () => {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchmove', handleDragMove);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, [editorHeight]);

  // Parameterized generic HTML exporter for compiling modular source templates
  const exportProjectHTML = (proj: Project, customFilename?: string) => {
    const isTailwindActive = proj.useTailwind !== undefined ? proj.useTailwind : useTailwind;
    const isFontAwesomeActive = proj.useFontAwesome !== undefined ? proj.useFontAwesome : useFontAwesome;
    const isGoogleFontsActive = proj.useGoogleFonts !== undefined ? proj.useGoogleFonts : useGoogleFonts;

    const tailwindCdn = isTailwindActive ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
    const fontAwesomeCdn = isFontAwesomeActive ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
    const googleFontsCdn = isGoogleFontsActive ? '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;450;600;800&family=JetBrains+Mono:wght@400;700&display=swap">' : '';

    const combinedFileStr = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${proj.name} - Exported Preview</title>
  ${googleFontsCdn ? '  ' + googleFontsCdn + '\n' : ''}${fontAwesomeCdn ? '  ' + fontAwesomeCdn + '\n' : ''}${tailwindCdn ? '  ' + tailwindCdn + '\n' : ''}  <style>
    /* Custom CSS styled design rules */
    ${proj.css}
  </style>
</head>
<body>
  ${proj.html}
  
  <script>
    /* Custom Interactive JavaScript */
    try {
      ${proj.javascript}
    } catch(e) {
      console.error("Execution error:", e.message);
    }
  </script>
</body>
</html>`;

    const blob = new Blob([combinedFileStr], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = customFilename || `${proj.name.toLowerCase().replace(/\s+/g, '-')}-export.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    triggerLocalFeedback(customFilename ? `Downloaded ${customFilename}!` : `Downloaded HTML file for ${proj.name}!`);
  };

  // Direct export of the active workspace code specifically under "index.html" filename representation
  const handleExportHtmlDirect = () => {
    exportProjectHTML({
      id: activeProjectId,
      name: activeProjectName,
      html,
      css,
      javascript: js,
      useTailwind,
      useFontAwesome,
      useGoogleFonts,
      updatedAt: new Date().toLocaleDateString()
    }, 'index.html');
  };

  // Export Combined Code as raw index.html standalone (active project viewport)
  const exportFullHTML = () => {
    exportProjectHTML({
      id: activeProjectId,
      name: activeProjectName,
      html,
      css,
      javascript: js,
      useTailwind,
      useFontAwesome,
      useGoogleFonts,
      updatedAt: new Date().toLocaleDateString()
    });
  };

  // HTML5 canvas PNG generator for offline PWAs
  const generateAppIconBlob = (size: number, text: string): Promise<Blob> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Linear colored background gradient
        const grad = ctx.createLinearGradient(0, 0, size, size);
        grad.addColorStop(0, '#4f46e5');
        grad.addColorStop(1, '#818cf8');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, size, size);

        // Compass outline circle layout element
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = size * 0.04;
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size * 0.35, 0, Math.PI * 2);
        ctx.stroke();

        // App typography label
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${size * 0.38}px "Inter", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text.slice(0, 2).toUpperCase(), size / 2, size * 0.51);
      }
      canvas.toBlob((blob) => {
        resolve(blob || new Blob());
      }, 'image/png');
    });
  };

  // Parameterized generic .ZIP workspace project archive exporter
  const exportProjectAsZip = async (proj: Project) => {
    try {
      const isTailwindActive = proj.useTailwind !== undefined ? proj.useTailwind : useTailwind;
      const isFontAwesomeActive = proj.useFontAwesome !== undefined ? proj.useFontAwesome : useFontAwesome;
      const isGoogleFontsActive = proj.useGoogleFonts !== undefined ? proj.useGoogleFonts : useGoogleFonts;

      const tailwindCdn = isTailwindActive ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
      const fontAwesomeCdn = isFontAwesomeActive ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
      const googleFontsCdn = isGoogleFontsActive ? '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;450;600;800&family=JetBrains+Mono:wght@400;700&display=swap">' : '';

      const indexHtmlStr = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${proj.name}</title>
  ${googleFontsCdn ? '  ' + googleFontsCdn + '\n' : ''}${fontAwesomeCdn ? '  ' + fontAwesomeCdn + '\n' : ''}${tailwindCdn ? '  ' + tailwindCdn + '\n' : ''}  <link rel="stylesheet" href="style.css">
</head>
<body>
  ${proj.html}
  
  <script src="script.js"></script>
</body>
</html>`;

      const readmeBlob = `# ${proj.name}

This project was built and exported from the AI Preview Sandbox workspace. 

## Files Included
- \`index.html\` - The structured layout containing HTML markup & external CDNs
- \`style.css\` - Custom styled CSS rules matching components
- \`script.js\` - Interactive dynamics, event handlers and console listeners

## Running Locally
To preview your project under local environments, you can serve these files over any simple HTTP utility:

### Option 1: Live Server (VS Code Extension)
Right click \`index.html\` and select **"Open with Live Server"**.

### Option 2: Npx Serve (Node)
\`\`\`bash
npx serve .
\`\`\`

### Option 3: Python Server
\`\`\`bash
python -m http.server 8000
\`\`\`
Then navigate to \`http://localhost:8000\`.`;

      const zip = new JSZip();
      zip.file("index.html", indexHtmlStr);
      zip.file("style.css", proj.css);
      zip.file("script.js", proj.javascript);
      zip.file("README.md", readmeBlob);

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${proj.name.toLowerCase().replace(/\s+/g, '-')}-project.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      triggerLocalFeedback(`Downloaded Project ZIP for ${proj.name}!`);
    } catch (err: any) {
      console.error("Failed to build ZIP file", err);
      triggerLocalFeedback('Error exporting ZIP file!');
    }
  };

  // --- ANDROID PACKAGING ASSISTANT HELPER FUNCTIONS ---
  const analyzeProjectForMobile = () => {
    const hasViewport = html.toLowerCase().includes('name="viewport"') || html.toLowerCase().includes("name='viewport'");
    const hasResponsiveClasses = /sm:|md:|lg:|xl:|flex|grid|flex-col|flex-row|@media|columns-|w-full|max-w-/.test(html + css);
    const touchReadyStyles = /p-\d+|py-\d+|px-\d+|h-\d+|w-\d+|gap-|font-|text-/.test(html + css);
    const touchEventsCount = (html.match(/on\w+=/g) || []).length + (js.match(/click|pointer|touch|tap|addEventListener/g) || []).length;
    
    // Project Type detection
    const lowerHtml = html.toLowerCase();
    const lowerJs = js.toLowerCase();
    
    let detectedType: 'PWA Project' | 'HTML Project' | 'Android Project' = 'HTML Project';
    if (lowerJs.includes('capacitor') || lowerJs.includes('cordova') || lowerHtml.includes('cordova.js') || lowerHtml.includes('capacitor.js')) {
      detectedType = 'Android Project';
    } else if (
      lowerHtml.includes('serviceworker') ||
      lowerHtml.includes('service-worker') ||
      lowerHtml.includes('manifest.json') ||
      lowerHtml.includes('manifest.webmanifest') ||
      lowerJs.includes('serviceworker') ||
      lowerJs.includes('service-worker') ||
      lowerJs.includes('navigator.serviceworker') ||
      lowerJs.includes('register()') ||
      lowerJs.includes('sw.register') ||
      lowerJs.includes('caches.open')
    ) {
      detectedType = 'PWA Project';
    }

    let effectiveType = detectedType;
    if (projectTypeOverride === 'PWA') effectiveType = 'PWA Project';
    else if (projectTypeOverride === 'HTML') effectiveType = 'HTML Project';
    else if (projectTypeOverride === 'Android') effectiveType = 'Android Project';

    const issues = [];
    let score = 0;
    
    if (hasViewport) {
      score += 30;
    } else {
      issues.push({
        id: 'viewport',
        severity: 'high',
        title: 'Missing mobile viewport tag',
        desc: 'Without a viewport tag, mobile browsers will render the page at desktop width and scale it down, making text microscopic.',
        fixable: true
      });
    }
    
    if (hasResponsiveClasses) {
      score += 25;
    } else {
      issues.push({
        id: 'responsive',
        severity: 'medium',
        title: 'No mobile responsive classes or media queries',
        desc: 'The layout might not adapt gracefully to narrow mobile phone screens. Use Tailwind prefixes such as sm: or md: to create fluid columns.',
        fixable: false
      });
    }
    
    if (touchReadyStyles) {
      score += 25;
    } else {
      issues.push({
        id: 'touch_targets',
        severity: 'low',
        title: 'Sparsely sized touch targets',
        desc: 'Mobile buttons and interface controls should have at least 44x44px touch targets to allow comfortable thumb interactions.',
        fixable: false
      });
    }
    
    if (touchEventsCount > 0) {
      score += 20;
    } else {
      issues.push({
        id: 'events',
        severity: 'low',
        title: 'No mobile tap/click actions detected',
        desc: 'We could detect standard click handlers or interactive event listeners in your code sequence. Ensure components respond to touches.',
        fixable: false
      });
    }
    
    return { score, issues, hasViewport, hasResponsiveClasses, touchReadyStyles, touchEventsCount, detectedType, effectiveType };
  };

  const autoFixViewport = () => {
    let updatedHtml = html;
    const viewportTag = '\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">';
    
    if (updatedHtml.toLowerCase().includes('<head>')) {
      updatedHtml = updatedHtml.replace(/<head>/i, `<head>${viewportTag}`);
    } else if (updatedHtml.toLowerCase().includes('<html>')) {
      updatedHtml = updatedHtml.replace(/<html>/i, `<html>\n<head>${viewportTag}\n</head>`);
    } else {
      updatedHtml = `<head>${viewportTag}\n</head>\n` + updatedHtml;
    }
    
    setHtml(updatedHtml);
    triggerLocalFeedback("Injected viewport tag successfully!");
    recordVersion('manual', 'Injected Mobile Viewport Tag', updatedHtml, css, js);
  };

  const generateCapacitorConfig = (appName: string, appId: string) => {
    const cleanAppId = appId.trim() || 'com.example.myapp';
    const cleanAppName = appName.trim() || 'My Mobile App';
    
    return `{
  "appId": "${cleanAppId}",
  "appName": "${cleanAppName}",
  "webDir": "www",
  "bundledWebRuntime": false,
  "server": {
    "androidScheme": "https"
  },
  "plugins": {
    "SplashScreen": {
      "launchShowDuration": 2000,
      "backgroundColor": "#1e1b4b",
      "showSpinner": true,
      "androidSpinnerStyle": "large"
    }
  }
}`;
  };

  const handleDownloadCapacitorZip = async () => {
    try {
      const zip = new JSZip();
      
      const useTailwind = html.includes('tailwindcss') || css.includes('@import "tailwindcss"') || html.includes('cdn.tailwindcss.com') || true;
      const useFontAwesome = html.includes('font-awesome') || html.includes('fontawesome');
      const useGoogleFonts = html.includes('fonts.googleapis.com');
      
      const tailwindCdn = useTailwind ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
      const fontAwesomeCdn = useFontAwesome ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
      const googleFontsCdn = useGoogleFonts ? '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;750;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">' : '';
      
      let formattedHtml = html;
      if (!formattedHtml.toLowerCase().includes('name="viewport"')) {
        formattedHtml = `<meta name="viewport" content="width=device-width, initial-scale=1.0">\n` + formattedHtml;
      }
      
      const bundledHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  ${formattedHtml.toLowerCase().includes('name="viewport"') ? '' : '<meta name="viewport" content="width=device-width, initial-scale=1.0">'}
  <title>${packagerAppName || activeProjectName}</title>
  ${googleFontsCdn}
  ${fontAwesomeCdn}
  ${tailwindCdn}
  <link rel="stylesheet" href="style.css">
</head>
<body class="bg-slate-50 dark:bg-slate-950">
  ${formattedHtml}
  <script src="script.js"></script>
</body>
</html>`;

      zip.file("www/index.html", bundledHtml);
      zip.file("www/style.css", css);
      zip.file("www/script.js", js);
      
      const appId = packagerAppID.trim() || 'com.example.app';
      const appLabel = packagerAppName.trim() || activeProjectName;
      zip.file("capacitor.config.json", generateCapacitorConfig(appLabel, appId));
      
      const pkgJson = {
        "name": appLabel.toLowerCase().replace(/[^a-z0-9_-]/g, '') || "capacitor-custom-app",
        "version": "1.0.0",
        "description": `Android build files for ${appLabel}`,
        "main": "www/index.html",
        "scripts": {
          "cap:copy": "cap copy",
          "cap:sync": "cap sync",
          "android:open": "cap open android"
        },
        "dependencies": {
          "@capacitor/core": "^6.0.0"
        },
        "devDependencies": {
          "@capacitor/cli": "^6.0.0",
          "@capacitor/android": "^6.0.0"
        }
      };
      zip.file("package.json", JSON.stringify(pkgJson, null, 2));
      
      const customReadme = `# ${appLabel} Android Build Package
    
This folder contains the complete Capacitor production integration boilerplate compiled specifically for your sandbox design.

## Project Files
- \`www/\` - Local hybrid web app artifacts. Contains layout indexes, styles sheets and interactivity handlers.
- \`capacitor.config.json\` - Declarative configurations governing bundle IDs, app labels, and directory roots.
- \`package.json\` - Build script orchestrations for quick-sync workflows.

## Fast Track Setup & Compiling APK
Compile this code into an installable APK using your local development system:

### 1. Prerequisite Installations
- Ensure **Node.js** (v18 or above) is configured.
- Ensure **Android Studio** is open (includes Android Software Development Kit - SDK & SDK tools).

### 2. Synchronization workflow
Run these commands in your terminal inside this extracted directory:

1. **Install required compiler dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

2. **Initialize Capacitor and platform layouts:**
   \`\`\`bash
   npx cap init "${appLabel}" "${appId}" --web-dir=www
   npx cap add android
   npx cap sync
   \`\`\`

3. **Open project within Android Studio to build APK:**
   \`\`\`bash
   npx cap open android
   \`\`\`
   
Once Android Studio opens the workspace:
- Wait for gradle build indexes to finish.
- Head to top navigation and choose: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
- The compiled APK is instantly generated for physical device debugging/installing!

### 3. Alternative Terminal APK Compilation
Alternatively, execute build directly through gradle CLI targets if environment PATH is ready:
\`\`\`bash
cd android
./gradlew assembleDebug
\`\`\`
Output APK path: \`android/app/build/outputs/apk/debug/app-debug.apk\``;

      zip.file("BUILD_INSTRUCTIONS.md", customReadme);
      
      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `android-${appLabel.toLowerCase().replace(/\s+/g, '-')}-packager.zip`;
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }, 120);
      
      triggerLocalFeedback("Downloaded complete Capacitor Android build suite!");
    } catch (err: any) {
      console.error("Android bundle packaging failure", err);
      triggerLocalFeedback("Failed packaging Android ZIP archive: " + err.message);
    }
  };

  const generateLauncherIconPng = (text: string, bgColor: string, txtColor: string, size: number, shape: string): Promise<Blob> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve(new Blob());

      ctx.clearRect(0, 0, size, size);

      ctx.fillStyle = bgColor;
      if (shape === 'circle') {
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
        ctx.fill();
      } else if (shape === 'squircle') {
        const r = size * 0.25;
        ctx.beginPath();
        ctx.moveTo(r, 0);
        ctx.lineTo(size - r, 0);
        ctx.quadraticCurveTo(size, 0, size, r);
        ctx.lineTo(size, size - r);
        ctx.quadraticCurveTo(size, size, size - r, size);
        ctx.lineTo(r, size);
        ctx.quadraticCurveTo(0, size, 0, size - r);
        ctx.lineTo(0, r);
        ctx.quadraticCurveTo(0, 0, r, 0);
        ctx.closePath();
        ctx.fill();
      } else {
        const r = size * 0.15;
        ctx.beginPath();
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(0, 0, size, size, r);
        } else {
          ctx.rect(0, 0, size, size);
        }
        ctx.fill();
      }

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = size * 0.04;
      ctx.stroke();

      ctx.fillStyle = txtColor;
      const fontSize = size * 0.45;
      ctx.font = `bold ${fontSize}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
      ctx.shadowBlur = size * 0.05;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = size * 0.03;

      ctx.fillText(text, size / 2, size / 2);

      canvas.toBlob((blob) => {
        resolve(blob || new Blob());
      }, 'image/png');
    });
  };

  const handleDownloadAndroidPlayStoreZip = async () => {
    try {
      setPlayStoreIsCompiling(true);
      setPlayStoreCompileLogs([]);
      setPlayStoreDownloadUrl(null);
      
      const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
      const addLog = (msg: string) => {
        setPlayStoreCompileLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
      };

      addLog("Initializing Play Store WebView wrapper bootstrap... 🤖");
      await sleep(400);
      
      addLog("Analyzing local workspace layout references...");
      const finalAppName = packagerAppName.trim() || activeProjectName;
      const finalAppID = packagerAppID.trim() || "com.company.myapp";
      const cleanNameSafe = finalAppName.toLowerCase().replace(/[^a-z0-9]/g, '') || "webviewapp";
      addLog(`Set target application id to: "${finalAppID}"`);
      addLog(`Set brand label string: "${finalAppName}"`);
      await sleep(300);

      const { effectiveType } = analyzeProjectForMobile();
      if (effectiveType === 'PWA Project') {
        addLog("⚡ [PWA Engine Active] Detected/Selected Progressive Web App (PWA) project blueprint.");
        await sleep(300);
        addLog("🛡️ Skipping Gradlew bundle compilation to enforce secure, offline-first sandbox guidelines.");
        await sleep(300);
        addLog("📦 Bundling high-performance Android-ready PWA package ZIP...");
        await sleep(400);

        const pwaZip = new JSZip();

        addLog("Rendering brand elements and web launcher icons...");
        const icon192 = await generateLauncherIconPng(
          playStoreIconText || "APP",
          playStoreIconBgColor,
          playStoreIconTextColor,
          192,
          playStoreIconShape
        );
        const icon512 = await generateLauncherIconPng(
          playStoreIconText || "APP",
          playStoreIconBgColor,
          playStoreIconTextColor,
          512,
          playStoreIconShape
        );
        pwaZip.file("icon-192.png", icon192);
        pwaZip.file("icon-512.png", icon512);

        addLog("Compiling W3C Web App Manifest configurations (manifest.json)...");
        const manifestStr = `{
  "name": "${finalAppName}",
  "short_name": "${finalAppName.slice(0, 12)}",
  "description": "Progressive Web App build optimized for mobile integration.",
  "start_url": "index.html",
  "display": "standalone",
  "background_color": "${playStoreThemeBg}",
  "theme_color": "${playStoreThemePrimary}",
  "orientation": "any",
  "icons": [
    {
      "src": "icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}`;
        pwaZip.file("manifest.json", manifestStr);

        addLog("Generating offline-first Progressive Web App Service Worker (sw.js)...");
        const cacheName = `${cleanNameSafe}-cache-v1`;
        const swStr = `const CACHE_NAME = "${cacheName}";
const ASSETS = [
  "./",
  "./index.html",
  "./style.css",
  "./script.js",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS);
    })
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return cachedResponse || fetch(event.request);
    })
  );
});`;
        pwaZip.file("sw.js", swStr);

        addLog("Assembling custom viewport markup templates...");
        const pwaUseTailwind = html.includes('tailwindcss') || css.includes('@import "tailwindcss"') || html.includes('cdn.tailwindcss.com') || true;
        const pwaUseFontAwesome = html.includes('font-awesome') || html.includes('fontawesome');
        const pwaUseGoogleFonts = html.includes('fonts.googleapis.com');

        const tailwindCdn = pwaUseTailwind ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
        const fontAwesomeCdn = pwaUseFontAwesome ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
        const googleFontsCdn = pwaUseGoogleFonts ? '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;450;600;800&family=JetBrains+Mono:wght@400;700&display=swap">' : '';

        const webIndexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>${finalAppName}</title>
  
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="${playStoreThemePrimary}">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <link rel="apple-touch-icon" href="icon-192.png">

  ${googleFontsCdn}
  ${fontAwesomeCdn}
  ${tailwindCdn}
  <link rel="stylesheet" href="style.css">
</head>
<body class="bg-slate-950 text-slate-100">
  ${html}
  <script src="script.js"></script>
  
  <script>
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("sw.js")
          .then((reg) => console.log("Service Worker registered successfully! scope:", reg.scope))
          .catch((err) => console.log("Service Worker registration failed:", err));
      });
    }
  </script>
</body>
</html>`;
        pwaZip.file("index.html", webIndexHtml);
        pwaZip.file("style.css", css);
        pwaZip.file("script.js", js);

        addLog("Injecting detailed cloud packaging deployment resources...");
        const readMeStr = `# ${finalAppName} - Android Ready PWA Package

This lightweight package is engineered to deliver an ultra-optimized Progressive Web App (PWA) on Android devices.

## Package Architecture
- **Responsive Layout**: Fluid bounds optimized dynamically for Android WebView, tablets, and mobile phone viewports.
- **Dynamic Icons**: High-DPI maskable icons generated during compilation.
- **Offline Cache**: Robust service worker offline asset loader cache rules.

## Store Publishing Quick guides:
To convert this PWA directly into an APK/AAB for publishing inside Google Play Store, we recommend using:
1. **PWABuilder** (https://www.pwabuilder.com/): An open-source workspace backed by Microsoft that compiles this ZIP folder into production-ready Android APK and Google Play Store AAB files in under a minute!
2. **Bubblewrap CLI**: Command line utilities from Google Chrome engineers:
   \`npx @bubblewrap/cli init --manifest=manifest.json\`
`;
        pwaZip.file("ANDROID_PWA_READY_GUIDE.md", readMeStr);

        addLog("Compressing Android-ready PWA workspace archives...");
        const zipContent = await pwaZip.generateAsync({ type: "blob" });
        const dlUrl = URL.createObjectURL(zipContent);
        const dlFilename = `android-ready-pwa-${cleanNameSafe}.zip`;

        setPlayStoreDownloadUrl(dlUrl);
        setPlayStoreDownloadFilename(dlFilename);

        addLog("✨ Successful compilation! High-performance Android-ready PWA package ZIP is ready to download.");
        setPlayStoreIsCompiling(false);
        triggerLocalFeedback("PWA project packaged successfully! Ready for download.");
        return;
      }

      const zip = new JSZip();

      addLog("Auto-rendering launcher icons at multi-DPI resolutions...");
      const iconSizes = [
        { name: 'mdpi', size: 48 },
        { name: 'hdpi', size: 72 },
        { name: 'xhdpi', size: 96 },
        { name: 'xxhdpi', size: 144 },
        { name: 'xxxhdpi', size: 192 }
      ];

      for (const item of iconSizes) {
        const logoBlob = await generateLauncherIconPng(
          playStoreIconText || "APP",
          playStoreIconBgColor,
          playStoreIconTextColor,
          item.size,
          playStoreIconShape
        );
        zip.file(`app/src/main/res/mipmap-${item.name}/ic_launcher.png`, logoBlob);
        zip.file(`app/src/main/res/mipmap-${item.name}/ic_launcher_round.png`, logoBlob);
      }
      
      addLog("Rendering 512x512 adaptive Google Play Store promotional listing emblem...");
      const storeLogoBlob = await generateLauncherIconPng(
        playStoreIconText || "APP",
        playStoreIconBgColor,
        playStoreIconTextColor,
        512,
        playStoreIconShape
      );
      zip.file(`PLAY_STORE_CONVERTER_ICON_512.png`, storeLogoBlob);
      zip.file(`app/src/main/res/drawable/splash_logo.png`, storeLogoBlob);
      await sleep(400);

      addLog("Compiling XML resource configuration rules...");
      
      const stringsXml = `<resources>
    <string name="app_name">${finalAppName}</string>
</resources>`;
      zip.file("app/src/main/res/values/strings.xml", stringsXml);

      const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">${playStoreThemePrimary}</color>
    <color name="colorPrimaryDark">${playStoreThemeBg}</color>
    <color name="colorAccent">${playStoreThemePrimary}dd</color>
    <color name="splash_background">${playStoreThemeBg}</color>
    <color name="window_background">${playStoreThemeBg}</color>
</resources>`;
      zip.file("app/src/main/res/values/colors.xml", colorsXml);

      const themesXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.WebViewApp" parent="Theme.AppCompat.DayNight">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
        <item name="colorAccent">@color/colorAccent</item>
    </style>
    
    <style name="Theme.WebViewApp.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="android:windowBackground">@color/window_background</item>
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowActionBar">false</item>
    </style>

    <style name="Theme.WebViewApp.NoActionBar.Fullscreen" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="android:windowFullscreen">true</item>
        <item name="android:windowContentOverlay">@null</item>
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowActionBar">false</item>
    </style>
</resources>`;
      zip.file("app/src/main/res/values/themes.xml", themesXml);

      const backupRulesXml = `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
</full-backup-content>`;
      zip.file("app/src/main/res/xml/backup_rules.xml", backupRulesXml);

      const dataExtractionRulesXml = `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="sharedpref" path="."/>
    </cloud-backup>
    <device-transfer>
        <include domain="sharedpref" path="."/>
    </device-transfer>
</data-extraction-rules>`;
      zip.file("app/src/main/res/xml/data_extraction_rules.xml", dataExtractionRulesXml);

      const activityMainLayout = `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/window_background">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</androidx.constraintlayout.widget.ConstraintLayout>`;
      zip.file("app/src/main/res/layout/activity_main.xml", activityMainLayout);

      const activitySplashLayout = `<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/splash_background"
    android:gravity="center">

    <ImageView
        android:id="@+id/splash_logo"
        android:layout_width="140dp"
        android:layout_height="140dp"
        android:contentDescription="@string/app_name"
        android:src="@drawable/splash_logo" />
</RelativeLayout>`;
      zip.file("app/src/main/res/layout/activity_splash.xml", activitySplashLayout);

      addLog("Assembling AndroidManifest structural configurations...");
      const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.WebViewApp"
        tools:targetApi="31">
        
        <activity
            android:name=".SplashActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.WebViewApp.NoActionBar.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".MainActivity"
            android:exported="false"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:theme="@style/Theme.WebViewApp.NoActionBar">
        </activity>
    </application>
</manifest>`;
      zip.file("app/src/main/AndroidManifest.xml", manifestXml);
      await sleep(300);

      addLog("Weaving full-screen immersive and backbutton-redirected Java controllers...");
      const packagePath = finalAppID.replace(/\./g, '/');

      const mainActivityJava = `package ${finalAppID};

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {

    private WebView myWebView;
    private ValueCallback<Uri[]> uploadMessage;
    private final static int FILECHOOSER_RESULTCODE = 1;

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        
        ${playStoreIsImmersive ? `if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = 
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );` : ''}

        setContentView(R.layout.activity_main);

        myWebView = findViewById(R.id.webview);

        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);

        ${playStoreIsHardwareAccelerated ? `myWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);` : ''}

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (url.contains("appassets.androidplatform.net")) {
                        return false;
                    }
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        myWebView.setWebChromeClient(new WebChromeClient() {
            public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback,
                    WebChromeClient.FileChooserParams fileChooserParams) {
                if (uploadMessage != null) {
                    uploadMessage.onReceiveValue(null);
                    uploadMessage = null;
                }
                uploadMessage = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILECHOOSER_RESULTCODE);
                } catch (Exception e) {
                    uploadMessage = null;
                    return false;
                }
                return true;
            }
        });

        myWebView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == FILECHOOSER_RESULTCODE) {
            if (uploadMessage == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && intent != null) {
                String dataString = intent.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
            uploadMessage.onReceiveValue(results);
            uploadMessage = null;
        }
    }

    @Override
    public void onBackPressed() {
        ${playStoreIsBackButtonIntercepted ? `if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            super.onBackPressed();
        }` : 'super.onBackPressed();'}
    }
}`;
      zip.file(`app/src/main/java/${packagePath}/MainActivity.java`, mainActivityJava);

      const splashActivityJava = `package ${finalAppID};

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
                
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 1800);
    }
}`;
      zip.file(`app/src/main/java/${packagePath}/SplashActivity.java`, splashActivityJava);
      await sleep(400);

      addLog("Generating multi-module Gradle and dependencies compile scripts...");
      
      const rootBuildGradle = `plugins {
    id 'com.android.application' version '8.2.0' apply false
}`;
      zip.file("build.gradle", rootBuildGradle);

      const appBuildGradle = `plugins {
    id 'com.android.application'
}

android {
    namespace "${finalAppID}"
    compileSdk 34

    defaultConfig {
        applicationId "${finalAppID}"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

configurations.all {
    resolutionStrategy {
        force 'org.jetbrains.kotlin:kotlin-stdlib:1.8.22'
        force 'org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.22'
        force 'org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.22'
    }
    exclude group: "org.jetbrains.kotlin", module: "kotlin-stdlib-jdk7"
    exclude group: "org.jetbrains.kotlin", module: "kotlin-stdlib-jdk8"
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.webkit:webkit:1.9.0'
}`;
      zip.file("app/build.gradle", appBuildGradle);

      const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${cleanNameSafe}"
include ':app'`;
      zip.file("settings.gradle", settingsGradle);

      zip.file("gradle/wrapper/gradle-wrapper.properties", `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists`);

      zip.file("gradlew", `#!/usr/bin/env sh
# Automated gradlew bootstrap script
exec "./gradle/wrapper/gradle-wrapper.properties" "$@"`);
      zip.file("gradlew.bat", `@rem Automated Windows gradlew bootstrap`);

      addLog("Bundling active PWA web app assets inside assets/www/ directory...");
      const useTailwind = html.includes('tailwindcss') || css.includes('@import "tailwindcss"') || html.includes('cdn.tailwindcss.com') || true;
      const useFontAwesome = html.includes('font-awesome') || html.includes('fontawesome');
      const useGoogleFonts = html.includes('fonts.googleapis.com');
      
      const tailwindCdn = useTailwind ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
      const fontAwesomeCdn = useFontAwesome ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
      const googleFontsCdn = useGoogleFonts ? '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;750;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">' : '';
      
      let formattedHtml = html;
      if (!formattedHtml.toLowerCase().includes('name="viewport"')) {
        formattedHtml = `<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">\n` + formattedHtml;
      }

      const webIndexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>${finalAppName}</title>
  ${googleFontsCdn}
  ${fontAwesomeCdn}
  ${tailwindCdn}
  
  <style>
    body {
      -webkit-touch-callout: none;
      -webkit-user-select: none;
      user-select: none;
      overflow: hidden;
      position: fixed;
      width: 100%;
      height: 100%;
    }
    input, textarea {
      -webkit-user-select: auto !important;
      user-select: auto !important;
    }
  </style>

  <link rel="stylesheet" href="style.css">
</head>
<body class="bg-slate-950 text-slate-100">
  ${formattedHtml}
  <script src="script.js"></script>
</body>
</html>`;

      zip.file("app/src/main/assets/www/index.html", webIndexHtml);
      zip.file("app/src/main/assets/www/style.css", css);
      zip.file("app/src/main/assets/www/script.js", js);
      await sleep(350);

      if (playStoreGithubActionsWorkflow) {
        addLog(`Configuring cloud compilation workflow (.github/workflows/${githubWorkflow || 'android-build.yml'})...`);
        const workflowConfigContent = `name: Build Google Play Store App

on:
  push:
    branches: [ "main" ]
  workflow_dispatch:

jobs:
  build:
    name: Compile Android App
    runs-on: ubuntu-latest

    steps:
    - name: Checkout Repository
      uses: actions/checkout@v4

    - name: Set up Node.js
      uses: actions/setup-node@v4
      with:
        node-version: 20

    - name: Detect and Setup Project
      id: setup_project
      run: |
        if [ -f "gradlew" ]; then
          echo "PROJECT_TYPE=native-android" >> $GITHUB_ENV
          echo "Detected native Android project."
        elif [ -f "android/gradlew" ]; then
          echo "PROJECT_TYPE=existing-capacitor" >> $GITHUB_ENV
          echo "Detected existing Capacitor Android project."
        else
          echo "PROJECT_TYPE=html-pwa" >> $GITHUB_ENV
          echo "Detected HTML/PWA project. Building Capacitor Android wrapper..."
          
          # Initialize package.json if not present
          if [ ! -f "package.json" ]; then
            npm init -y
          fi
          
          # Install Capacitor CLI, core, and Android platform
          npm install @capacitor/core @capacitor/cli @capacitor/android
          
          # Prepare static web assets directory
          mkdir -p www
          
          # Copy static files to web assets directory, avoiding copying the www directory into itself
          find . -maxdepth 1 -type f -not -name "package.json" -not -name "package-lock.json" -not -name "yarn.lock" -not -name "package-lock.json" -exec cp {} www/ \; || true
          
          # Copy separate directories if present
          for dir in assets images css js static; do
            if [ -d "$dir" ] && [ "$dir" != "www" ]; then
              cp -r "$dir" www/ || true
            fi
          done
          
          # Create default capacitor.config.json if not exists
          if [ ! -f "capacitor.config.json" ]; then
            echo '{"appId": "com.pwa.app", "appName": "Applet", "webDir": "www", "bundledWebRuntime": false}' > capacitor.config.json
          fi
          
          # Initialize and sync Capacitor platform
          npx cap init "Applet" "com.pwa.app" --web-dir=www || true
          npx cap add android || true
          npx cap sync android
        fi

    - name: Audit and Refactor Kotlin Gradle dependencies
      run: |
        echo "Solving duplicate class conflicts by enforcing strict compilation strategies..."
        find . -name "build.gradle" -not -path "*/node_modules/*" | while read -r gradle_file; do
          echo "Patching \$gradle_file..."
          cat << 'EOF' >> "\$gradle_file"

// Automated Kotlin standard library duplicate class conflict resolution
allprojects {
    configurations.all {
        resolutionStrategy {
            force 'org.jetbrains.kotlin:kotlin-stdlib:1.8.22'
            force 'org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.22'
            force 'org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.22'
        }
        exclude group: "org.jetbrains.kotlin", module: "kotlin-stdlib-jdk7"
        exclude group: "org.jetbrains.kotlin", module: "kotlin-stdlib-jdk8"
    }
}
EOF
        done

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: gradle

    - name: Compile and Package App using Gradle
      run: |
        if [ "\${{ env.PROJECT_TYPE }}" = "native-android" ]; then
          chmod +x gradlew
          ./gradlew assembleDebug
          ./gradlew bundleRelease
        elif [ "\${{ env.PROJECT_TYPE }}" = "existing-capacitor" ] || [ "\${{ env.PROJECT_TYPE }}" = "html-pwa" ]; then
          chmod +x android/gradlew
          cd android
          ./gradlew assembleDebug
          ./gradlew bundleRelease
          cd ..
        else
          echo "Unknown build environment type."
          exit 1
        fi

    - name: Prepare Artifacts for Upload
      run: |
        mkdir -p tmp-apk tmp-aab
        
        # Locate APK and copy it to tmp-apk
        APK_FILE=\$(find . -name "*.apk" -not -path "*/node_modules/*" | head -n 1)
        if [ -n "\$APK_FILE" ]; then
          cp "\$APK_FILE" tmp-apk/app-debug.apk
          echo "Successfully copied APK: \$APK_FILE"
        else
          echo "ERROR: No compiled APK found!" >&2
          exit 1
        fi
        
        # Locate AAB and copy it to tmp-aab
        AAB_FILE=\$(find . -name "*.aab" -not -path "*/node_modules/*" | head -n 1)
        if [ -n "\$AAB_FILE" ]; then
          cp "\$AAB_FILE" tmp-aab/app-release.aab
          echo "Successfully copied AAB: \$AAB_FILE"
        else
          echo "ERROR: No compiled AAB found!" >&2
          exit 1
        fi

    - name: Upload Debug APK Binary
      uses: actions/upload-artifact@v4
      with:
        name: play-ready-debug-apk
        path: tmp-apk/app-debug.apk

    - name: Upload Release Play Store Bundle (AAB)
      uses: actions/upload-artifact@v4
      with:
        name: play-ready-release-aab
        path: tmp-aab/app-release.aab`;
        zip.file(`.github/workflows/${githubWorkflow || 'android-build.yml'}`, workflowConfigContent);
      }

      const buildReadme = `# ${finalAppName} - Android Play Store Container Project

This folder contains your standalone native Android app codebase wrapping your interactive web workspace inside a customized WebView container. It is optimized for the **Google Play Store**.

## Architecture & Optimizations:
- **Immersive View**: Full screen layout completely hiding system and navigation status bars.
- **Hardware Accelerated**: Native UI hardware acceleration enabled for smooth WebGL/CSS interactions.
- **CORS/AJAX Protection**: Integrated modern \`WebViewAssetLoader\` which loads assets over a secure mock origin \`https://appassets.androidplatform.net/assets/www/\`. This supports XMLHttpRequests, Fetch, and service worker cookies perfectly!
- **Auto-Icons**: Multi-DPI launchers automatically scaled and injected under \`mipmap-*dpi\` directories.
- **Activity Overrides**: SplashActivity routes to optimized MainActivity, carrying back button triggers and image upload dialog bindings.

## How to build locally in Android Studio:
1. Open up **Android Studio**.
2. Choose **"Open an Existing Project"** and select this directory root.
3. Gradle will index and download dependencies automatically (requires JDK 17).
4. Run compiling: **Build > Build Bundle(s) / APK(s) > Build APK(s)** for immediate debug, or select **Generate Signed Bundle / APK** for publishing!

## Build via Terminal:
\`^^^cmd
chmod +x gradlew
./gradlew assembleDebug   # For APK
./gradlew bundleRelease   # For Play Store AAB
\`^^^

## Build automatically in the Cloud (Free via GitHub):
1. Push this entire extracted directory structure into a clean **GitHub repository**.
2. Open the **Actions** tab of your repository.
3. The integrated GitHub Workflow will automatically run and build both **app-debug.apk** and **app-release.aab** inside 3 minutes, ready for you to download on the Actions run summary page!`;
      zip.file("PLAY_STORE_BUILD_GUIDE.md", buildReadme.replace(/\^\^\^/g, '```'));

      addLog("Compressing project workspace archives...");
      const zipContent = await zip.generateAsync({ type: "blob" });
      const dlUrl = URL.createObjectURL(zipContent);
      const dlFilename = `android-${cleanNameSafe}-playstore.zip`;

      setPlayStoreDownloadUrl(dlUrl);
      setPlayStoreDownloadFilename(dlFilename);

      addLog("✨ Ready! Complete Play Store gradle suite successfully compiled.");
      setPlayStoreIsCompiling(false);
      triggerLocalFeedback("AAB & APK project build layouts generated!");
    } catch (err: any) {
      console.error(err);
      setPlayStoreIsCompiling(false);
      setPlayStoreCompileLogs(prev => [...prev, `[✖ ERROR] Compile error: ${err.message}`]);
      triggerLocalFeedback("Failed compiling Play Store bundle: " + err.message);
    }
  };

  // ZIP exporter compiling code into modular structured archives (active project viewport)
  const exportAsZip = async () => {
    await exportProjectAsZip({
      id: activeProjectId,
      name: activeProjectName,
      html,
      css,
      javascript: js,
      useTailwind,
      useFontAwesome,
      useGoogleFonts,
      updatedAt: new Date().toLocaleDateString()
    });
  };

  // PWA Exporter compiling comprehensive custom templates and service workers
  const exportAsPWA = async () => {
    try {
      const tailwindCdn = useTailwind ? '<script src="https://cdn.tailwindcss.com"></script>' : '';
      const fontAwesomeCdn = useFontAwesome ? '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">' : '';
      const googleFontsCdn = useGoogleFonts ? '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;450;600;800&family=JetBrains+Mono:wght@400;700&display=swap">' : '';

      const baseName = activeProjectName || "Sandbox PWA";

      const indexHtmlStr = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${baseName}</title>
  
  <!-- PWA Capabilities meta tags -->
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="#4f46e5">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <link rel="apple-touch-icon" href="icon-192.png">

  ${googleFontsCdn ? '  ' + googleFontsCdn + '\n' : ''}${fontAwesomeCdn ? '  ' + fontAwesomeCdn + '\n' : ''}${tailwindCdn ? '  ' + tailwindCdn + '\n' : ''}  <link rel="stylesheet" href="style.css">
</head>
<body>
  ${html}
  
  <script src="script.js"></script>
  
  <!-- Register PWA Service Worker -->
  <script>
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("sw.js")
          .then((reg) => console.log("Service Worker registered successfully! scope:", reg.scope))
          .catch((err) => console.log("Service Worker registration failed:", err));
      });
    }
  </script>
</body>
</html>`;

      const manifestStr = `{
  "name": "${baseName}",
  "short_name": "${baseName.slice(0, 12)}",
  "description": "Progressive Web App build exported from AI Preview Sandbox.",
  "start_url": "index.html",
  "display": "standalone",
  "background_color": "#0b0f19",
  "theme_color": "#4f46e5",
  "orientation": "any",
  "icons": [
    {
      "src": "icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}`;

      const swStr = `const CACHE_NAME = "${baseName.toLowerCase().replace(/\s+/g, '-')}-cache-v1";
const ASSETS = [
  "./",
  "./index.html",
  "./style.css",
  "./script.js",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS);
    })
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return cachedResponse || fetch(event.request);
    })
  );
});`;

      const readmeBlob = `# ${baseName} PWA Package

This bundle is a fully compliant **Progressive Web App (PWA)** exported from your AI Preview Sandbox workspace.

## Included Files
- \`index.html\` - Web page structure linked to styles, scripts, service worker, and the web manifest
- \`style.css\` - Main custom style sheets
- \`script.js\` - Interactive dynamics client-side instructions
- \`manifest.json\` - PWA Web Manifest outlining display settings, color schemes, and icon specs
- \`sw.js\` - Service Worker script facilitating dynamic local offline resource caching
- \`icon-192.png\` - App Icon, designed and generated on export (192px width)
- \`icon-512.png\` - High-resolution deployment Icon (512px width)

## Running Your PWA Offline
Because browsers require a secure origin for PWAs, you must serve this folder over **HTTPS** or **localhost**:

### Local Preview (Quickest)
1. Run a local server from this directory:
   \`\`\`bash
   npx serve .
   \`\`\`
2. Open \`http://localhost:3000\` (or whichever port is assigned) in your web browser.
3. Observe the install icon (usually in the browser address bar or menu) to install your web app natively on your computer or mobile device!

### Production Deployment
Upload these files folder-flat into any static hosting service (Netlify, Vercel, Firebase Hosting, GitHub Pages) supporting secure HTTPS connections to run the offline capacities in full.`;

      // Draw custom app icons based on active title short-name
      const initialText = baseName.slice(0, 2).trim() || 'SB';
      const icon192Blob = await generateAppIconBlob(192, initialText);
      const icon512Blob = await generateAppIconBlob(512, initialText);

      const zip = new JSZip();
      zip.file("index.html", indexHtmlStr);
      zip.file("style.css", css);
      zip.file("script.js", js);
      zip.file("manifest.json", manifestStr);
      zip.file("sw.js", swStr);
      zip.file("icon-192.png", icon192Blob);
      zip.file("icon-512.png", icon512Blob);
      zip.file("README.md", readmeBlob);

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${baseName.toLowerCase().replace(/\s+/g, '-')}-pwa.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      triggerLocalFeedback('Downloaded PWA Offline Package!');
    } catch (err: any) {
      console.error("Failed to build PWA Package", err);
      triggerLocalFeedback('Error generating PWA Package!');
    }
  };

  // Helper copy content action
  const copyCurrentCode = () => {
    let sourceText = '';
    const tabLabel = selectedTab === 'html' ? 'HTML Tab' : selectedTab === 'css' ? 'CSS Tab' : 'JavaScript Tab';
    if (selectedTab === 'html') sourceText = html;
    else if (selectedTab === 'css') sourceText = css;
    else if (selectedTab === 'javascript') sourceText = js;

    navigator.clipboard.writeText(sourceText).then(() => {
      triggerLocalFeedback(`Copied ${tabLabel} contents to clipboard!`);
    });
  };

  // Dynamic lines array calculator
  const getLineNumbersArray = (val: string) => {
    const count = val.split('\n').length;
    return Array.from({ length: Math.max(1, count) }, (_, idx) => idx + 1);
  };

  const activeValue = selectedTab === 'html' ? html : selectedTab === 'css' ? css : js;
  const setActiveValue = selectedTab === 'html' ? setHtml : selectedTab === 'css' ? setCss : setJs;

  return (
    <div id="code_preview_root" className={`min-h-screen transition-colors duration-300 font-sans ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      
      {/* Toast Feedback notifications */}
      <AnimatePresence>
        {copyFeedback && (
          <motion.div 
            id="toast_feedback"
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 16, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, y: -20 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-indigo-600 text-white font-semibold text-xs py-3 px-6 rounded-full shadow-2xl tracking-wide border border-indigo-400"
          >
            <Sparkles className="w-4 h-4 animate-bounce text-yellow-300" />
            <span>{copyFeedback}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Redesigned Premium Top Navigation Bar */}
      <header id="app_header" className={`border-b px-4 py-2.5 flex items-center justify-between gap-4 transition-all duration-300 relative z-40 ${isDarkMode ? 'bg-slate-900/95 border-slate-800' : 'bg-white border-slate-200'}`}>
        {/* Left Side: Brand & Workspace Selector */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-indigo-650 via-purple-600 to-pink-505 flex items-center justify-center text-white shadow-md shadow-indigo-500/10 hover:scale-105 transition-all shrink-0">
            <Sparkles className="w-4 sm:w-4.5 h-4 sm:h-4.5 stroke-[2.5]" />
          </div>

          {/* Universal Multi-Menu Bar (File, Templates, AI, Tools, Settings) */}
          <div className="flex items-center gap-1 sm:gap-1.5 border-l pl-1.5 sm:pl-3 border-slate-200 dark:border-slate-800 relative z-40" id="container_multi_menu">
            
            {/* FILE MENU */}
            <div className="relative inline-block" id="container_file_menu">
              <button
                id="btn_file_menu_trigger"
                onClick={() => setActiveMenuDropdown(activeMenuDropdown === 'file' ? null : 'file')}
                className={`relative z-20 flex items-center gap-1.5 px-3 py-1.5 select-none rounded-lg font-bold text-[11px] sm:text-xs transition-colors cursor-pointer ${
                  activeMenuDropdown === 'file'
                    ? 'bg-indigo-600 text-white font-extrabold shadow-sm'
                    : isDarkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <FolderOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span>File</span>
                <ChevronDown className={`hidden sm:inline-block w-3 h-3 transition-transform ${activeMenuDropdown === 'file' ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {activeMenuDropdown === 'file' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 5 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 5 }}
                    className={`absolute left-0 mt-1.5 w-60 rounded-xl shadow-xl p-2 z-50 border ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100 shadow-black/80' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setNewProjectNameVal(''); setNewProjectTemplate('blank'); setShowNewProjectModal(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <PlusCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>New Project</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setShowLoadPanel(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <FolderOpen className="w-4 h-4 text-sky-400 shrink-0" />
                        <span>Open Project</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); handleSaveCurrent(); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Save className="w-4 h-4 text-indigo-400 shrink-0" />
                        <span>Save</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setNewProjectName(`${activeProjectName} (Copy)`); setShowSaveAsModal(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Copy className="w-4 h-4 text-slate-400 shrink-0" />
                        <span>Save As...</span>
                      </button>
                      
                      {/* Divider for clean separation */}
                      <div className="h-px bg-slate-100 dark:bg-slate-800 my-1"></div>

                      {/* Export expands inline */}
                      <div className="flex flex-col">
                        <button
                          onClick={() => setExportExpanded(!exportExpanded)}
                          className={`flex items-center justify-between w-full px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                        >
                          <div className="flex items-center gap-2.5">
                            <Download className="w-4 h-4 text-purple-400 shrink-0" />
                            <span>Export</span>
                          </div>
                          <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${exportExpanded ? 'rotate-180' : ''}`} />
                        </button>
                        
                        <AnimatePresence>
                          {exportExpanded && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="overflow-hidden pl-4 flex flex-col gap-0.5 mt-0.5 border-l border-slate-100 dark:border-slate-800 ml-5"
                            >
                              <button
                                onClick={() => { setActiveMenuDropdown(null); handleExportHtmlDirect(); }}
                                className={`flex items-center gap-2 px-2 py-1.5 text-[11px] font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-850 text-slate-300 hover:text-white' : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'}`}
                              >
                                <FileCode className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                                <span>Export Static HTML</span>
                              </button>
                              <button
                                onClick={() => { setActiveMenuDropdown(null); exportAsZip(); }}
                                className={`flex items-center gap-2 px-2 py-1.5 text-[11px] font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-850 text-slate-300 hover:text-white' : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'}`}
                              >
                                <Archive className="w-3.5 h-3.5 text-sky-450 text-sky-400 shrink-0" />
                                <span>Export Modular ZIP</span>
                              </button>
                              <button
                                onClick={() => { setActiveMenuDropdown(null); exportAsPWA(); }}
                                className={`flex items-center gap-2 px-2 py-1.5 text-[11px] font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-850 text-slate-300 hover:text-white' : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'}`}
                              >
                                <Archive className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                                <span>Export PWA App (ZIP)</span>
                              </button>
                              <button
                                onClick={handleAndroidPlayStoreAuditAndBuild}
                                className={`flex items-center gap-2 px-2 py-1.5 text-[11px] font-bold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-850 text-emerald-300 hover:text-white' : 'hover:bg-slate-100 text-emerald-600 hover:text-emerald-750'}`}
                              >
                                <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                <span>Android App (Play Store Ready)</span>
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* TEMPLATES MENU */}
            <div className="relative inline-block" id="container_templates_menu">
              <button
                id="btn_templates_menu_trigger"
                onClick={() => setActiveMenuDropdown(activeMenuDropdown === 'templates' ? null : 'templates')}
                className={`relative z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-colors cursor-pointer select-none ${
                  activeMenuDropdown === 'templates'
                    ? 'bg-indigo-600 text-white font-extrabold shadow-sm'
                    : isDarkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Cpu className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Templates</span>
                <ChevronDown className="hidden sm:inline-block w-3 h-3 transition-transform" />
              </button>
              <AnimatePresence>
                {activeMenuDropdown === 'templates' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 5 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 5 }}
                    className={`absolute left-0 mt-1.5 w-[calc(100vw-24px)] xs:w-80 sm:w-[380px] rounded-2xl shadow-xl p-3 z-50 border flex flex-col gap-2.5 ${
                      isDarkMode 
                        ? 'bg-slate-900 border-slate-800 text-slate-100 shadow-black/80' 
                        : 'bg-white border-slate-205 text-slate-800 shadow-slate-200'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between border-b pb-1.5 border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-1.5">
                        <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">Templates Depot</span>
                      </div>
                      <span className="text-[9px] font-mono bg-cyan-500/10 text-cyan-400 px-1.5 py-0.5 rounded font-bold">
                        {PRESET_PROJECTS.length} Items
                      </span>
                    </div>

                    {/* App Category Filter Tabs inside dropdown */}
                    <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none select-none shrink-0 border-b border-slate-100 dark:border-slate-800" onClick={(e) => e.stopPropagation()}>
                      {[
                        "All Apps",
                        "Games & Fun",
                        "Utility Tools",
                        "Interactive Visuals",
                        "Productivity Apps"
                      ].map(cat => (
                        <button
                          key={cat}
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setActiveCategory(cat);
                          }}
                          className={`text-[9.5px] px-2.5 py-1 rounded-full font-bold whitespace-nowrap transition-all cursor-pointer ${
                            activeCategory === cat
                              ? 'bg-indigo-600 text-white shadow-sm font-extrabold'
                              : isDarkMode 
                                ? 'bg-slate-800/80 text-slate-400 border border-slate-850 hover:bg-slate-800' 
                                : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200/60'
                          }`}
                        >
                          {cat === "All Apps" ? "All" : cat.split(' ')[0]}
                        </button>
                      ))}
                    </div>

                    {/* Scrollable Templates lists inside dropdown */}
                    <div className="max-h-[260px] overflow-y-auto space-y-1 pr-0.5" onClick={(e) => e.stopPropagation()}>
                      {PRESET_PROJECTS
                        .filter(p => activeCategory === 'All Apps' || p.category === activeCategory)
                        .map(preset => {
                          const isCurrentActive = activeProjectId === preset.id;
                          return (
                            <button
                              key={preset.id}
                              onClick={() => {
                                loadProject(preset);
                                setActiveMenuDropdown(null);
                              }}
                              className={`w-full p-2 rounded-lg cursor-pointer border transition-all text-left flex items-center gap-2.5 group relative overflow-hidden ${
                                isCurrentActive
                                  ? 'border-indigo-400 bg-indigo-500/5'
                                  : isDarkMode 
                                    ? 'border-slate-800/80 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-950' 
                                    : 'border-slate-200 bg-slate-50 hover:bg-white hover:border-slate-300 hover:shadow-xs'
                              }`}
                            >
                              <div className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 ${
                                preset.category === 'Games & Fun' ? 'bg-fuchsia-500/15 text-fuchsia-400' :
                                preset.category === 'Productivity Apps' ? 'bg-indigo-500/15 text-indigo-400' :
                                preset.category === 'Utility Tools' ? 'bg-yellow-500/15 text-yellow-400' : 'bg-cyan-500/15 text-cyan-400'
                              }`}>
                                <Cpu className="w-3 h-3 stroke-[2]" />
                              </div>

                              <div className="flex-grow min-w-0">
                                <div className="font-bold text-[11px] truncate group-hover:text-indigo-400 transition-colors">
                                  {preset.name}
                                </div>
                                <div className="text-[9px] text-slate-400 font-mono truncate leading-none mt-0.5">
                                  {preset.category || 'Visuals'}
                                </div>
                              </div>

                              <ChevronRight className="w-3 h-3 text-slate-500 group-hover:translate-x-0.5 transition-all shrink-0" />
                            </button>
                          );
                        })}
                    </div>

                    {/* Bottom Browse Gallery trigger */}
                    <div className="border-t pt-1.5 border-slate-100 dark:border-slate-800" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setShowTemplatesGallery(true); }}
                        className={`w-full flex items-center justify-center gap-1 py-1.5 text-[11px] font-bold rounded-lg transition-all ${
                          isDarkMode ? 'bg-slate-800/80 hover:bg-slate-800 text-indigo-400 hover:text-indigo-300' : 'bg-slate-100 hover:bg-slate-200 text-indigo-600 hover:text-indigo-700'
                        }`}
                      >
                        <Sparkles className="w-3 h-3 animate-pulse text-indigo-400" />
                        <span>Open Advanced Gallery Dialog</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* AI TOOLS MENU */}
            <div className="relative inline-block" id="container_ai_menu">
              <button
                id="btn_ai_menu_trigger"
                onClick={() => setActiveMenuDropdown(activeMenuDropdown === 'ai' ? null : 'ai')}
                className={`relative z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-colors cursor-pointer select-none ${
                  activeMenuDropdown === 'ai'
                    ? 'bg-indigo-650 bg-indigo-600 text-white font-extrabold'
                    : isDarkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>AI Tools</span>
                <ChevronDown className="hidden sm:inline-block w-3 h-3 transition-transform" />
              </button>
              <AnimatePresence>
                {activeMenuDropdown === 'ai' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 5 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 5 }}
                    className={`absolute left-0 mt-1.5 w-52 rounded-xl shadow-xl p-2 z-50 border ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100 shadow-black/80' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5">
                      <button
                        onClick={() => {
                          setActiveMenuDropdown(null);
                          const textarea = document.getElementById('ai_prompt_input') as HTMLTextAreaElement;
                          if (textarea) {
                            textarea.focus();
                            textarea.scrollIntoView({ behavior: 'smooth' });
                          }
                          triggerLocalFeedback("Describe your app in the AI command box & click 'Build New'!");
                        }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Sparkles className="w-4 h-4 text-purple-400" />
                        <span>Generate App</span>
                      </button>
                      <button
                        onClick={() => {
                          setActiveMenuDropdown(null);
                          const textarea = document.getElementById('ai_prompt_input') as HTMLTextAreaElement;
                          if (textarea) {
                            textarea.focus();
                            textarea.scrollIntoView({ behavior: 'smooth' });
                          }
                          triggerLocalFeedback("Describe changes in the AI command box & click 'Edit Active App'!");
                        }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Wand2 className="w-4 h-4 text-indigo-400 animate-pulse" />
                        <span>Edit Project</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); startVoiceRecognition('main'); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Mic className="w-4 h-4 text-rose-455 text-rose-450" />
                        <span>Voice Input</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* PROJECTS MENU (Tools) */}
            <div className="relative inline-block" id="container_tools_menu">
              <button
                id="btn_tools_menu_trigger"
                onClick={() => setActiveMenuDropdown(activeMenuDropdown === 'tools' ? null : 'tools')}
                className={`relative z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-colors cursor-pointer select-none ${
                  activeMenuDropdown === 'tools'
                    ? 'bg-indigo-650 bg-indigo-600 text-white font-extrabold shadow-sm'
                    : isDarkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <History className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Projects</span>
                <ChevronDown className={`hidden sm:inline-block w-3 h-3 transition-transform ${activeMenuDropdown === 'tools' ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {activeMenuDropdown === 'tools' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 5 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 5 }}
                    className={`absolute left-0 mt-1.5 w-56 rounded-xl shadow-xl p-2 z-50 border ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100 shadow-black/80' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5">
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setShowVersionsPanel(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <History className="w-4 h-4 text-amber-400" />
                        <span>Version History</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setShowAndroidPackagerModal(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Smartphone className="w-4 h-4 text-emerald-400" />
                        <span>Android Packaging</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setSettingsDropdownOpen(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <Settings className="w-4 h-4 text-slate-400" />
                        <span>Preferences</span>
                      </button>
                      <button
                        onClick={() => { setActiveMenuDropdown(null); setShowHelpModal(true); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <HelpCircle className="w-4 h-4 text-indigo-400" />
                        <span>Help & Instructions</span>
                      </button>
                      <div className="h-px bg-slate-800/10 dark:bg-slate-800 my-1" />
                      <button
                        onClick={() => { setActiveMenuDropdown(null); handleResetWorkspace(); }}
                        className={`flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-lg transition-colors text-left text-red-500 hover:bg-rose-500/10`}
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Revert Workspace</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* SETTINGS MENU */}
            <div className="relative inline-block" id="container_settings_menu">
              <button
                id="btn_settings_menu_trigger"
                onClick={() => setActiveMenuDropdown(activeMenuDropdown === 'settings' ? null : 'settings')}
                className={`relative z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-[11px] sm:text-xs transition-colors cursor-pointer select-none ${
                  activeMenuDropdown === 'settings'
                    ? 'bg-indigo-650 bg-indigo-600 text-white font-extrabold shadow-sm'
                    : isDarkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Settings className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>Settings</span>
                <ChevronDown className="hidden sm:inline-block w-3 h-3 transition-transform" />
              </button>
              <AnimatePresence>
                {activeMenuDropdown === 'settings' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 5 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 5 }}
                    className={`absolute left-0 mt-1.5 w-60 rounded-xl shadow-xl p-2.5 z-50 border ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100 shadow-black/80' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5 animate-fade-in">
                      {/* Theme Toggle */}
                      <button
                        onClick={() => {
                          setIsDarkMode(!isDarkMode);
                        }}
                        className={`flex items-center justify-between w-full px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200 hover:text-white' : 'hover:bg-slate-100 text-slate-700 hover:text-slate-900'}`}
                      >
                        <div className="flex items-center gap-2">
                          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-500" />}
                          <span>Appearance Mode</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-slate-400">
                          {isDarkMode ? 'Dark' : 'Light'}
                        </span>
                      </button>

                      {/* Autosave Switch */}
                      <button
                        onClick={() => {
                          const newVal = !isAutoSave;
                          setIsAutoSave(newVal);
                          localStorage.setItem('cps_auto_save', String(newVal));
                          triggerLocalFeedback(newVal ? "Autosave turned ON!" : "Autosave turned OFF!");
                        }}
                        className={`flex items-center justify-between w-full px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200' : 'hover:bg-slate-100 text-slate-700'}`}
                      >
                        <div className="flex items-center gap-2">
                          <Check className={`w-4 h-4 text-emerald-500 ${isAutoSave ? 'opacity-100' : 'opacity-20'}`} />
                          <span>Autosave Workspace</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-indigo-400">
                          {isAutoSave ? 'ON' : 'OFF'}
                        </span>
                      </button>

                      {/* Auto Compile Switch */}
                      <button
                        onClick={() => {
                          setAutoRun(!autoRun);
                          triggerLocalFeedback(!autoRun ? "Auto-compiler Activated!" : "Auto-compiler Paused");
                        }}
                        className={`flex items-center justify-between w-full px-3 py-2 text-xs font-semibold rounded-lg transition-colors text-left ${isDarkMode ? 'hover:bg-slate-800 text-slate-200' : 'hover:bg-slate-100 text-slate-700'}`}
                      >
                        <div className="flex items-center gap-2">
                          <Check className={`w-4 h-4 text-teal-400 ${autoRun ? 'opacity-100' : 'opacity-20'}`} />
                          <span>Auto Live Compile</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-indigo-400">
                          {autoRun ? 'AUTO' : 'MANUAL'}
                        </span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            {/* Backdrop for closing list */}
            {activeMenuDropdown && (
              <div
                className="fixed inset-0 z-10 bg-transparent cursor-default"
                onClick={() => setActiveMenuDropdown(null)}
              />
            )}
          </div>



          <div className="flex flex-col">
            <div className="flex items-center gap-1.5 leading-none">
              <h1 className="text-[13px] font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 font-sans">
                AI Studio Builder
              </h1>
              <span className={`inline-flex items-center gap-1 text-[8px] font-extrabold px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                isOffline 
                  ? 'bg-amber-500/15 text-amber-500 border border-amber-500/10' 
                  : 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/10'
              }`}>
                {isOffline ? 'Offline' : 'Pro'}
              </span>
            </div>

            {/* Active Workspace Label & Dropdown Toggle */}
            <div className="flex items-center gap-1.5 mt-1 font-mono text-[11px] select-none text-slate-400">
              <span>Space:</span>
              {isRenamingName ? (
                <div className="flex items-center gap-1">
                  <input
                    id="input_rename_project"
                    type="text"
                    value={editProjectNameVal}
                    onChange={(e) => setEditProjectNameVal(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleRenameSubmit();
                      } else if (e.key === 'Escape') {
                        setIsRenamingName(false);
                      }
                    }}
                    onBlur={handleRenameSubmit}
                    className="text-[11px] bg-slate-100 dark:bg-slate-950 border border-indigo-500 rounded px-1.5 py-0.5 text-indigo-600 dark:text-indigo-300 font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 max-w-[155px]"
                    autoFocus
                    maxLength={32}
                  />
                  <button 
                    id="btn_confirm_rename"
                    onClick={handleRenameSubmit} 
                    className="text-emerald-500 p-0.5 hover:bg-emerald-500/10 rounded"
                    title="Confirm renaming"
                  >
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  </button>
                  <button 
                    id="btn_cancel_rename"
                    onClick={() => setIsRenamingName(false)} 
                    className="text-rose-500 p-0.5 hover:bg-rose-500/10 rounded"
                    title="Cancel"
                  >
                    <X className="w-3.5 h-3.5 stroke-[2.5]" />
                  </button>
                </div>
              ) : (
                <div className="relative inline-block">
                  <div className="flex items-center gap-1 group">
                    <button
                      id="btn_project_dropdown_trigger"
                      onClick={() => setRecentDropdownOpen(!recentDropdownOpen)}
                      className="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-slate-500/10 text-indigo-650 text-indigo-600 dark:text-indigo-400 font-semibold text-[11.5px] font-mono transition-all text-left"
                      title="Click for Project Management & Recent projects"
                    >
                      <span className="truncate max-w-[130px] sm:max-w-none">{activeProjectName}</span>
                      <ChevronDown className={`w-3 h-3 text-indigo-500 transition-transform duration-200 shrink-0 ${recentDropdownOpen ? 'rotate-180' : ''}`} />
                    </button>
                    
                    <button
                      id="btn_trigger_rename"
                      onClick={() => {
                        setEditProjectNameVal(activeProjectName);
                        setIsRenamingName(true);
                      }}
                      className="p-1 opacity-50 hover:opacity-100 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all rounded shrink-0"
                      title="Rename active project workspace"
                    >
                      <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                    </button>
                  </div>

                  {/* Dropdown Card */}
                  <AnimatePresence>
                    {recentDropdownOpen && (
                      <>
                        {/* Overlay click away background */}
                        <div 
                          className="fixed inset-0 z-40 bg-transparent" 
                          onClick={() => setRecentDropdownOpen(false)} 
                        />
                        {/* Dropdown panel */}
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          className={`absolute left-0 mt-2 w-72 rounded-2xl shadow-2xl p-4 z-50 border ${
                            isDarkMode 
                              ? 'bg-slate-900 border-slate-800 text-white shadow-black/80' 
                              : 'bg-white border-slate-200 text-slate-800 shadow-slate-200/80'
                          }`}
                        >
                          {/* Section: Project Actions */}
                          <div className="mb-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                            <span className="text-[10px] font-bold text-slate-450 text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-2">Project Options</span>
                            <div className="grid gap-1">
                              <button
                                id="dropdown_btn_new_project"
                                onClick={() => {
                                  setRecentDropdownOpen(false);
                                  setNewProjectNameVal('');
                                  setNewProjectTemplate('blank');
                                  setShowNewProjectModal(true);
                                }}
                                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-all text-left ${
                                  isDarkMode ? 'hover:bg-slate-800 text-slate-200' : 'hover:bg-slate-100 text-slate-700'
                                }`}
                              >
                                <PlusCircle className="w-4 h-4 text-emerald-400" />
                                <span>New Project...</span>
                              </button>
                              
                              <button
                                id="dropdown_btn_save_project"
                                onClick={() => {
                                  setRecentDropdownOpen(false);
                                  handleSaveCurrent();
                                }}
                                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-all text-left ${
                                  isDarkMode ? 'hover:bg-slate-800 text-slate-200' : 'hover:bg-slate-100 text-slate-700'
                                }`}
                              >
                                <Save className="w-4 h-4 text-indigo-400" />
                                <span>Save Active Workspace</span>
                              </button>

                              <button
                                id="dropdown_btn_rename_project"
                                onClick={() => {
                                  setRecentDropdownOpen(false);
                                  setEditProjectNameVal(activeProjectName);
                                  setIsRenamingName(true);
                                }}
                                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-all text-left ${
                                  isDarkMode ? 'hover:bg-slate-800 text-slate-200' : 'hover:bg-slate-100 text-slate-700'
                                }`}
                              >
                                <FileCode className="w-4 h-4 text-sky-400" />
                                <span>Rename Workspace...</span>
                              </button>
                            </div>
                          </div>

                          {/* Section: Recent Project Swatches */}
                          <div className="mb-2">
                            <div className="flex items-center justify-between mb-2 px-1">
                              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">Recent Workspaces</span>
                              <History className="w-3 h-3 text-slate-500" />
                            </div>
                            
                            <div className="space-y-0.5 max-h-[160px] overflow-y-auto pr-0.5">
                              {recentProjectIds.length <= 1 ? (
                                <div className="text-[11px] text-slate-500 italic py-3 text-center">No other modified spaces yet</div>
                              ) : (
                                recentProjectIds.map(pId => {
                                  if (pId === activeProjectId) return null;
                                  
                                  const pObj = getProjectById(pId);
                                  if (!pObj) return null;
                                  const isPreset = PRESET_PROJECTS.some(x => x.id === pId);
                                  
                                  return (
                                    <button
                                      key={pId}
                                      onClick={() => {
                                        setRecentDropdownOpen(false);
                                        loadProject(pObj);
                                      }}
                                      className={`w-full flex items-center justify-between text-left px-2 py-1.5 rounded-lg text-xs transition-all ${
                                        isDarkMode ? 'hover:bg-slate-800/80 text-slate-200' : 'hover:bg-slate-100 text-slate-700'
                                      }`}
                                    >
                                      <div className="truncate pr-2 flex items-center gap-1.5 shrink min-w-0">
                                        <Clock className="w-3.5 h-3.5 opacity-60 text-indigo-400 shrink-0" />
                                        <span className="truncate font-medium">{pObj.name}</span>
                                      </div>
                                      <span className={`text-[8px] px-1.5 py-0.2 rounded font-bold uppercase shrink-0 ${
                                        isPreset 
                                          ? 'bg-slate-800 text-indigo-400 border border-slate-700/50' 
                                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10'
                                      }`}>
                                        {isPreset ? 'Preset' : 'User'}
                                      </span>
                                    </button>
                                  );
                                })
                              )}
                            </div>
                          </div>

                          <div className="h-px bg-slate-100 dark:bg-slate-800/80 my-2"></div>

                          {/* Trigger view full project list */}
                          <button
                            id="dropdown_btn_open_explorer"
                            onClick={() => {
                              setRecentDropdownOpen(false);
                              setShowLoadPanel(true);
                            }}
                            className="w-full text-center text-[11px] text-indigo-400 hover:text-indigo-300 font-bold py-1 flex items-center justify-center gap-1"
                          >
                            <span>Open Project Explorer</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {/* Realtime Save status indicator */}
              <div className="flex items-center ml-1">
                <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-mono font-medium border ${
                  saveStatus === 'saving'
                    ? 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                    : saveStatus === 'dirty'
                      ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                }`}>
                  <span className={`w-1 h-1 rounded-full ${
                    saveStatus === 'saving'
                      ? 'bg-amber-400 animate-bounce'
                      : saveStatus === 'dirty'
                        ? 'bg-rose-400'
                        : 'bg-emerald-400 animate-pulse'
                  }`}></span>
                  {saveStatus === 'saving' ? 'Saving...' : saveStatus === 'dirty' ? 'Unsaved' : 'Saved'}
                </span>
              </div>
            </div>
          </div>
        </div>



        {/* Right Section: Prominent Preview CTA & Save indicator */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Synchronized Live Status indicator badge */}
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-[10px] font-mono font-bold border max-w-[85px] sm:max-w-none truncate shrink min-w-0 md:flex ${
            saveStatus === 'saving'
              ? 'bg-amber-500/10 text-amber-500 border-amber-500/15'
              : saveStatus === 'dirty'
                ? 'bg-rose-500/10 text-rose-400 border-rose-500/15'
                : 'bg-emerald-500/10 text-emerald-450 border border-emerald-500/15'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${
              saveStatus === 'saving' ? 'bg-amber-400 animate-bounce' : saveStatus === 'dirty' ? 'bg-rose-400' : 'bg-emerald-400 animate-pulse'
            }`} />
            <span className="hidden sm:inline">{saveStatus === 'saving' ? 'Saving' : saveStatus === 'dirty' ? 'Unsaved' : 'Autosaved'}</span>
          </span>

          <button
            onClick={compilePreview}
            id="btn_run_preview_prominent"
            className="relative inline-flex items-center gap-1.5 px-4 py-2 font-extrabold text-[12px] sm:text-xs rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white hover:scale-[1.01] active:scale-[0.98] transition-all cursor-pointer shadow-md shadow-indigo-600/15 group shrink-0"
            title="Compile output sandbox preview and reload container frame preview"
          >
            <Play className="w-3.5 h-3.5 fill-current text-indigo-400 group-hover:text-white shrink-0" />
            <span>Preview</span>
          </button>

          {/* Unified Settings Dropdown (Groups Help, Theme togglers and dev variables) */}
          <div className="relative hidden">
            <button
              id="btn_settings_dropdown_trigger"
              onClick={() => setSettingsDropdownOpen(!settingsDropdownOpen)}
              className={`p-2 rounded-xl transition-all flex items-center justify-center border cursor-pointer ${
                settingsDropdownOpen
                  ? 'bg-indigo-500/10 text-indigo-400 border-indigo-400/30'
                  : isDarkMode
                    ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    : 'bg-slate-100 text-slate-705 text-slate-700 border-slate-202 border-slate-200 hover:bg-slate-200'
              }`}
              title="Global preferences and settings menu"
            >
              <Settings className="w-4 h-4" />
            </button>

            <AnimatePresence>
              {settingsDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-40 bg-transparent cursor-default" onClick={() => setSettingsDropdownOpen(false)} />
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className={`absolute right-0 mt-2 w-72 rounded-2xl shadow-2xl p-4 z-50 border ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 text-white shadow-black/80' : 'bg-white border-slate-200 text-slate-800'
                    }`}
                  >
                    <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-1 px-1">
                      Preferences
                    </div>

                    <div className="space-y-1">
                      {/* Theme selection toggle inside dropdown menu */}
                      <button
                        onClick={() => {
                          setIsDarkMode(!isDarkMode);
                        }}
                        className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-semibold select-none transition-all ${
                          isDarkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {isDarkMode ? <Sun className="w-4 h-4 text-emerald-400" /> : <Moon className="w-4 h-4 text-slate-500" />}
                          <span>Appearance Mode</span>
                        </div>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded font-mono bg-slate-500/10 text-slate-400">
                          {isDarkMode ? 'Dark' : 'Light'}
                        </span>
                      </button>

                      {/* Auto Save Toggle option */}
                      <label className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-semibold select-none cursor-pointer transition-all ${
                        isDarkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                      }`}>
                        <div className="flex items-center gap-2.5">
                          <Check className={`w-4 h-4 text-emerald-500 ${isAutoSave ? 'opacity-100' : 'opacity-20'}`} />
                          <span>Local PWA Autosave</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={isAutoSave}
                          className="sr-only"
                          onChange={(e) => {
                            setIsAutoSave(e.target.checked);
                            localStorage.setItem('cps_auto_save', String(e.target.checked));
                          }}
                        />
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded font-mono bg-indigo-500/10 text-indigo-400 uppercase">
                          {isAutoSave ? 'Active' : 'Off'}
                        </span>
                      </label>

                      {/* Auto Compiler Control */}
                      <label className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-semibold select-none cursor-pointer transition-all ${
                        isDarkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                      }`}>
                        <div className="flex items-center gap-2.5">
                          <Check className={`w-4 h-4 text-teal-400 ${autoRun ? 'opacity-100' : 'opacity-20'}`} />
                          <span>Auto Live Compile</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={autoRun}
                          className="sr-only"
                          onChange={(e) => setAutoRun(e.target.checked)}
                        />
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded font-mono bg-indigo-500/10 text-indigo-400 uppercase">
                          {autoRun ? 'Enabled' : 'Manual'}
                        </span>
                      </label>

                      <div className="h-px bg-slate-100 dark:bg-slate-800 my-1"></div>

                      {/* Export HTML Action inside Dropdown */}
                      <button
                        onClick={() => {
                          setSettingsDropdownOpen(false);
                          handleExportHtmlDirect();
                        }}
                        className="w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold text-orange-500 hover:bg-orange-500/10 transition-all cursor-pointer"
                      >
                        <Download className="w-4 h-4 text-orange-500" />
                        <span>Export Static HTML Code</span>
                      </button>

                      {/* Revert Workspace Action */}
                      <button
                        onClick={() => {
                          setSettingsDropdownOpen(false);
                          handleResetWorkspace();
                        }}
                        className="w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold text-rose-500 hover:bg-rose-500/10 transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-4 h-4 text-rose-400" />
                        <span>Revert Workspace Code</span>
                      </button>

                      {/* Help Modal trigger */}
                      <button
                        onClick={() => {
                          setSettingsDropdownOpen(false);
                          setShowHelpModal(true);
                        }}
                        className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-all ${
                          isDarkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                        }`}
                      >
                        <HelpCircle className="w-4 h-4 text-indigo-400" />
                        <span>Help & Instructions</span>
                      </button>
                    </div> {/* Settings dropdown content ends */}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Start Hidden Old Component Wrapper to consume child render tags safely */}
        <div className="hidden">
          {/* New Project trigger button */}
          <button
            id="btn_new_project_toolbar"
            onClick={() => {
              setNewProjectNameVal('');
              setNewProjectTemplate('blank');
              setShowNewProjectModal(true);
            }}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl transition-all ${
              isDarkMode ? 'bg-emerald-500/10 text-emerald-405 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100 border border-emerald-250 border-emerald-200'
            }`}
            title="Create a fresh blank or templated workspace"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New Project</span>
          </button>

          {/* Preset templates gallery button */}
          <button
            id="btn_templates_gallery"
            onClick={() => setShowTemplatesGallery(true)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl transition-all ${
              isDarkMode 
                ? 'bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 hover:bg-indigo-900/30' 
                : 'bg-indigo-50 text-indigo-700 border border-indigo-100 hover:bg-indigo-100'
            }`}
            title="Open Interactive App Templates Gallery"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>Templates Gallery</span>
          </button>

          {/* Preset / Project loading button */}
          <button
            id="btn_load_project"
            onClick={() => setShowLoadPanel(true)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl transition-all ${
              isDarkMode ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            title="Load Template or Saved Project"
          >
            <FolderOpen className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Load Project</span>
          </button>

          {/* Version History panel toggle button */}
          <button
            id="btn_version_history"
            onClick={() => setShowVersionsPanel(true)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl transition-all ${
              isDarkMode ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            title="View automatic and manual versions history code checkpoints"
          >
            <History className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden sm:inline">Versions</span>
            {activeVersions.length > 0 && (
              <span className="ml-1 bg-indigo-600 dark:bg-indigo-500 text-white font-mono text-[9px] px-1.5 py-0.5 rounded-full font-bold leading-none shrink-0" id="badge_version_count">
                {activeVersions.length}
              </span>
            )}
          </button>

          {/* Android App Packaging Assistant Button */}
          <button
            id="btn_android_packaging"
            onClick={() => setShowAndroidPackagerModal(true)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-xl transition-all ${
              isDarkMode 
                ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-900/40 hover:bg-emerald-900/30' 
                : 'bg-emerald-50 text-emerald-700 border border-emerald-100 hover:bg-emerald-100'
            }`}
            title="Open Android App Packaging Assistant Wizard"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
            <span className="hidden sm:inline">Android Export</span>
          </button>

          {/* Save operations */}
          <div className="flex items-center">
            <button
              id="btn_save_project"
              onClick={handleSaveCurrent}
              className="flex items-center gap-1 px-3 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-l-xl transition-all border-r border-indigo-700"
              title="Save current workspace"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Save</span>
            </button>
            <button
              id="btn_save_as"
              onClick={() => {
                setNewProjectName(`${activeProjectName} (Copy)`);
                setShowSaveAsModal(true);
              }}
              className="px-2 py-2 text-xs bg-indigo-600 hover:bg-indigo-500 text-white rounded-r-xl transition-all"
              title="Save as a new project copy"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-6 w-px bg-slate-200 dark:bg-slate-800 mx-1"></div>

          {/* Compile Run Control */}
          <button
            id="btn_run_preview"
            onClick={compilePreview}
            className="flex items-center gap-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl shadow-md transition-all active:scale-95 cursor-pointer shrink-0"
            title="Compile output iframe code"
          >
            <Play className="w-4 h-4 fill-white shrink-0" />
            <span>Run Preview</span>
          </button>

          {/* Export HTML Button besides Run Preview */}
          <button
            id="btn_export_html_direct_toolbar"
            onClick={handleExportHtmlDirect}
            className="flex items-center gap-1.5 text-xs font-bold bg-orange-600 hover:bg-orange-505 hover:bg-orange-500 text-white px-4 py-2 rounded-xl shadow-md transition-all active:scale-95 cursor-pointer shrink-0"
            title="Download the current HTML project as index.html webpage"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>Export HTML</span>
          </button>

          {/* Theme custom toggle */}
          <button
            id="btn_toggle_theme"
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-xl transition-transform active:scale-90 ${
              isDarkMode ? 'bg-slate-800 text-amber-400 hover:bg-slate-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>


          
          <button
            id="btn_help"
            onClick={() => setShowHelpModal(true)}
            className={`p-2 rounded-xl ${isDarkMode ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Screen Layout Workspace */}
      <main className="flex flex-col lg:flex-row w-full h-[calc(100vh-65px)] overflow-hidden pb-0">
        
        {/* LEFT COLLAPSIBLE SIDEBAR: AI Companion Console & Templates Depot */}
        <aside 
          id="ai_companion_sidebar"
          className={`w-full lg:w-[380px] shrink-0 flex flex-col border-r h-auto lg:h-full lg:overflow-y-auto ${
            isDarkMode 
              ? 'bg-slate-900/90 border-slate-800' 
              : 'bg-slate-50 border-slate-200 text-slate-800'
          }`}
        >
          {/* AI BUILDER DASHBOARD ROW */}
          <div className="p-4 border-b border-dashed border-slate-800/10 dark:border-slate-800 flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse shrink-0" />
              <h2 className="text-xs font-extrabold tracking-wider text-indigo-400 uppercase">AI App Generator Command</h2>
            </div>
            
            <p className="text-[11px] text-slate-500 leading-normal">
              Describe the app or feature you want to build. Our AI engine will auto-fill HTML structure, styling, and interactivity instantly.
            </p>

            {/* Input Box with custom mic trigger */}
            <div className="relative">
              <textarea
                id="ai_prompt_input"
                rows={3}
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g. A futuristic neon calculator with standard keys, active calculation history, and smooth button tap visual scales..."
                disabled={isGeneratingAi}
                className={`w-full text-xs p-3 rounded-xl pr-10 border transition-all resize-none shadow-inner focus:outline-none focus:ring-1 ${
                  isDarkMode 
                    ? 'bg-slate-950 text-slate-100 border-slate-800 focus:border-indigo-500 focus:ring-indigo-500/20' 
                    : 'bg-white text-slate-800 border-slate-200 focus:border-indigo-400 focus:ring-indigo-400/20'
                }`}
              />
              
              {/* Voice Button inside prompt */}
              <button
                type="button"
                id="btn_voice_prompt"
                onClick={() => startVoiceRecognition('main')}
                disabled={isGeneratingAi}
                className={`absolute right-3.5 bottom-3.5 p-1.5 rounded-full transition-all cursor-pointer ${
                  isListeningVoice && activeVoiceTarget === 'main'
                    ? 'bg-red-500 text-white animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.7)]' 
                    : isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-900'
                }`}
                title="Tap to speak guidelines"
              >
                <Mic className="w-4 h-4" />
              </button>

              {/* Listening Overlay */}
              {isListeningVoice && activeVoiceTarget === 'main' && (
                <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs rounded-xl flex flex-col items-center justify-center gap-1.5 text-center p-3.5 z-25 border border-red-500/30">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                    <span className="text-[11px] font-bold text-red-400 uppercase tracking-widest font-mono">Listening now...</span>
                  </div>
                  <p className="text-[10px] text-slate-300 font-medium max-w-[220px]">
                    {voiceLanguage === 'te-IN'
                      ? "స్పీకర్ కోసం రికార్డింగ్... తెలుగులో మాట్లాడండి"
                      : "Voice auto-appending to AI prompt... Speak now!"}
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsListeningVoice(false)}
                    className="mt-1 text-[9px] font-extrabold px-3 py-1 bg-red-950 text-red-200 border border-red-800/30 rounded-lg hover:bg-red-900/60 transition-all cursor-pointer"
                  >
                    Cancel Voice Capture
                  </button>
                </div>
              )}
            </div>

            {/* Language Selector Overlay for Voice Inputs */}
            <div className={`flex items-center justify-between p-2 rounded-xl border ${
              isDarkMode ? 'bg-slate-950/20 border-slate-850' : 'bg-slate-50 border-slate-200'
            }`}>
              <span className="text-[10px] text-slate-500 flex items-center gap-1 font-semibold font-mono">
                <Globe className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span>Voice Lang:</span>
              </span>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setVoiceLanguage('en-US')}
                  className={`text-[9.5px] font-extrabold px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                    voiceLanguage === 'en-US'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : isDarkMode
                        ? 'border-slate-800 text-slate-400 bg-slate-950 hover:bg-slate-900 hover:text-white'
                        : 'border-slate-205 text-slate-600 bg-white hover:bg-slate-100 hover:text-slate-905'
                  }`}
                  title="Speak English"
                >
                  🇺🇸 English
                </button>
                <button
                  type="button"
                  onClick={() => setVoiceLanguage('te-IN')}
                  className={`text-[9.5px] font-extrabold px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                    voiceLanguage === 'te-IN'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : isDarkMode
                        ? 'border-slate-800 text-slate-400 bg-slate-950 hover:bg-slate-900 hover:text-white'
                        : 'border-slate-205 text-slate-600 bg-white hover:bg-slate-100 hover:text-slate-905'
                  }`}
                  title="Speak Telugu - తెలుగు మాట్లాడండి"
                >
                  🇮🇳 తెలుగు
                </button>
              </div>
            </div>

            {/* Quick Prompts suggestions wrapper */}
            <div className="flex flex-wrap gap-1.5 mt-1 select-none">
              <span className="text-[9px] text-slate-500 font-bold uppercase py-0.5 tracking-wider pr-1">Try:</span>
              {[
                { label: "🎯 TicTacToe", p: "Tic-tac-toe game styled in retro cyberpunk arcade colors, with scoring tallies, neon lines, and sound simulator effects." },
                { label: "⏱️ Interval Timer", p: "A gorgeous HIIT workout timer dashboard showing active progress circles, customizable round settings, and visual alarm states." },
                { label: "🗒️ Notes Board", p: "A Kanban note board showing visual cards, category tags filters, adding new scratch notes, and delete buttons." }
              ].map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => setAiPrompt(s.p)}
                  disabled={isGeneratingAi}
                  className={`text-[9.5px] px-2 py-1 rounded-lg border transition-all cursor-pointer font-medium hover:scale-105 ${
                    isDarkMode 
                      ? 'border-slate-800 text-slate-400 bg-slate-950/40 hover:border-slate-700 hover:text-white' 
                      : 'border-slate-200 text-slate-500 bg-white hover:border-slate-300 hover:text-slate-800'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* AI compilation step rolling update visualizer OR Generate Button */}
            {isGeneratingAi ? (
              <div 
                id="ai_generation_loader"
                className="mt-2 p-3 text-center rounded-xl bg-indigo-500/10 border border-indigo-500/25 flex flex-col gap-2 items-center"
              >
                <div className="flex items-center gap-2.5 bg-indigo-500/20 px-3 py-1.5 rounded-xl">
                  <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin" />
                  <span className="text-xs font-bold text-indigo-400">Gemini Developing App...</span>
                </div>
                <div className="text-[10px] text-indigo-300 font-mono italic animate-pulse">
                  &gt; {currentAiStep || 'Generating modules...'}
                </div>
              </div>
            ) : (
              <div className="flex gap-2 mt-2">
                <button
                  type="button"
                  id="btn_trigger_ai_new"
                  onClick={() => handleAiGenerate(false)}
                  className={`flex-1 flex items-center justify-center gap-1 py-2 px-2.5 text-[11px] font-bold border rounded-xl hover:bg-opacity-90 cursor-pointer hover:scale-[1.01] active:scale-[0.99] transition-all text-center ${
                    isDarkMode 
                      ? 'border-slate-800 bg-slate-950 text-slate-300 hover:text-white' 
                      : 'border-slate-300 bg-white text-slate-700 hover:text-slate-900'
                  }`}
                  title="Build a brand new interactive application node from scratch"
                >
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Build New</span>
                </button>
                <button
                  type="button"
                  id="btn_trigger_ai_edit"
                  onClick={() => handleAiGenerate(true)}
                  className="flex-[1.3] flex items-center justify-center gap-1.5 py-2 px-3 text-[11px] font-extrabold bg-gradient-to-r from-indigo-600 via-purple-650 via-purple-600 to-pink-500 text-white rounded-xl shadow-[0_4px_12px_rgba(99,102,241,0.35)] hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer text-center"
                  title="Apply prompt as edit instructions to refactor active project code"
                >
                  <Wand2 className="w-3.5 h-3.5 animate-pulse" />
                  <span>Edit Active App</span>
                </button>
              </div>
            )}
          </div>

          {/* TEMPLATE CATEGORIES REGISTRY */}
          <div className="p-4 flex-grow flex flex-col gap-3 overflow-hidden">
            <div className="flex items-center justify-between border-b border-dashed border-slate-800/10 dark:border-slate-800 pb-1.5">
              <div className="flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">Visual Templates Library</h3>
              </div>
              <span className="text-[9px] font-mono bg-cyan-500/10 text-cyan-400 px-1.5 py-0.5 rounded font-bold">
                {PRESET_PROJECTS.length} Templates
              </span>
            </div>

            {/* App Category filtered tags */}
            <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-thin select-none shrink-0 scrollbar-none">
              {[
                "All Apps",
                "Games & Fun",
                "Utility Tools",
                "Interactive Visuals",
                "Productivity Apps"
              ].map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`text-[9.5px] px-2.5 py-1 rounded-full font-bold whitespace-nowrap transition-all cursor-pointer ${
                    activeCategory === cat
                      ? 'bg-indigo-600 text-white shadow-sm font-extrabold'
                      : isDarkMode 
                        ? 'bg-slate-950/80 text-slate-400 border border-slate-800 hover:bg-slate-900' 
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* List of presets in horizontal or scrollable vertical layout */}
            <div className="flex-grow overflow-y-auto space-y-2 max-h-[350px] lg:max-h-none scrollbar-thin pr-1">
              {PRESET_PROJECTS
                .filter(p => activeCategory === 'All Apps' || p.category === activeCategory)
                .map(preset => {
                  const isCurrentActive = activeProjectId === preset.id;
                  return (
                    <div
                      key={preset.id}
                      onClick={() => loadProject(preset)}
                      className={`p-3 rounded-xl cursor-pointer border group transition-all text-left flex items-start gap-3 relative overflow-hidden ${
                        isCurrentActive
                          ? 'border-indigo-500 bg-indigo-550/10 bg-indigo-500/5'
                          : isDarkMode 
                            ? 'border-slate-800 bg-slate-950/45 hover:border-slate-700 hover:bg-slate-950' 
                            : 'border-slate-250 bg-white hover:bg-slate-100 hover:border-slate-300'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        preset.category === 'Games & Fun' ? 'bg-fuchsia-500/15 text-fuchsia-400' :
                        preset.category === 'Productivity Apps' ? 'bg-indigo-500/15 text-indigo-400' :
                        preset.category === 'Utility Tools' ? 'bg-yellow-500/15 text-yellow-400' : 'bg-cyan-500/15 text-cyan-400'
                      }`}>
                        <Cpu className="w-4 h-4 stroke-[2]" />
                      </div>

                      <div className="flex-grow min-w-0">
                        <div className="font-bold text-xs truncate group-hover:text-indigo-400 transition-colors">
                          {preset.name}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1 italic">
                          Click to instant load and run sandbox
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5 mt-1">
                          <span className="text-[9px] font-mono font-bold text-indigo-400 uppercase tracking-widest leading-none bg-indigo-500/10 px-1 py-0.5 rounded">
                            {preset.category || 'Visuals'}
                          </span>
                        </div>
                      </div>

                      <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-0.5 transition-all mt-0.5 self-center" />
                    </div>
                  );
                })}

              {PRESET_PROJECTS.filter(p => activeCategory === 'All Apps' || p.category === activeCategory).length === 0 && (
                <div className="text-center py-6 text-slate-500 text-[11px] font-medium font-mono">
                  No templates found in this slot.
                </div>
              )}
            </div>

            {/* Offline and PWA Install Promo bar */}
            {isInstallable && (
              <div 
                onClick={triggerNativePwaInstall}
                className="mt-auto p-3 rounded-xl bg-gradient-to-tr from-indigo-950/40 to-purple-950/40 border border-indigo-800/20 flex items-center gap-3 cursor-pointer hover:border-indigo-500/40 transition-all select-none"
              >
                <div className="w-8 h-8 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0 animate-bounce">
                  <Download className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="flex-grow min-w-0">
                  <div className="text-xs font-bold text-indigo-400 leading-tight">Install AI App Builder</div>
                  <div className="text-[9px] text-slate-400 mt-0.5 leading-snug">Run locally on your home screen or system offline!</div>
                </div>
              </div>
            )}
          </div>
        </aside>
        
        {/* Segmented responsive view toggler for mobile users */}
        {isMobile && (
          <div className="flex md:hidden items-center justify-center p-2.5 bg-slate-100 dark:bg-slate-950 border-b border-slate-250 dark:border-slate-800 shrink-0 sticky top-0 z-10">
            <div className={`grid grid-cols-2 p-1 rounded-xl w-full max-w-[280px] ${
              isDarkMode ? 'bg-slate-900' : 'bg-slate-200/50'
            }`}>
              <button
                id="mobile_view_editor_btn"
                onClick={() => setMobileActiveView('editor')}
                className={`py-1.5 text-[11px] font-extrabold rounded-lg transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                  mobileActiveView === 'editor'
                    ? 'bg-indigo-650 bg-indigo-600 text-white shadow-md'
                    : 'text-slate-500 dark:text-slate-450 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                <Code className="w-3.5 h-3.5" />
                <span>Code Editor</span>
              </button>
              <button
                id="mobile_view_preview_btn"
                onClick={() => setMobileActiveView('preview')}
                className={`py-1.5 text-[11px] font-extrabold rounded-lg transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                  mobileActiveView === 'preview'
                    ? 'bg-indigo-650 bg-indigo-600 text-white shadow-md'
                    : 'text-slate-500 dark:text-slate-450 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                <Play className="w-3.5 h-3.5" />
                <span>Live Preview</span>
              </button>
            </div>
          </div>
        )}

        {/* CENTER COLUMN WORKSPACE: Editor & Live Preview Panel */}
        <div id="middle_workspace_column" className="flex-grow flex flex-col h-full min-w-0 w-full lg:w-0 overflow-hidden">
          {/* TOP SECTION: Code Editor wrapper */}
          <section 
            id="editor_workspace"
            style={isMobile ? { height: '100%', display: mobileActiveView === 'editor' ? 'flex' : 'none' } : { height: `${editorHeight}px` }}
            className={`flex-col relative shrink-0 overflow-hidden ${
              isMobile && mobileActiveView !== 'editor' ? 'hidden' : 'flex'
            } ${isDarkMode ? 'bg-slate-900 border-b border-slate-800' : 'bg-slate-100 border-b border-slate-200'}`}
          >
          {/* Tab Headings bar */}
          <div className={`flex items-center justify-between px-4 py-2 border-b ${isDarkMode ? 'bg-slate-900/60 border-slate-800/80' : 'bg-slate-200/50 border-slate-300/60'}`}>
            <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
              {(['html', 'css', 'javascript'] as EditorTab[]).map(tab => (
                <button
                  key={tab}
                  id={`tab_${tab}`}
                  onClick={() => setSelectedTab(tab)}
                  className={`relative flex items-center gap-2 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                    selectedTab === tab
                      ? isDarkMode ? 'bg-slate-800 text-indigo-400' : 'bg-white text-indigo-600 shadow-sm font-bold'
                      : isDarkMode ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/80'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${
                    tab === 'html' ? 'bg-orange-500' : tab === 'css' ? 'bg-sky-500' : 'bg-yellow-400'
                  }`}></span>
                  <span className="font-semibold tracking-wide">
                    {tab === 'html' ? 'HTML Tab' : tab === 'css' ? 'CSS Tab' : 'JavaScript Tab'}
                  </span>
                </button>
              ))}
            </div>

            {/* Sub utilities under Tab bar */}
            <div className="flex items-center gap-2">
              {/* Edit Workspace with AI button */}
              <button
                id="btn_edit_with_ai"
                onClick={() => setShowRefinerModal(true)}
                className="p-1.5 px-3 rounded-lg text-[11px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer border border-indigo-500/35 text-white bg-gradient-to-r from-indigo-600 via-purple-650 via-purple-600 to-pink-500 hover:scale-[1.02] shadow-sm shadow-indigo-500/10"
                title="Refine or Edit this Workspace using AI prompt instructions"
              >
                <Sparkles className="w-3.5 h-3.5 text-orange-200 animate-pulse" />
                <span>Edit with AI</span>
              </button>

              {/* Copy file */}
              <button
                id="btn_copy_editor"
                onClick={copyCurrentCode}
                className={`p-1.5 rounded-md text-[11px] font-medium flex items-center gap-1 transition-all ${
                  isDarkMode ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-200 text-slate-600'
                }`}
                title="Copy Active Code Tab"
              >
                <Copy className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Copy</span>
              </button>

              {/* Clear confirmation */}
              <button
                id="btn_clear_tab"
                onClick={() => setShowClearConfirm(true)}
                className="p-1.5 rounded-md text-red-500/80 hover:text-red-500 hover:bg-red-500/10 transition-all cursor-pointer"
                title="Reset active code workspace"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Embedded Editor Area with Line Numbers */}
          <div className="flex-grow flex overflow-hidden relative font-mono text-sm">
            {/* Auto-updating Scroll gutter list */}
            <div 
              ref={lineGutterRef}
              className={`select-none text-right pr-3 pl-4 py-3 border-r overflow-hidden text-[12px] font-mono leading-6 ${
                isDarkMode 
                  ? 'bg-slate-950 text-slate-600 border-slate-800' 
                  : 'bg-slate-50 text-slate-400 border-slate-200'
              }`}
              style={{ width: '52px' }}
            >
              {getLineNumbersArray(activeValue).map(ln => (
                <div key={ln} className="h-6 leading-6">{ln}</div>
              ))}
            </div>

            {/* Main Interactive text component */}
            <div className="flex-grow h-full relative">
              <textarea
                id="textarea_editor"
                ref={textareaRef}
                value={activeValue}
                onChange={(e) => setActiveValue(e.target.value)}
                onScroll={handleScroll}
                onKeyDown={handleKeyDown}
                placeholder={`Paste your ${selectedTab.toUpperCase()} code structure here...`}
                className={`w-full h-full p-3 resize-none font-mono leading-span leading-6 text-[13px] bg-transparent focus:outline-none ${
                  isDarkMode ? 'text-slate-100 placeholder-slate-600' : 'text-slate-800 placeholder-slate-400'
                }`}
                spellCheck="false"
                style={{
                  lineHeight: '24px',
                  whiteSpace: 'pre',
                  overflowWrap: 'normal',
                }}
              />
              
              {/* Overlay type branding watermark */}
              <div className="absolute right-4 bottom-3 pointer-events-none text-[10px] select-none uppercase tracking-widest font-bold opacity-20">
                {selectedTab} sandbox
              </div>
            </div>
          </div>

          {/* Small status footer of editor */}
          <div className={`px-4 py-1 flex items-center justify-between text-[11px] font-mono border-t ${
            isDarkMode ? 'bg-slate-950/60 border-slate-800 text-slate-500' : 'bg-slate-50 border-slate-200 text-slate-500'
          }`}>
            <div className="flex items-center gap-4">
              <span>Lines: <strong className="text-indigo-400">{activeValue.split('\n').length}</strong></span>
              <span>Characters: <strong className="text-indigo-400">{activeValue.length}</strong></span>
            </div>
            <div className="flex items-center gap-4">
              {/* Auto Save Toggle Checkbox */}
              <label className="flex items-center gap-1.5 cursor-pointer select-none">
                <input 
                  id="chk_auto_save"
                  type="checkbox" 
                  checked={isAutoSave}
                  onChange={(e) => {
                    setIsAutoSave(e.target.checked);
                    localStorage.setItem('cps_auto_save', String(e.target.checked));
                  }}
                  className="rounded border-slate-400 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 w-3 h-3"
                />
                <span className="text-slate-400 hover:text-indigo-400 transition-colors">Auto Save</span>
              </label>

              <span className="opacity-25">|</span>

              <label className="flex items-center gap-1.5 cursor-pointer select-none">
                <input 
                  type="checkbox" 
                  checked={autoRun}
                  onChange={(e) => setAutoRun(e.target.checked)}
                  className="rounded border-slate-400 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 w-3 h-3"
                />
                <span>Auto Compile (1.2s)</span>
              </label>
            </div>
          </div>
        </section>

        {/* DRAGGABLE WEIGHT BAR DIVIDER FOR VERTICAL SPLITS */}
        {!isMobile && (
          <div 
            id="editor_resizer_bar"
            onMouseDown={handleDragStart}
            onTouchStart={handleDragStart}
            className={`h-2.5 w-full cursor-row-resize flex items-center justify-center relative group active:bg-indigo-500 hover:bg-indigo-500/30 transition-all ${
              isDarkMode ? 'bg-slate-950 border-b border-t border-slate-800' : 'bg-slate-200 border-b border-t border-slate-300'
            }`}
            title="Drag up or down to resize panels"
          >
            {/* visual knurl horizontal lines */}
            <div className="flex gap-1.5">
              <span className="w-6 h-[2px] rounded bg-slate-400 dark:bg-slate-600 group-hover:bg-white"></span>
              <span className="w-6 h-[2px] rounded bg-slate-400 dark:bg-slate-600 group-hover:bg-white"></span>
            </div>
          </div>
        )}

         {/* BOTTOM SECTION: Live Preview area */}
        <section 
          id="preview_workspace" 
          className={`flex-grow flex-col min-h-[200px] overflow-hidden bg-slate-900 ${
            isMobile && mobileActiveView !== 'preview' ? 'hidden' : 'flex'
          }`}
        >
          
          {/* Preview window bar controls */}
          <div className={`flex items-center justify-between px-4 py-2 border-b shrink-0 ${
            isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 text-slate-800'
          }`}>
            <div className="flex items-center gap-2">
              <span className="flex gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-400 inline-block"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 inline-block"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-green-400 inline-block"></span>
              </span>
              <span className="text-xs font-mono font-medium opacity-60 pl-2">LIVE OUTBOX / SANDBOX</span>

              {/* Dynamic Library Injection Switches */}
              <div className="hidden lg:flex items-center gap-2 border-l pl-3 ml-2 border-slate-300 dark:border-slate-800">
                <span className="text-[9.5px] text-slate-500 font-bold uppercase tracking-wider">CDNs:</span>
                
                <button 
                  id="toggle_cdn_tailwind"
                  onClick={() => setUseTailwind(!useTailwind)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors font-semibold border ${
                    useTailwind 
                      ? 'bg-sky-500/10 text-sky-400 border-sky-400/30' 
                      : 'bg-slate-800/20 text-slate-500 border-transparent hover:text-slate-400'
                  }`}
                  title="Inject Tailwind CSS version 3 library into Sandbox"
                >
                  Tailwind
                </button>

                <button 
                  id="toggle_cdn_fontawesome"
                  onClick={() => setUseFontAwesome(!useFontAwesome)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors font-semibold border ${
                    useFontAwesome 
                      ? 'bg-indigo-500/15 text-indigo-400 border-indigo-500/20' 
                      : 'bg-slate-800/20 text-slate-500 border-transparent hover:text-slate-400'
                  }`}
                  title="Inject FontAwesome 6 icon catalog styles"
                >
                  FontAwesome
                </button>

                <button 
                  id="toggle_cdn_fonts"
                  onClick={() => setUseGoogleFonts(!useGoogleFonts)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors font-semibold border ${
                    useGoogleFonts 
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-400/20' 
                      : 'bg-slate-800/20 text-slate-500 border-transparent hover:text-slate-400'
                  }`}
                  title="Preload Google Fonts collection (Inter, JetBrains Mono)"
                >
                  Fonts
                </button>
              </div>
            </div>

            {/* Multi Device preset visualizer sizing togglers */}
            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-950 p-1 rounded-lg">
              <button
                id="preset_device_desktop"
                onClick={() => setPreviewDevice('desktop')}
                className={`p-1.5 rounded-md transition-all ${
                  previewDevice === 'desktop' 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
                }`}
                title="Desktop viewport frame resolution"
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
              <button
                id="preset_device_tablet"
                onClick={() => setPreviewDevice('tablet')}
                className={`p-1.5 rounded-md transition-all ${
                  previewDevice === 'tablet' 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
                }`}
                title="Tablet frame resolution (768px)"
              >
                <Tablet className="w-3.5 h-3.5" />
              </button>
              <button
                id="preset_device_mobile"
                onClick={() => setPreviewDevice('mobile')}
                className={`p-1.5 rounded-md transition-all ${
                  previewDevice === 'mobile' 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
                }`}
                title="Mobile frame resolution (375px)"
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Control buttons */}
            <div className="flex items-center gap-2">
              {/* Show console toggle */}
              <button
                id="btn_toggle_console"
                onClick={() => setShowConsole(!showConsole)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  showConsole 
                    ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20' 
                    : isDarkMode ? 'bg-slate-800 text-slate-400 border border-slate-700' : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}
              >
                Console Logs ({consoleLogs.length})
              </button>

              <button
                id="btn_refresh_sandbox"
                onClick={compilePreview}
                className="p-2 rounded-lg bg-emerald-600/10 text-emerald-400 border border-emerald-500/15 hover:bg-emerald-600/25 transition-all"
                title="Refresh Sandbox frame"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>

              <button
                id="btn_fullscreen_preview"
                onClick={() => setIsFullScreenPreview(true)}
                className="p-2 rounded-lg bg-indigo-600/10 text-indigo-400 border border-indigo-500/15 hover:bg-indigo-600/25 transition-all flex items-center justify-center"
                title="Open Sandbox in Immersive Full Screen Preview"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive frame viewport with dynamic sizing layouts */}
          <div className="flex-grow flex flex-col bg-slate-950 p-4 relative overflow-hidden items-center justify-center">
            
            <div 
              className={`bg-white transition-all duration-300 relative flex flex-col shadow-2xl overflow-hidden rounded-xl h-full border border-slate-800 ${
                previewDevice === 'mobile' 
                  ? 'w-[375px]' 
                  : previewDevice === 'tablet' 
                    ? 'w-[768px]' 
                    : 'w-full'
              }`}
            >
              <iframe
                id="sandbox_iframe"
                key={previewKey}
                ref={iframeRef}
                srcDoc={renderedCode}
                title="Live Code Preview Sandbox window"
                sandbox="allow-scripts allow-modals allow-same-origin"
                className="w-full flex-grow border-none bg-white"
              />
            </div>
          </div>

          {/* OPTIONAL CONSOLE DRAWER LOGS VIEWER */}
          <AnimatePresence>
            {showConsole && (
              <motion.div 
                id="terminal_console_drawer"
                initial={{ height: 0 }}
                animate={{ height: 160 }}
                exit={{ height: 0 }}
                className="bg-slate-950 border-t border-slate-800 flex flex-col text-[11px] font-mono shrink-0 overflow-hidden text-slate-400"
              >
                <div className="flex items-center justify-between px-4 py-1.5 bg-slate-900 border-b border-indigo-950 shrink-0">
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                    <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                    <span>DEBUGGER CONSOLE OUTPUT</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      id="btn_clear_console"
                      onClick={() => setConsoleLogs([])} 
                      className="hover:text-white px-2 py-0.5 rounded transition-all bg-slate-800 text-[10px]"
                    >
                      Sweep Console
                    </button>
                    <button 
                      id="btn_close_console"
                      onClick={() => setShowConsole(false)} 
                      className="hover:text-red-400"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* List scroll elements */}
                <div className="flex-grow p-3 overflow-y-auto space-y-1">
                  {consoleLogs.length === 0 ? (
                    <div className="text-slate-600 text-center py-4 italic">No outputs captured yet. Use console.log() in your Javascript block!</div>
                  ) : (
                    consoleLogs.map((log, idx) => (
                      <div 
                        key={idx} 
                        className={`py-1 border-b border-transparent flex items-start gap-2.5 transition-colors ${
                          log.type === 'error' 
                            ? 'text-red-400 bg-red-950/25 px-2 rounded border-red-950' 
                            : log.type === 'system' 
                              ? 'text-indigo-300 font-bold' 
                              : 'text-slate-250 border-slate-900'
                        }`}
                      >
                        <span className="text-[9px] opacity-40 font-mono select-none pt-0.5">{log.time}</span>
                        {log.type === 'error' && <span className="font-bold text-red-500 select-none">[ERR]</span>}
                        {log.type === 'system' && <span className="font-bold text-indigo-400 select-none">[SYS]</span>}
                        {log.type === 'log' && <span className="text-emerald-500 font-bold select-none">&gt;</span>}
                        <span className="flex-grow break-all whitespace-pre-wrap">{log.text}</span>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </div>
    </main>

      {/* PANELS & DIALOG MODAL CONTROLLERS */}

      {/* OVERLAY PANEL: PROJECTS MANAGER */}
      <AnimatePresence>
        {showLoadPanel && (
          <div className="fixed inset-0 z-50 flex justify-end" id="dialog_slideover_wrapper">
            {/* Backdrop cover */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLoadPanel(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            {/* Panel sliding box */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={`relative w-full max-w-md h-full flex flex-col shadow-2xl ${
                isDarkMode ? 'bg-slate-900 border-l border-slate-800' : 'bg-white border-l border-slate-200'
              }`}
            >
              <div className="p-5 border-b border-slate-800/10 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold tracking-tight">Project Explorer</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Select a templates library preview block</p>
                </div>
                <button
                  onClick={() => setShowLoadPanel(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-500/15"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Lists content wrapper */}
              <div className="flex-grow overflow-y-auto p-5 space-y-4">
                
                {/* PRESETS HEADER */}
                <div>
                  <div className="text-[10px] font-bold tracking-wider text-indigo-400 uppercase mb-2">Preset Templates Examples</div>
                  <div className="grid gap-3">
                    {PRESET_PROJECTS.map(prep => {
                      const isActive = activeProjectId === prep.id;
                      return (
                        <div
                          key={prep.id}
                          onClick={() => loadProject(prep)}
                          className={`p-4 rounded-xl cursor-pointer border transition-all text-left group flex flex-col justify-between ${
                            isActive
                              ? 'border-indigo-600 bg-indigo-500/10'
                              : isDarkMode ? 'border-slate-850 bg-slate-950/45 hover:border-slate-750' : 'border-slate-205 bg-slate-50 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-xs text-sky-400 flex items-center gap-1">
                              <Sparkles className="w-3 h-3 text-amber-400 animate-pulse" />
                              {prep.name}
                            </span>
                            <span className="text-[8px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">PRESET</span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-2 line-clamp-2">
                            Interactive code sandbox showcasing creative dynamic mechanics using scripts.
                          </p>
                          <div className="mt-3 pt-2 border-t border-slate-200/5 dark:border-slate-800/60 flex items-center justify-between gap-2">
                            <span className="text-[9px] font-mono text-slate-500 hover:text-slate-350 select-none">Quick Export</span>
                            <div className="flex gap-1.5 shrink-0">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  exportProjectHTML(prep);
                                }}
                                className="p-1 px-2 rounded bg-amber-500/10 text-amber-500 font-extrabold hover:bg-amber-500/20 text-[9px] uppercase tracking-wider flex items-center gap-1 transition-all border border-amber-500/10 cursor-pointer"
                                title="Download Instant Standalone HTML file of this Preset"
                              >
                                <Download className="w-2.5 h-2.5 text-amber-400" />
                                <span>HTML</span>
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  exportProjectAsZip(prep);
                                }}
                                className="p-1 px-2 rounded bg-indigo-550/15 text-indigo-400 font-extrabold hover:bg-indigo-500/25 text-[9px] uppercase tracking-wider flex items-center gap-1 transition-all border border-indigo-550/10 cursor-pointer"
                                title="Download Complete modular ZIP file code project of this Preset"
                              >
                                <Archive className="w-2.5 h-2.5 text-indigo-400" />
                                <span>ZIP</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="h-px bg-slate-200 dark:bg-slate-800 my-4"></div>

                {/* USER CUSTOM WORKSPACES */}
                <div>
                  <div className="text-[10px] font-bold tracking-wider text-rose-450 text-rose-400 uppercase mb-2">Your Saved Projects ({projects.filter(p => !PRESET_PROJECTS.some(preset => preset.id === p.id)).length})</div>
                  <div className="grid gap-3">
                    {projects.filter(p => !PRESET_PROJECTS.some(preset => preset.id === p.id)).length === 0 ? (
                      <div className="text-center py-6 text-xs text-slate-500 border border-dashed rounded-xl border-slate-700/60 flex flex-col items-center gap-2">
                        <span>No saved spaces found yet.</span>
                        <button 
                          onClick={() => {
                            setShowLoadPanel(false);
                            setNewProjectName('My Awesome Project');
                            setShowSaveAsModal(true);
                          }}
                          className="text-[11px] underline text-indigo-400"
                        >
                          Save current workspace as Project
                        </button>
                      </div>
                    ) : (
                      projects.filter(p => !PRESET_PROJECTS.some(preset => preset.id === p.id)).map(userp => {
                        const isActive = activeProjectId === userp.id;
                        return (
                          <div
                            key={userp.id}
                            onClick={() => loadProject(userp)}
                            className={`p-4 rounded-xl cursor-pointer border transition-all text-left flex flex-col justify-between ${
                              isActive
                                ? 'border-amber-600 bg-amber-500/10'
                                : isDarkMode ? 'border-slate-800 bg-slate-950/50 hover:border-slate-700' : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                            }`}
                          >
                            <div className="flex items-start justify-between min-w-0 w-full mb-1">
                              <div className="flex-grow min-w-0 mr-2">
                                <span className="font-bold text-xs truncate block text-indigo-400 dark:text-sky-350">{userp.name}</span>
                                <span className="text-[9px] text-slate-500 mt-1 block">Saved: {userp.updatedAt}</span>
                              </div>
                              {deleteConfirmProjectId === userp.id ? (
                                <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                                  <button
                                    onClick={(e) => {
                                      deleteUserProject(userp.id, e);
                                      setDeleteConfirmProjectId(null);
                                    }}
                                    className="px-2 py-1 rounded bg-rose-650 bg-rose-600 hover:bg-rose-500 text-[9px] font-extrabold text-white transition-all shadow-md cursor-pointer"
                                  >
                                    Sure?
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setDeleteConfirmProjectId(null);
                                    }}
                                    className="px-1.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[9px] text-slate-300 border border-slate-700/50 cursor-pointer"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <button
                                  id={`delete_project_${userp.id}`}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDeleteConfirmProjectId(userp.id);
                                  }}
                                  className="p-1 px-1.5 rounded-lg text-rose-450 hover:text-rose-400 hover:bg-rose-500/10 transition-all shrink-0 self-start"
                                  title="Delete project workspace"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>

                            <div className="mt-3 pt-2 border-t border-slate-200/5 dark:border-slate-800/60 flex items-center justify-between gap-2 w-full">
                              <span className="text-[9px] font-mono text-slate-500 select-none">Quick Export</span>
                              <div className="flex gap-1.5 shrink-0">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    exportProjectHTML(userp);
                                  }}
                                  className="p-1 px-2 rounded bg-amber-500/10 text-amber-500 font-extrabold hover:bg-amber-500/20 text-[9px] uppercase tracking-wider flex items-center gap-1 transition-all border border-amber-500/10 cursor-pointer"
                                  title="Download standalone HTML backup of this project"
                                >
                                  <Download className="w-2.5 h-2.5 text-amber-400" />
                                  <span>HTML</span>
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    exportProjectAsZip(userp);
                                  }}
                                  className="p-1 px-2 rounded bg-indigo-505 bg-indigo-600/10 text-indigo-400 font-extrabold hover:bg-indigo-600/20 text-[9px] uppercase tracking-wider flex items-center gap-1 transition-all border border-indigo-500/10 cursor-pointer"
                                  title="Download complete modular Project ZIP"
                                >
                                  <Archive className="w-2.5 h-2.5 text-indigo-400" />
                                  <span>ZIP</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

              </div>
              <div className="p-4 border-t dark:border-slate-800 text-[11px] text-slate-500 flex justify-between">
                <span>Total files: <strong>{projects.length} slots</strong></span>
                <span>Storage status: <strong>Persistent Offline</strong></span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* OVERLAY PANEL: VERSION HISTORY MANAGER */}
      <AnimatePresence>
        {showVersionsPanel && (
          <div className="fixed inset-0 z-50 flex justify-end" id="dialog_versions_slideover">
            {/* Backdrop cover */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowVersionsPanel(false);
                setExpandedVersionId(null);
              }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            {/* Panel sliding box */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={`relative w-full max-w-md h-full flex flex-col shadow-2xl ${
                isDarkMode ? 'bg-slate-900 border-l border-slate-800' : 'bg-white border-l border-slate-200'
              }`}
            >
              <div className="p-5 border-b border-slate-800/10 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold tracking-tight flex items-center gap-1.5 text-indigo-500">
                    <History className="w-4 h-4 text-amber-500" />
                    <span>Version Timeline</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Current base project: <strong className={isDarkMode ? 'text-indigo-400' : 'text-indigo-600'}>{activeProjectName}</strong>
                  </p>
                </div>
                <button
                  onClick={() => {
                    setShowVersionsPanel(false);
                    setExpandedVersionId(null);
                  }}
                  className="p-1.5 rounded-lg hover:bg-slate-500/15"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Version History Action Utilities */}
              {activeVersions.length > 0 && (
                <div className={`px-5 py-2 border-b flex justify-between items-center text-[11px] ${
                  isDarkMode ? 'border-slate-800 bg-slate-950/20' : 'border-slate-250 bg-slate-50/50'
                }`}>
                  <span className="text-slate-500 font-medium">Auto-save buffer count: <strong>{activeVersions.length}/15</strong></span>
                  <button
                    onClick={() => {
                      if (confirm("Are you sure you want to wipe all history backups of this project? This is irreversible.")) {
                        localStorage.removeItem(`cps_versions_${activeProjectId}`);
                        setActiveVersions([]);
                        setExpandedVersionId(null);
                        triggerLocalFeedback("Cleared project histories!");
                      }
                    }}
                    className="text-rose-500 font-bold hover:underline bg-transparent"
                  >
                    Clear History
                  </button>
                </div>
              )}

              {/* Version List Body container */}
              <div className="flex-grow overflow-y-auto p-5 space-y-4">
                {activeVersions.length === 0 ? (
                  <div className="text-center py-16 text-xs text-slate-505 dark:text-slate-500 border border-dashed rounded-xl border-slate-700/60 flex flex-col items-center gap-3">
                    <History className="w-8 h-8 text-slate-500" />
                    <div className="max-w-[240px] leading-relaxed">
                      No versions registered yet for this workspace. Auto-saves and manual compile checkpoints will appear here chronologically!
                    </div>
                  </div>
                ) : (
                  <div className="relative border-l border-indigo-500/30 pl-4 ml-2.5 space-y-5">
                    {activeVersions.map((ver, idx) => {
                      const isExpanded = expandedVersionId === ver.id;
                      
                      // Style configurations for badges
                      let badgeColor = 'bg-slate-850 text-slate-400 border-slate-800';
                      let typeLabel = 'AUTO';
                      if (ver.type === 'initial') {
                        badgeColor = 'bg-sky-500/10 text-sky-400 border-sky-500/20';
                        typeLabel = 'INITIAL';
                      } else if (ver.type === 'manual') {
                        badgeColor = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
                        typeLabel = 'SAVEPOINT';
                      } else if (ver.type === 'ai') {
                        badgeColor = 'bg-purple-500/10 text-purple-400 border-purple-500/20';
                        typeLabel = 'AI CHECKPOINT';
                      }

                      const htmlLines = ver.html ? ver.html.split('\n').length : 0;
                      const cssLines = ver.css ? ver.css.split('\n').length : 0;
                      const jsLines = ver.javascript ? ver.javascript.split('\n').length : 0;

                      return (
                        <div key={ver.id} className="relative group">
                          {/* Timeline Node dot */}
                          <div className={`absolute -left-[23px] top-1.5 w-2.5 h-2.5 rounded-full border-2 transition-all ${
                            idx === 0 
                              ? 'bg-amber-400 border-amber-400 scale-125 shadow-[0_0_8px_rgba(251,191,36,0.6)]' 
                              : 'bg-indigo-300 border-slate-900 group-hover:bg-indigo-400'
                          }`} />

                          <div className={`p-3.5 rounded-xl border text-left flex flex-col transition-all ${
                            isDarkMode 
                              ? 'bg-slate-950/40 border-slate-850 hover:border-slate-755' 
                              : 'bg-slate-50 border-slate-200 hover:bg-slate-100/70'
                          }`}>
                            <div className="flex items-center justify-between w-full">
                              <span className={`text-[8px] px-2 py-0.5 rounded-md font-extrabold uppercase tracking-widest border ${badgeColor}`}>
                                {typeLabel}
                              </span>
                              <div className="flex items-center gap-1.5 text-slate-500 text-[10px]">
                                <Clock className="w-3 h-3 text-slate-450" />
                                <span>{ver.timestamp}</span>
                              </div>
                            </div>

                            <h4 className={`text-xs font-bold leading-snug mt-2 text-indigo-400 dark:text-indigo-350 break-words`}>
                              {ver.name}
                            </h4>

                            <div className="flex items-center justify-between mt-3 gap-2 flex-wrap">
                              {/* Small details */}
                              <span className="text-[10px] text-slate-505 font-medium">
                                Size: <span className="font-mono text-[9px]">{htmlLines + cssLines + jsLines} lines total</span>
                              </span>

                              <div className="flex gap-1">
                                <button
                                  type="button"
                                  onClick={() => setExpandedVersionId(isExpanded ? null : ver.id)}
                                  className={`p-1 px-2.5 rounded-lg text-[10px] font-semibold border flex items-center gap-1 transition-all cursor-pointer ${
                                    isExpanded
                                      ? 'bg-slate-800 border-slate-700 text-white'
                                      : isDarkMode
                                        ? 'border-slate-800 text-slate-400 bg-slate-950 hover:bg-slate-900 hover:text-white'
                                        : 'border-slate-205 text-slate-600 bg-white hover:bg-slate-100 hover:text-slate-950'
                                  }`}
                                  title="View detailed files code differences"
                                >
                                  <span>{isExpanded ? 'Hide Code' : 'Inspect'}</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => restoreVersion(ver)}
                                  className="p-1 px-3 rounded-lg text-[10px] font-extrabold bg-emerald-600 hover:bg-emerald-505 hover:bg-emerald-500 text-white shadow-sm transition-all flex items-center gap-1 cursor-pointer"
                                  title="Instantly restore these files into active editors"
                                >
                                  <ChevronRight className="w-3.5 h-3.5" />
                                  <span>Restore</span>
                                </button>
                              </div>
                            </div>

                            {/* Collapsible inspected editors scroll block */}
                            {isExpanded && (
                              <div className="mt-3.5 pt-3 border-t border-slate-200/5 dark:border-slate-800/80 space-y-2.5 overflow-hidden">
                                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 font-mono">
                                  <span>File check-outs:</span>
                                </div>
                                <div className="grid gap-2">
                                  {ver.html && (
                                    <div className="flex flex-col rounded-lg overflow-hidden border border-slate-800/20 dark:border-slate-800/80">
                                      <div className="bg-slate-950 p-1.5 px-2.5 flex justify-between items-center text-[9px] font-bold font-mono text-indigo-400">
                                        <span>index.html</span>
                                        <span className="text-slate-500 font-normal">{htmlLines} lines</span>
                                      </div>
                                      <pre className="p-2 bg-slate-950/80 max-h-32 overflow-y-auto text-[9px] font-mono text-slate-300 leading-relaxed text-left whitespace-pre-wrap select-all">
                                        {ver.html}
                                      </pre>
                                    </div>
                                  )}
                                  {ver.css && (
                                    <div className="flex flex-col rounded-lg overflow-hidden border border-slate-800/20 dark:border-slate-800/80">
                                      <div className="bg-slate-950 p-1.5 px-2.5 flex justify-between items-center text-[9px] font-bold font-mono text-sky-400">
                                        <span>style.css</span>
                                        <span className="text-slate-500 font-normal">{cssLines} lines</span>
                                      </div>
                                      <pre className="p-2 bg-slate-950/80 max-h-32 overflow-y-auto text-[9px] font-mono text-slate-300 leading-relaxed text-left whitespace-pre-wrap select-all">
                                        {ver.css}
                                      </pre>
                                    </div>
                                  )}
                                  {ver.javascript && (
                                    <div className="flex flex-col rounded-lg overflow-hidden border border-slate-800/20 dark:border-slate-800/80">
                                      <div className="bg-slate-950 p-1.5 px-2.5 flex justify-between items-center text-[9px] font-bold font-mono text-amber-500">
                                        <span>main.js</span>
                                        <span className="text-slate-500 font-normal">{jsLines} lines</span>
                                      </div>
                                      <pre className="p-2 bg-slate-950/80 max-h-32 overflow-y-auto text-[9px] font-mono text-slate-300 leading-relaxed text-left whitespace-pre-wrap select-all">
                                        {ver.javascript}
                                      </pre>
                                    </div>
                                  )}
                                </div>
                                <div className="pt-1.5 flex justify-end gap-1.5 border-t border-slate-800/60 mt-2">
                                  <button
                                    type="button"
                                    onClick={() => setExpandedVersionId(null)}
                                    className="p-1 px-3 text-[9px] text-slate-500 font-semibold hover:text-slate-300 bg-transparent cursor-pointer"
                                  >
                                    Minimize previews
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => restoreVersion(ver)}
                                    className="p-1 px-3 rounded-lg text-[9.5px] font-extrabold bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm flex items-center gap-1 transition-all cursor-pointer"
                                  >
                                    <ChevronRight className="w-3 h-3" />
                                    <span>Restore Version State</span>
                                  </button>
                                </div>
                              </div>
                            )}

                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="p-4 border-t dark:border-slate-800 text-[11px] text-slate-505 dark:text-slate-500 flex justify-between items-center bg-slate-950/30">
                <span className="font-semibold">Local Storage Backup Engine</span>
                <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2.5 py-0.5 rounded-full font-bold">Secure Sandbox</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* OVERLAY PANEL: INTERACTIVE APP TEMPLATES GALLERY */}
      <AnimatePresence>
        {showTemplatesGallery && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-md" id="dialog_templates_gallery">
            {/* Backdrop cover */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowTemplatesGallery(false)}
              className="absolute inset-0 cursor-pointer"
            />
            {/* Gallery responsive bento box frame */}
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className={`relative w-full max-w-6xl h-[92vh] sm:h-[85vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden border ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              {/* Top header navigation row */}
              <div className={`p-4 sm:p-5 border-b flex items-center justify-between shrink-0 ${
                isDarkMode ? 'border-slate-800 bg-slate-950/40' : 'border-slate-100 bg-slate-50/50'
              }`}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center shadow-inner">
                    <Sparkles className="w-5 h-5 text-indigo-505 text-indigo-550 text-indigo-500 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold tracking-tight text-indigo-550 dark:text-indigo-400 flex items-center gap-2">
                      <span>Interactive Templates Gallery</span>
                    </h3>
                    <p className={`text-[11px] sm:text-xs mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Select an application template to run instantly or personalize with AI prompt instructions.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowTemplatesGallery(false)}
                  className={`p-1.5 rounded-lg hover:bg-slate-500/10 transition-colors cursor-pointer ${
                    isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-550 hover:text-slate-800'
                  }`}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mobile View tab switcher */}
              <div className="flex lg:hidden grid grid-cols-2 p-1.5 border-b shrink-0 bg-slate-950/20 dark:border-slate-800">
                <button
                  onClick={() => setGalleryMobileTab('catalog')}
                  className={`py-2 text-[11px] font-bold rounded-lg text-center transition-all cursor-pointer ${
                    galleryMobileTab === 'catalog'
                      ? 'bg-indigo-650 bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 dark:text-slate-450'
                  }`}
                >
                  📁 Browse Catalog 
                </button>
                <button
                  onClick={() => setGalleryMobileTab('preview')}
                  className={`py-2 text-[11px] font-bold rounded-lg text-center transition-all cursor-pointer flex items-center justify-center gap-1 ${
                    galleryMobileTab === 'preview'
                      ? 'bg-indigo-650 bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 dark:text-slate-450'
                  }`}
                >
                  💻 Sandbox Preview & AI
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                </button>
              </div>

              {/* Gallery Content layout splits */}
              <div className="flex-grow flex overflow-hidden min-h-0">
                
                {/* COLUMN ONE: TEMPLATES CATALOG LISTING (Responsive Visibility) */}
                <div className={`w-full lg:w-1/2 flex flex-col p-4 sm:p-5 border-r border-slate-100 dark:border-slate-800 overflow-hidden ${
                  galleryMobileTab === 'catalog' ? 'flex' : 'hidden lg:flex'
                }`}>
                  
                  {/* Search bar row */}
                  <div className="relative shrink-0 mb-4">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <Cpu className="w-4 h-4 text-slate-400 animate-pulse" />
                    </span>
                    <input
                      type="text"
                      className={`w-full text-xs pl-9 pr-12 py-2.5 rounded-xl border outline-none placeholder:text-slate-500 font-medium transition-all ${
                        isDarkMode 
                          ? 'bg-slate-950/60 border-slate-800 text-slate-200 focus:border-indigo-500/80 focus:ring-1 focus:ring-indigo-500/20' 
                          : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400/25'
                      }`}
                      placeholder="Search templates by title or framework..."
                      value={gallerySearchQuery}
                      onChange={(e) => setGallerySearchQuery(e.target.value)}
                    />
                    {gallerySearchQuery && (
                      <button
                        onClick={() => setGallerySearchQuery('')}
                        className="absolute inset-y-0 right-0 flex items-center pr-3 font-semibold text-slate-400 hover:text-rose-500 text-xs bg-transparent"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  {/* Template Categories Tabs list */}
                  <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-none shrink-0 border-b border-slate-100 dark:border-slate-800 mb-4 select-none">
                    {[
                      "All Apps",
                      "Games & Fun",
                      "Utility Tools",
                      "Interactive Visuals",
                      "Productivity Apps"
                    ].map(cat => {
                      const count = PRESET_PROJECTS.filter(p => {
                        const matchesCat = cat === 'All Apps' || p.category === cat;
                        const matchesSearch = p.name.toLowerCase().includes(gallerySearchQuery.toLowerCase());
                        return matchesCat && matchesSearch;
                      }).length;

                      return (
                        <button
                          key={cat}
                          onClick={() => setGalleryCategory(cat)}
                          className={`text-[10px] px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-all border flex items-center gap-1.5 cursor-pointer ${
                            galleryCategory === cat
                              ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                              : isDarkMode 
                                ? 'bg-slate-950/40 border-slate-850 text-slate-400 hover:text-white hover:bg-slate-950' 
                                : 'bg-white border-slate-200 text-slate-650 hover:bg-slate-50'
                          }`}
                        >
                          <span>{cat}</span>
                          <span className={`text-[9px] font-mono px-1 rounded-md ${
                            galleryCategory === cat ? 'bg-white/20 text-white' : 'bg-slate-500/10 text-slate-400'
                          }`}>{count}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Scrollable Templates lists */}
                  <div className="flex-grow overflow-y-auto space-y-3 pr-1.5 scrollbar-thin">
                    {PRESET_PROJECTS
                      .filter(p => {
                        const matchesCat = galleryCategory === 'All Apps' || p.category === galleryCategory;
                        const matchesSearch = p.name.toLowerCase().includes(gallerySearchQuery.toLowerCase());
                        return matchesCat && matchesSearch;
                      })
                      .map(preset => {
                        const isSelected = selectedGalleryTemplate.id === preset.id;
                        const htmlLines = preset.html ? preset.html.split('\n').length : 0;
                        const cssLines = preset.css ? preset.css.split('\n').length : 0;
                        const jsLines = preset.javascript ? preset.javascript.split('\n').length : 0;
                        const totalLines = htmlLines + cssLines + jsLines;

                        return (
                          <div
                            key={preset.id}
                            onClick={() => {
                              setSelectedGalleryTemplate(preset);
                              // Auto sync template AI refinement text default option
                              setGalleryAiPrompt('');
                            }}
                            className={`p-4 rounded-2xl cursor-pointer border transition-all text-left relative overflow-hidden group flex items-start gap-4 ${
                              isSelected
                                ? isDarkMode
                                  ? 'border-indigo-550 bg-indigo-500/10 shadow-[0_4px_20px_rgba(99,102,241,0.15)] ring-1 ring-indigo-500/30'
                                  : 'border-indigo-500 bg-indigo-50/50 shadow-[0_4px_20px_rgba(99,102,241,0.08)] ring-1 ring-indigo-500/20'
                                : isDarkMode
                                  ? 'border-slate-800 bg-slate-950/45 hover:border-slate-700 hover:bg-slate-950'
                                  : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70 hover:border-slate-350'
                            }`}
                          >
                            {/* Accent indicators */}
                            {isSelected && (
                              <div className="absolute top-0 right-0 h-full w-1 bg-indigo-500" />
                            )}

                            {/* Circular graphic badge */}
                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                              isSelected 
                                ? 'bg-indigo-600 text-white border-indigo-400/25'
                                : preset.category === 'Games & Fun' 
                                  ? 'bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/10' 
                                  : preset.category === 'Productivity Apps'
                                    ? 'bg-sky-500/10 text-sky-450 border-sky-500/10'
                                    : 'bg-emerald-500/10 text-emerald-450 border-emerald-500/10'
                            }`}>
                              <Cpu className="w-4.5 h-4.5" />
                            </div>

                            <div className="flex-grow min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-extrabold text-xs text-indigo-400 dark:text-indigo-300 group-hover:text-indigo-500 dark:group-hover:text-indigo-400 transition-colors">
                                  {preset.name}
                                </span>
                                {isSelected && (
                                  <span className="text-[8px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-1.5 py-0.5 rounded-md font-extrabold uppercase shrink-0">
                                    Loaded
                                  </span>
                                )}
                              </div>
                              <p className={`text-[11px] leading-relaxed mt-1 line-clamp-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                {preset.id === 'neon-clock' ? 'Retro digital glassmorphic neon glowing dashboard environment showing clock mechanics with high contrast CSS filters.' :
                                 preset.id === 'bouncing-balls' ? 'Interactive physics engine utilizing canvas API rendering gravity simulations, speed modifiers, and cursor tracking.' :
                                 preset.id === 'cool-color-generator' ? 'Harmonious color schemes orchestrator using dynamic HSL configurations, copy shortcuts, and custom popup feedback toasts.' :
                                 preset.id === 'snake-game' ? 'Arcade cabinet 2D classic grid engine built with custom directional controls, score tallies, and high score recorders.' :
                                 'Timeboxing productivity app displaying responsive layout dials, sound notification simulations, and active sequence interval trackers.'}
                              </p>

                              <div className="flex flex-wrap items-center gap-2 mt-3 text-[10px] text-slate-450 dark:text-slate-500">
                                <span className={`px-2 py-0.5 rounded font-extrabold uppercase tracking-wider text-[8px] ${
                                  preset.category === 'Games & Fun' ? 'bg-fuchsia-500/10 text-fuchsia-400 border border-fuchsia-500/15' :
                                  preset.category === 'Productivity Apps' ? 'bg-sky-500/10 text-sky-450 border border-sky-500/15' :
                                  'bg-emerald-500/10 text-emerald-455 dark:text-emerald-450 border border-emerald-500/15'
                                }`}>
                                  {preset.category || 'Utility'}
                                </span>
                                <span>•</span>
                                <span className="font-mono text-[9px]">{totalLines} lines</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                    {PRESET_PROJECTS.filter(p => {
                      const matchesCat = galleryCategory === 'All Apps' || p.category === galleryCategory;
                      const matchesSearch = p.name.toLowerCase().includes(gallerySearchQuery.toLowerCase());
                      return matchesCat && matchesSearch;
                    }).length === 0 && (
                      <div className="text-center py-16 text-slate-500 text-xs border border-dashed rounded-2xl border-slate-800/10 dark:border-slate-800 flex flex-col items-center gap-3">
                        <Cpu className="w-10 h-10 text-slate-600" />
                        <span>No templates match your query criteria in this category.</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Footer loading statistics */}
                  <div className={`mt-4 pt-4 border-t flex justify-between items-center text-[11px] font-mono select-none border-dashed ${
                    isDarkMode ? 'border-slate-800 text-slate-550' : 'border-slate-100 text-slate-450'
                  }`}>
                    <span>Blueprint key: <strong>{selectedGalleryTemplate.id}</strong></span>
                    <button
                      onClick={() => {
                        // Quick Load selection directly
                        loadProject(selectedGalleryTemplate);
                        setShowTemplatesGallery(false);
                      }}
                      className="text-indigo-550 dark:text-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-300 font-extrabold flex items-center gap-1 cursor-pointer bg-transparent"
                    >
                      Instant Load Workspace &rarr;
                    </button>
                  </div>
                </div>

                {/* COLUMN TWO: DYNAMIC LIVE INTERACTIVE PREVIEW & AI SUITE (Responsive Visibility) */}
                <div className={`w-full lg:w-1/2 flex flex-col p-4 sm:p-5 overflow-y-auto ${
                  galleryMobileTab === 'preview' ? 'flex' : 'hidden lg:flex'
                }`}>
                  
                  {/* Detailed Description Header */}
                  <div className="shrink-0 mb-4 bg-gradient-to-r from-indigo-500/5 to-transparent p-4 rounded-xl border border-indigo-500/10 dark:border-indigo-800/20">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      <h4 className="text-sm font-black tracking-tight text-indigo-600 dark:text-indigo-400 uppercase">
                        {selectedGalleryTemplate.name}
                      </h4>
                    </div>
                    <p className={`text-[11px] leading-relaxed mt-1.5 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                      {selectedGalleryTemplate.id === 'neon-clock' ? 'Interactive neon clock with floating RGB ambient glow elements, custom glow filters, and layout modifiers.' :
                       selectedGalleryTemplate.id === 'bouncing-balls' ? 'A canvas sandbox modeling elastic wall collisions, custom gravity multipliers, and drag physics.' :
                       selectedGalleryTemplate.id === 'cool-color-generator' ? 'Harmonious color palette constructor. Copy hex strings automatically and generate random custom layouts.' :
                       selectedGalleryTemplate.id === 'snake-game' ? 'A classic, retro 2D snake grid. Playable immediately: steering directionals, score record keeping, and speed sliders.' :
                       'A fully fledged Pomodoro session planner, integrated zen synth background hum, custom sequence tracker logging.'}
                    </p>
                  </div>

                  {/* ACTIVE LIVE INTERACTIVE IFRAME DEVICE VIEWPORT */}
                  <div className="shrink-0 mb-5">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-500 flex items-center gap-1.5 select-none">
                        <Monitor className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Interactive Sandbox Environment</span>
                      </span>
                      <button
                        onClick={() => {
                          // Quick refresh inside iframe preview
                          const iframe = document.getElementById('preview_gallery_iframe') as any;
                          if (iframe) {
                            iframe.srcdoc = compileTemplateSrcDoc(selectedGalleryTemplate);
                            triggerLocalFeedback("Preview updated!");
                          }
                        }}
                        title="Reload preview sandbox to restore baseline"
                        className={`p-1 px-2.5 rounded-lg text-[10px] font-bold border transition-all flex items-center gap-1 cursor-pointer hover:bg-slate-500/10 ${
                          isDarkMode ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-650'
                        }`}
                      >
                        <RefreshCw className="w-3 h-3 text-indigo-400" />
                        <span>Restart Preview</span>
                      </button>
                    </div>

                    {/* Integrated Device Mockup Container */}
                    <div className={`w-full rounded-2xl overflow-hidden shadow-inner flex flex-col border transition-all aspect-video min-h-[220px] max-h-[300px] ${
                      isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-900 border-slate-250'
                    }`}>
                      {/* Simulated chrome browser header */}
                      <div className="bg-slate-950 p-2 border-b border-white/5 flex items-center justify-between px-4 shrink-0 select-none">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-500/60" />
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
                        </div>
                        <span className="text-[9px] font-mono text-slate-400 lowercase tracking-wider truncate max-w-[180px]">
                          preview-{selectedGalleryTemplate.id}.localhost
                        </span>
                        <div className="w-4 h-4 rounded-full bg-white/5 flex items-center justify-center">
                          <span className="text-[8px] text-slate-400 font-bold">↻</span>
                        </div>
                      </div>

                      {/* Clean Sandbox execution frame */}
                      <iframe
                        id="preview_gallery_iframe"
                        srcDoc={compileTemplateSrcDoc(selectedGalleryTemplate)}
                        title="Isolated template sandbox player"
                        className="w-full flex-grow border-none bg-black/5"
                        sandbox="allow-scripts allow-same-origin allow-modals"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>

                  {/* AI INTEGRATIONS SUITE: EDIT TEMPLATE WITH AI */}
                  <div className={`p-4 rounded-2xl border mb-4 ${
                    isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50/70 border-slate-200'
                  }`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Wand2 className="w-4.5 h-4.5 text-amber-500 animate-pulse" />
                      <h4 className="text-xs font-extrabold uppercase text-amber-600 dark:text-amber-550 tracking-wider">
                        Personalize Template with AI Helper
                      </h4>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-relaxed mb-3">
                      Instruct Gemini how to upgrade or customize <strong className="text-indigo-400">{selectedGalleryTemplate.name}</strong>, and watch it draft, compile, and present the refactored delta instantly!
                    </p>

                    {/* Modification Form */}
                    <div className="space-y-2">
                      <div className="relative">
                        <input
                          type="text"
                          className={`w-full text-xs pl-3.5 pr-12 py-2.5 rounded-xl border outline-none placeholder:text-slate-400 font-medium transition-all ${
                            isDarkMode
                              ? 'bg-slate-900 border-slate-800 text-slate-200 focus:border-indigo-500'
                              : 'bg-white border-slate-200 text-slate-800 focus:border-indigo-400'
                          }`}
                          placeholder="What changes do you envision? (e.g. 'Add sound indicators' or 'Change layout into Roman style')..."
                          value={galleryAiPrompt}
                          onChange={(e) => setGalleryAiPrompt(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && galleryAiPrompt.trim()) {
                              handleEditTemplateWithAi(selectedGalleryTemplate, galleryAiPrompt);
                            }
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (galleryAiPrompt.trim()) {
                              handleEditTemplateWithAi(selectedGalleryTemplate, galleryAiPrompt);
                            }
                          }}
                          disabled={!galleryAiPrompt.trim()}
                          className={`absolute right-1.5 top-1.5 bottom-1.5 p-1 px-3.5 rounded-lg text-[10px] font-extrabold text-white flex items-center gap-1 cursor-pointer transition-all ${
                            galleryAiPrompt.trim() 
                              ? 'bg-amber-600 hover:bg-amber-500 shadow-md' 
                              : 'bg-slate-800/80 text-slate-450 border border-slate-700/50 cursor-not-allowed'
                          }`}
                        >
                          <Wand2 className="w-3 h-3 text-amber-300" />
                          <span>AI Refine</span>
                        </button>
                      </div>

                      {/* Smart preset suggestions badged buttons */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[9px] text-slate-505 dark:text-slate-500 font-bold uppercase mr-1 select-none">Upgrades:</span>
                        {(selectedGalleryTemplate.category === 'Games & Fun'
                          ? ["Make colors pulsing RGB neon", "Add a retro high score leaderboard HUD", "Inject classic arcade sound simulators"]
                          : selectedGalleryTemplate.category === 'Interactive Visuals'
                            ? ["Make it support beautiful reactive soundwaves", "Render light glass themes on double click", "Slow down background animation drift speed"]
                            : ["Translate instructions to Spanish locale", "Add full system dark-mode toggles", "Enlarge layout touch dimensions for phones"]
                        ).map((idea, idx) => (
                          <button
                            key={idx}
                            onClick={() => setGalleryAiPrompt(`Modify this template: ${idea}`)}
                            className={`text-[9.5px] px-2 py-0.5 rounded transition-all hover:border-amber-400 text-left border cursor-pointer select-none leading-normal ${
                              isDarkMode
                                ? 'bg-slate-950/40 border-slate-850 hover:bg-slate-900 text-slate-400 hover:text-white'
                                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            ⚡ {idea}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* BOTTOM ACTION BUTTONS */}
                  <div className="mt-auto grid grid-cols-2 gap-3 shrink-0 pt-3 border-t border-dashed border-slate-100 dark:border-slate-850">
                    <button
                      type="button"
                      onClick={() => {
                        // Action cancel, close gallery
                        setShowTemplatesGallery(false);
                      }}
                      className={`py-3 text-xs font-bold rounded-xl transition-all border cursor-pointer text-center ${
                        isDarkMode
                          ? 'border-slate-800 hover:bg-slate-800 text-slate-350 hover:text-white bg-slate-950/20'
                          : 'border-slate-200 hover:bg-slate-100 text-slate-600 bg-white'
                      }`}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      id="btn_load_gallery_choice"
                      onClick={() => {
                        // Instant loading action
                        loadProject(selectedGalleryTemplate);
                        setShowTemplatesGallery(false);
                      }}
                      className="py-3 text-xs font-extrabold rounded-xl text-white bg-indigo-600 hover:bg-indigo-500 hover:scale-[1.01] shadow-[0_4px_15px_rgba(99,102,241,0.3)] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5 text-indigo-200" />
                      <span>One-Click Load Template</span>
                    </button>
                  </div>

                </div>
              </div>

              {/* Console Foot bounds details */}
              <div className={`p-4 border-t text-[11px] font-medium text-slate-500 flex justify-between items-center select-none ${
                isDarkMode ? 'border-slate-800 bg-slate-950' : 'border-slate-100 bg-slate-50/50'
              }`}>
                <span>To revert loaded files, simple click "Versions" panel inside active toolbar to restore.</span>
                <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-3 py-1 rounded-full font-bold">Safe Sandbox Sandbox</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SAVE PROJECT MODAL DIALOG */}
      <AnimatePresence>
        {showSaveAsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" id="dialog_save_modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-sm rounded-2xl shadow-2xl p-6 ${
                isDarkMode ? 'bg-slate-900 border border-slate-800' : 'bg-white border text-slate-800'
              }`}
            >
              <h3 className="text-sm font-bold mb-1">Save Workspace As</h3>
              <p className="text-[11px] text-slate-400 mb-4">Store your changes in a new project name</p>
              
              <form onSubmit={handleSaveAsModalSubmit}>
                <input
                  id="input_save_name"
                  type="text"
                  required
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  placeholder="Enter a descriptive project name"
                  className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-transparent text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none mb-4"
                  maxLength={40}
                  autoFocus
                />
                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowSaveAsModal(false)}
                    className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-505 text-white shadow"
                  >
                    Save Project
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* NEW PROJECT MODAL DIALOG */}
      <AnimatePresence>
        {showNewProjectModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm" id="dialog_new_project_modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-xl rounded-2xl shadow-2xl p-6 border ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                    <PlusCircle className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold tracking-tight">Create New Workspace</h3>
                    <p className="text-[11px] text-slate-400">Bootstrap a fresh coding workspace sandbox</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowNewProjectModal(false)}
                  className="p-1 rounded-lg hover:bg-slate-500/15"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-4">
                {/* Project Title Input */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1.5">Project Name</label>
                  <input
                    id="input_new_project_name"
                    type="text"
                    required
                    value={newProjectNameVal}
                    onChange={(e) => setNewProjectNameVal(e.target.value)}
                    placeholder="e.g. Simple Landing Page, Interstellar Banner"
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs focus:ring-1 focus:outline-none ${
                      isDarkMode 
                        ? 'border-slate-805 border-slate-800 bg-slate-950 text-white focus:ring-indigo-500' 
                        : 'border-slate-200 bg-slate-50 text-slate-800 focus:ring-indigo-500'
                    }`}
                    maxLength={32}
                    autoFocus
                  />
                </div>

                {/* Template Choices */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1.5">Select a Starter Template</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[220px] overflow-y-auto pr-1">
                    {/* Blank Template option */}
                    <div
                      onClick={() => setNewProjectTemplate('blank')}
                      className={`p-3 rounded-xl cursor-pointer border text-left transition-all flex flex-col justify-between h-[105px] min-h-[105px] ${
                        newProjectTemplate === 'blank'
                          ? 'border-emerald-500 bg-emerald-500/5'
                          : isDarkMode ? 'border-slate-800 bg-slate-950/45 hover:border-slate-700' : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs flex items-center gap-1.5">
                          <Plus className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Blank Sandbox</span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">
                          Start with a completely clean dynamic markup sandbox.
                        </p>
                      </div>
                      <span className="text-[9px] text-indigo-400/90 font-mono font-medium">Clear Canvas Layout</span>
                    </div>

                    {/* Presets options */}
                    {PRESET_PROJECTS.map(preset => (
                      <div
                        key={preset.id}
                        onClick={() => setNewProjectTemplate(preset.id)}
                        className={`p-3 rounded-xl cursor-pointer border text-left transition-all flex flex-col justify-between h-[105px] min-h-[105px] ${
                          newProjectTemplate === preset.id
                            ? 'border-emerald-500 bg-emerald-500/5'
                            : isDarkMode ? 'border-slate-800 bg-slate-950/45 hover:border-slate-700' : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                        }`}
                      >
                        <div>
                          <div className="font-bold text-xs flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                            <span className="truncate">{preset.name}</span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">
                            Load interactive creative sandbox example content.
                          </p>
                        </div>
                        <span className="text-[9px] text-cyan-400/90 font-mono font-medium">Boilerplate Blueprint</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                  <button
                    onClick={() => setShowNewProjectModal(false)}
                    className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-450 hover:text-rose-450 text-slate-400 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      const finalName = newProjectNameVal.trim() || `My Sandbox Proj #${Date.now().toString().slice(-4)}`;
                      createNewProject(finalName, newProjectTemplate);
                    }}
                    className="px-5 py-2.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg transition-all"
                  >
                    Create Workspace
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* CLEAR CONFIRMATION DIALOG */}
      <AnimatePresence>
        {showClearConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" id="dialog_clear_modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-sm rounded-2xl p-6 shadow-2xl border ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white text-slate-800 border-slate-200'
              }`}
            >
              <h3 className="text-sm font-bold text-red-400 mb-1">Wipe All Active Code?</h3>
              <p className="text-[11px] text-slate-400 mb-4">This resets the active HTML, CSS and JS tabs. Your saved files are safe.</p>
              
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white"
                >
                  Keep Code
                </button>
                <button
                  onClick={triggerClear}
                  className="px-4 py-2 text-xs font-bold rounded-lg bg-red-600 hover:bg-red-500 text-white"
                >
                  Clear Everything
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ANDROID APP PACKAGING ASSISTANT MODAL */}
      <AnimatePresence>
        {showAndroidPackagerModal && (() => {
          const { score, issues, hasViewport, hasResponsiveClasses, touchReadyStyles, touchEventsCount, detectedType, effectiveType } = analyzeProjectForMobile();
          
          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm shadow-2xl" id="dialog_android_packager_modal">
              <motion.div
                initial={{ scale: 0.96, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.96, opacity: 0 }}
                transition={{ duration: 0.18 }}
                className={`w-full max-w-3xl rounded-2xl p-6 border flex flex-col max-h-[88vh] overflow-hidden ${
                  isDarkMode 
                    ? 'bg-slate-900 border-slate-800 text-white' 
                    : 'bg-white text-slate-800 border-slate-200'
                }`}
              >
                {/* Header */}
                <div className="flex justify-between items-start pb-4 border-b border-indigo-500/10 shrink-0">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
                      <Smartphone className="w-6 h-6 shrink-0 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold tracking-tight">Android App Packaging Assistant</h3>
                      <p className="text-xs text-slate-400">Scan sandbox code, configure Capacitor, and compile local ready APK folders.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowAndroidPackagerModal(false)}
                    className="p-1 rounded-lg hover:bg-slate-500/15 text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Tabs Bar */}
                <div className="flex items-center gap-2 border-b border-indigo-500/10 px-1 py-2 overflow-x-auto shrink-0 font-mono text-xs">
                  <button
                    onClick={() => setPackagerActiveTab('analyze')}
                    className={`px-4 py-2 rounded-lg font-bold transition-all shrink-0 ${
                      packagerActiveTab === 'analyze'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent'
                    }`}
                  >
                    🔍 1. Mobile Analyzer ({score}%)
                  </button>
                  <button
                    onClick={() => setPackagerActiveTab('config')}
                    className={`px-4 py-2 rounded-lg font-bold transition-all shrink-0 ${
                      packagerActiveTab === 'config'
                        ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent'
                    }`}
                  >
                    ⚙️ 2. Capacitor Config
                  </button>
                  <button
                    onClick={() => setPackagerActiveTab('export')}
                    className={`px-4 py-2 rounded-lg font-bold transition-all shrink-0 ${
                      packagerActiveTab === 'export'
                        ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent'
                    }`}
                  >
                    📦 3. Create APK Export Workflows
                  </button>
                  <button
                    onClick={() => setPackagerActiveTab('docs')}
                    className={`px-4 py-2 rounded-lg font-bold transition-all shrink-0 ${
                      packagerActiveTab === 'docs'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent'
                    }`}
                  >
                    📖 4. Build Instructions
                  </button>
                  <button
                    onClick={() => setPackagerActiveTab('playStoreReady')}
                    className={`px-4 py-2 rounded-lg font-bold transition-all shrink-0 ${
                      packagerActiveTab === 'playStoreReady'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'text-slate-450 text-slate-400 hover:text-emerald-300 hover:bg-slate-800/40 border border-transparent'
                    }`}
                  >
                    🚀 5. Play Store (APK/AAB)
                  </button>
                </div>

                {/* Tab content scroll-container */}
                <div className="flex-grow overflow-y-auto py-4 space-y-4 pr-1">
                  
                  {packagerActiveTab === 'analyze' && (
                    <div className="space-y-4 font-sans">
                      {/* Score metric banner card */}
                      <div className={`p-5 rounded-2xl border flex flex-col md:flex-row items-center gap-6 justify-between ${
                        score >= 80 
                          ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' 
                          : score >= 50 
                            ? 'bg-amber-500/5 border-amber-500/20 text-amber-400' 
                            : 'bg-red-500/5 border-red-500/20 text-red-500'
                      }`}>
                        <div className="flex items-center gap-4">
                          {/* Circle Progress Gauge */}
                          <div className="relative w-16 h-16 flex items-center justify-center">
                            <span className="absolute font-mono text-base font-extrabold">{score}%</span>
                            <svg className="w-16 h-16 transform -rotate-90">
                              <circle 
                                cx="32" 
                                cy="32" 
                                r="28" 
                                className="stroke-slate-705 stroke-slate-700 fill-none" 
                                strokeWidth="4" 
                              />
                              <circle 
                                cx="32" 
                                cy="32" 
                                r="28" 
                                stroke={score >= 80 ? '#10b981' : score >= 50 ? '#f59e0b' : '#ef4444'}
                                className="fill-none transition-all duration-500" 
                                strokeWidth="4" 
                                strokeDasharray="176" 
                                strokeDashoffset={176 - (176 * score) / 100}
                              />
                            </svg>
                          </div>
                          <div>
                            <h4 className="text-sm font-bold uppercase tracking-wide">
                              {score >= 80 ? 'Mobile Ready! ✨' : score >= 50 ? 'Partially Mobile Friendly ⚠️' : 'Optimizations Suggested 🚨'}
                            </h4>
                            <p className="text-xs text-slate-400 mt-1 max-w-sm">
                              {score >= 80 
                                ? 'Prerequisites checked. Layout configurations are optimized for tablet and phone displays.' 
                                : 'Missing viewport tags or flex layouts might distort rendering across standard Android containers.'}
                            </p>
                          </div>
                        </div>

                        {/* Viewport repair injector button */}
                        {!hasViewport && (
                          <button
                            onClick={autoFixViewport}
                            className="px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-lg transition-transform hover:scale-[1.02] shrink-0"
                          >
                            ⚡ Auto-Fix: Injected Viewport Tag
                          </button>
                        )}
                      </div>

                      {/* Project Type Classification Selector & Banner */}
                      <div className={`p-4 rounded-xl border flex flex-col gap-3 ${isDarkMode ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                          <div>
                            <h4 className="text-xs font-bold text-slate-250 flex items-center gap-1.5 font-sans">
                              <Layers className="w-3.5 h-3.5 text-indigo-400" />
                              <span>Project Type Classification</span>
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-0.5">We analyze your active workspace layouts to optimize Android packaging pathways.</p>
                          </div>
                          
                          {/* Selector button group */}
                          <div className="flex items-center gap-1.5 p-0.5 rounded-lg bg-slate-950 border border-slate-800 self-start sm:self-center font-mono text-[9px]">
                            <button
                              onClick={() => setProjectTypeOverride('AUTO')}
                              className={`px-2 py-1 rounded transition-all font-bold cursor-pointer ${projectTypeOverride === 'AUTO' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
                            >
                              Auto-Detect
                            </button>
                            <button
                              onClick={() => setProjectTypeOverride('PWA')}
                              className={`px-2 py-1 rounded transition-all font-bold cursor-pointer ${projectTypeOverride === 'PWA' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
                            >
                              PWA
                            </button>
                            <button
                              onClick={() => setProjectTypeOverride('HTML')}
                              className={`px-2 py-1 rounded transition-all font-bold cursor-pointer ${projectTypeOverride === 'HTML' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
                            >
                              HTML
                            </button>
                            <button
                              onClick={() => setProjectTypeOverride('Android')}
                              className={`px-2 py-1 rounded transition-all font-bold cursor-pointer ${projectTypeOverride === 'Android' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
                            >
                              Android
                            </button>
                          </div>
                        </div>

                        {/* Status visual box based on current effectiveType */}
                        <div className={`p-3 rounded-xl border flex items-center gap-3 transition-all ${
                          effectiveType === 'PWA Project'
                            ? 'bg-purple-500/10 border-purple-500/20 text-purple-300'
                            : effectiveType === 'Android Project'
                              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                              : 'bg-sky-500/10 border-sky-500/20 text-sky-300'
                        }`}>
                          <div className="text-xl shrink-0">
                            {effectiveType === 'PWA Project' ? '📱' : effectiveType === 'Android Project' ? '🤖' : '🌐'}
                          </div>
                          <div>
                            <p className="text-xs font-bold font-sans flex items-center gap-2">
                              <span>Active Blueprint: {effectiveType}</span>
                              {projectTypeOverride === 'AUTO' && (
                                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-400 tracking-wider">AUTO-DETECTED</span>
                              )}
                            </p>
                            <p className="text-[10px] text-slate-400 mt-0.5 leading-normal">
                              {effectiveType === 'PWA Project' && "PWA target active. We will package your web manifest, background service workers, and interactive layouts. Gradelw compilation is bypassed automatically during exports to safeguard offline runtime rules."}
                              {effectiveType === 'Android Project' && "Native Hybrid Android target active. Ready to deploy Capacitor wrapper integrations with hardware optimizations, back-button listeners, and localized gradle configuration scripts."}
                              {effectiveType === 'HTML Project' && "Standard HTML5 static workspace active. Optimizing pure responsive frame scaling, touch margins, and fluid multi-viewport css styles."}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Score Items Breakdown */}
                      <div>
                        <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">Diagnostic Metrics Overview</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${isDarkMode ? 'bg-slate-950/50 border-slate-800' : 'bg-slate-50 border-slate-250'}`}>
                            {hasViewport ? (
                              <span className="text-emerald-500 text-xs shrink-0">✅</span>
                            ) : (
                              <span className="text-red-500 text-xs shrink-0">⚠️</span>
                            )}
                            <div>
                              <p className="text-xs font-bold">Mobile Viewport configuration</p>
                              <p className="text-[10px] text-slate-400 mt-0.5">{hasViewport ? 'Passes standard scaling guides.' : 'Will look shrunk without auto viewport scaling.'}</p>
                            </div>
                          </div>

                          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${isDarkMode ? 'bg-slate-950/50 border-slate-800' : 'bg-slate-50 border-slate-250'}`}>
                            {hasResponsiveClasses ? (
                              <span className="text-emerald-500 text-xs shrink-0">✅</span>
                            ) : (
                              <span className="text-amber-500 text-xs shrink-0">⚠️</span>
                            )}
                            <div>
                              <p className="text-xs font-bold">Fluid Responsive Containers</p>
                              <p className="text-[10px] text-slate-400 mt-0.5">{hasResponsiveClasses ? 'Found style adapters or media sheets.' : 'No md: prefixes or width margins traced.'}</p>
                            </div>
                          </div>

                          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${isDarkMode ? 'bg-slate-950/50 border-slate-800' : 'bg-slate-50 border-slate-250'}`}>
                            {touchReadyStyles ? (
                              <span className="text-emerald-500 text-xs shrink-0">✅</span>
                            ) : (
                              <span className="text-amber-500 text-xs shrink-0">⚠️</span>
                            )}
                            <div>
                              <p className="text-xs font-bold">Touch Friendly Target Sizing</p>
                              <p className="text-[10px] text-slate-400 mt-0.5">Determined standard heights, paddings, and bounds.</p>
                            </div>
                          </div>

                          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${isDarkMode ? 'bg-slate-950/50 border-slate-800' : 'bg-slate-50 border-slate-250'}`}>
                            {touchEventsCount > 0 ? (
                              <span className="text-emerald-500 text-xs shrink-0">✅</span>
                            ) : (
                              <span className="text-amber-500 text-xs shrink-0">⚠️</span>
                            )}
                            <div>
                              <p className="text-xs font-bold">Interactive Callback Handlers</p>
                              <p className="text-[10px] text-slate-400 mt-0.5">Discovered {touchEventsCount} responsive trigger callbacks.</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Outstanding Issues lists */}
                      {issues.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Suggested Action Items</h4>
                          {issues.map(iss => (
                            <div 
                              key={iss.id}
                              className={`p-3 rounded-xl border flex gap-3 text-xs leading-relaxed ${
                                iss.severity === 'high' 
                                  ? 'bg-red-500/5 border-red-500/10' 
                                  : 'bg-slate-800/30 border-slate-800'
                              }`}
                            >
                              <span className="text-base shrink-0">{iss.severity === 'high' ? '🛑' : '⚠️'}</span>
                              <div className="flex-grow">
                                <p className="font-bold text-inherit">{iss.title}</p>
                                <p className="text-[11px] text-slate-400 mt-0.5">{iss.desc}</p>
                              </div>
                              {iss.fixable && (
                                <button
                                  onClick={autoFixViewport}
                                  className="self-center px-2.5 py-1 text-[10px] font-bold bg-amber-600 hover:bg-amber-500 text-white rounded-lg transition-transform hover:scale-[1.02] shrink-0"
                                >
                                  Fix Viewport
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {packagerActiveTab === 'config' && (
                    <div className="space-y-4 font-sans">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* App Label */}
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Android App Label</label>
                          <input
                            type="text"
                            value={packagerAppName}
                            onChange={(e) => setPackagerAppName(e.target.value)}
                            placeholder="e.g. My Amazing Dashboard"
                            className={`w-full px-3 py-2 rounded-xl text-xs focus:ring-1 focus:outline-none ${
                              isDarkMode ? 'bg-slate-950 border-slate-800 text-white focus:ring-indigo-500' : 'bg-slate-100 border-slate-200 text-slate-800 focus:ring-indigo-500'
                            }`}
                          />
                        </div>

                        {/* Package App ID */}
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 font-mono">Application Package ID</label>
                          <input
                            type="text"
                            value={packagerAppID}
                            onChange={(e) => setPackagerAppID(e.target.value)}
                            placeholder="e.g. com.company.app"
                            className={`w-full px-3 py-2 rounded-xl text-xs focus:ring-1 focus:outline-none font-mono ${
                              isDarkMode ? 'bg-slate-950 border-slate-800 text-white focus:ring-indigo-500' : 'bg-slate-100 border-slate-200 text-slate-800 focus:ring-indigo-500'
                            }`}
                          />
                          <p className="text-[9px] text-slate-400 mt-1 italic font-mono">Unique ID required for Android store indexing.</p>
                        </div>
                      </div>

                      {/* Live manifest and JSON viewer */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono">capacitor.config.json</label>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(generateCapacitorConfig(packagerAppName, packagerAppID));
                              triggerLocalFeedback("Copied Capacitor config to clipboard!");
                            }}
                            className="text-[10px] text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                          >
                            <Copy className="w-3 h-3" /> Copy Config
                          </button>
                        </div>
                        <pre className={`p-4 rounded-xl text-[11px] font-mono leading-relaxed overflow-x-auto border ${
                          isDarkMode ? 'bg-slate-950 border-slate-800/80 text-emerald-400' : 'bg-slate-50 border-slate-220 text-indigo-600'
                        }`}>
                          {generateCapacitorConfig(packagerAppName, packagerAppID)}
                        </pre>
                      </div>
                    </div>
                  )}

                  {packagerActiveTab === 'export' && (
                    <div className="space-y-4 font-sans animate-fadeIn">
                      {/* Big call to action panel */}
                      <div className={`p-6 rounded-2xl text-center border ${
                        isDarkMode ? 'bg-indigo-950/20 border-indigo-500/20' : 'bg-indigo-50/50 border-indigo-100'
                      }`}>
                        <div className="mx-auto w-12 h-12 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-3">
                          <Download className="w-6 h-6 animate-bounce" />
                        </div>
                        <h4 className="text-sm font-bold animate-pulse">Download Native Capacitor Boilerplate ZIP</h4>
                        <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 leading-relaxed">
                          We will bundle your active screen assets together with configured dependencies inside a unified package ready for deployment with Node & Gradle tools.
                        </p>

                        <button
                          onClick={handleDownloadCapacitorZip}
                          className="mt-4 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-extrabold shadow-lg shadow-indigo-650/15 hover:shadow-indigo-650/30 transition-transform hover:scale-[1.01] inline-flex items-center gap-2"
                        >
                          <Archive className="w-4 h-4" /> Download Build ZIP
                        </button>
                      </div>

                      {/* File outline card list */}
                      <div>
                        <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 font-mono">Structure of compiled ZIP package:</h4>
                        <div className={`rounded-xl border p-3 divide-y divide-slate-800/20 ${isDarkMode ? 'bg-slate-950/50 border-slate-800 font-sans' : 'bg-slate-100 border-slate-200'}`}>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono">
                            <span className="text-slate-300">📂 www/</span>
                            <span className="text-slate-500 text-[10px]">Embedded web build workspace</span>
                          </div>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono pl-4">
                            <span className="text-slate-300">📄 www/index.html</span>
                            <span className="text-slate-500 text-[10px]">Responsive frame layout + viewport config</span>
                          </div>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono pl-4">
                            <span className="text-slate-300">📄 www/style.css</span>
                            <span className="text-slate-500 text-[10px]">Styling declarations compiled</span>
                          </div>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono pl-4">
                            <span className="text-slate-300">📄 www/script.js</span>
                            <span className="text-slate-500 text-[10px]">Sandbox browser scripts bundle</span>
                          </div>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono">
                            <span className="text-slate-300">⚙️ capacitor.config.json</span>
                            <span className="text-slate-500 text-[10px]">Main bundle configuration</span>
                          </div>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono">
                            <span className="text-slate-300">📦 package.json</span>
                            <span className="text-slate-500 text-[10px]">Synchronizing Capacitor dependency registry</span>
                          </div>
                          <div className="py-1.5 flex items-center justify-between text-xs font-mono">
                            <span className="text-slate-300">📄 BUILD_INSTRUCTIONS.md</span>
                            <span className="text-slate-500 text-[10px]">Step by step local compilation guide</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {packagerActiveTab === 'docs' && (
                    <div className="space-y-4 font-sans leading-relaxed text-xs">
                      <div className="space-y-3">
                        <div className={`p-3.5 rounded-xl border ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <p className="font-bold flex items-center gap-1.5">
                            <span className="text-indigo-400">Step 1.</span> Extract & Install Build CLI Tools
                          </p>
                          <p className="text-slate-400 mt-1 text-[11px]">Unpack the downloaded ZIP and execute standard node installations:</p>
                          <pre className="p-2 bg-slate-950 rounded border border-slate-800 font-mono text-[10.5px] mt-1.5 text-indigo-305 text-indigo-300 flex items-center justify-between overflow-x-auto">
                            <span>npm install</span>
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText("npm install");
                                triggerLocalFeedback("Copied install command!");
                              }}
                              className="opacity-70 hover:opacity-100 font-sans font-bold text-[10px]"
                            >
                              Copy
                            </button>
                          </pre>
                        </div>

                        <div className={`p-3.5 rounded-xl border ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <p className="font-bold flex items-center gap-1.5">
                            <span className="text-indigo-400">Step 2.</span> Install Capacitor Android & Sync Platforms
                          </p>
                          <p className="text-slate-400 mt-1 text-[11px]">Add local android platforms and perform asset synchronized mappings:</p>
                          <pre className="p-2 bg-slate-950 rounded border border-slate-800 font-mono text-[10.5px] mt-1.5 text-indigo-300 flex items-center justify-between overflow-x-auto">
                            <span>npx cap add android && npx cap sync</span>
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText("npx cap add android && npx cap sync");
                                triggerLocalFeedback("Copied sync command!");
                              }}
                              className="opacity-70 hover:opacity-100 font-sans font-bold text-[10px]"
                            >
                              Copy
                            </button>
                          </pre>
                        </div>

                        <div className={`p-3.5 rounded-xl border ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <p className="font-bold flex items-center gap-1.5">
                            <span className="text-indigo-400">Step 3.</span> Open in Android Studio & Compile APK
                          </p>
                          <p className="text-slate-400 mt-1 text-[11px]">Boot the native project context inside Android Studio to target debug or release keys:</p>
                          <pre className="p-2 bg-slate-950 rounded border border-slate-800 font-mono text-[10.5px] mt-1.5 text-indigo-300 flex items-center justify-between overflow-x-auto">
                            <span>npx cap open android</span>
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText("npx cap open android");
                                triggerLocalFeedback("Copied open command!");
                              }}
                              className="opacity-70 hover:opacity-100 font-sans font-bold text-[10px]"
                            >
                              Copy
                            </button>
                          </pre>
                        </div>

                        <div className={`p-3.5 rounded-xl border ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <p className="font-bold flex items-center gap-1.5">
                            <span className="text-indigo-400">Alternative.</span> Command Line Compilation (Gradle Wrapper)
                          </p>
                          <p className="text-slate-400 mt-1 text-[11px]">Compile direct debug binaries without waiting for Android Studio GUI to start:</p>
                          <pre className="p-2 bg-slate-950 rounded border border-slate-800 font-mono text-[10.5px] mt-1.5 text-indigo-300 flex items-center justify-between overflow-x-auto">
                            <span>cd android && ./gradlew assembleDebug</span>
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText("cd android && ./gradlew assembleDebug");
                                triggerLocalFeedback("Copied Gradle build command!");
                              }}
                              className="opacity-70 hover:opacity-100 font-sans font-bold text-[10px]"
                            >
                              Copy
                            </button>
                          </pre>
                        </div>
                      </div>
                    </div>
                  )}

                  {packagerActiveTab === 'playStoreReady' && (
                    <div className="space-y-4 font-sans text-xs">
                      <div className="flex items-center gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                        <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg shrink-0">
                          <Sparkles className="w-5 h-5 animate-pulse" />
                        </div>
                        <div>
                          <p className="font-bold text-sm text-emerald-400">Play Store Ready Native Wrapper</p>
                          <p className="text-[11px] text-slate-300 mt-0.5">
                            Convert your PWA to an ultra-optimized native Android Gradle workspace supporting adaptive launcher icons, immersive UI, and GitHub Actions CD compile engines.
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Column 1: Configs */}
                        <div className={`p-4 rounded-xl border flex flex-col gap-3.5 ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <h4 className="font-bold text-slate-200 flex items-center gap-1.5 border-b border-indigo-500/10 pb-2">
                            <Settings className="w-3.5 h-3.5 text-indigo-400" />
                            <span>1. App Manifest & Identity</span>
                          </h4>

                          <div className="space-y-3">
                            <div>
                              <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">App Label Name</label>
                              <input
                                type="text"
                                value={packagerAppName}
                                onChange={(e) => setPackagerAppName(e.target.value)}
                                placeholder="My App"
                                className={`w-full px-3 py-1.5 text-xs font-semibold rounded-lg border focus:ring-1 focus:ring-indigo-500 outline-none ${
                                  isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-800'
                                }`}
                              />
                            </div>

                            <div>
                              <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Application ID (Package ID)</label>
                              <input
                                type="text"
                                value={packagerAppID}
                                onChange={(e) => setPackagerAppID(e.target.value)}
                                placeholder="com.company.myapp"
                                className={`w-full px-3 py-1.5 text-xs font-semibold rounded-lg border focus:ring-1 focus:ring-indigo-500 outline-none ${
                                  isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-800'
                                }`}
                              />
                            </div>

                            <div>
                              <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Mobilization Optimizations</label>
                              <div className="space-y-2">
                                <label className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-white transition-colors">
                                  <input
                                    type="checkbox"
                                    checked={playStoreIsImmersive}
                                    onChange={(e) => setPlayStoreIsImmersive(e.target.checked)}
                                    className="mt-0.5 rounded text-emerald-500 focus:ring-0 border-slate-700 bg-slate-900"
                                  />
                                  <div>
                                    <p className="font-semibold text-[11px] leading-none">Immersive Fullscreen Viewport</p>
                                    <p className="text-[10px] text-slate-400 mt-1">Hides status headers and navigation pill bars natively for immersive layouts.</p>
                                  </div>
                                </label>

                                <label className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-white transition-colors">
                                  <input
                                    type="checkbox"
                                    checked={playStoreIsHardwareAccelerated}
                                    onChange={(e) => setPlayStoreIsHardwareAccelerated(e.target.checked)}
                                    className="mt-0.5 rounded text-emerald-500 focus:ring-0 border-slate-700 bg-slate-900"
                                  />
                                  <div>
                                    <p className="font-semibold text-[11px] leading-none">GPU Hardware Acceleration</p>
                                    <p className="text-[10px] text-slate-400 mt-1">Forces GPU hardware-accelerated paint pipelines to achieve 60 FPS transitions.</p>
                                  </div>
                                </label>

                                <label className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-white transition-colors">
                                  <input
                                    type="checkbox"
                                    checked={playStoreIsBackButtonIntercepted}
                                    onChange={(e) => setPlayStoreIsBackButtonIntercepted(e.target.checked)}
                                    className="mt-0.5 rounded text-emerald-500 focus:ring-0 border-slate-700 bg-slate-900"
                                  />
                                  <div>
                                    <p className="font-semibold text-[11px] leading-none">Hardware Back Navigation Routing</p>
                                    <p className="text-[10px] text-slate-400 mt-1">Intercepts back press events to trigger page history return inside container.</p>
                                  </div>
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Column 2: Launcher Icon Assets */}
                        <div className={`p-4 rounded-xl border flex flex-col gap-3.5 ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <h4 className="font-bold text-slate-200 flex items-center gap-1.5 border-b border-indigo-500/10 pb-2">
                            <Palette className="w-3.5 h-3.5 text-indigo-400" />
                            <span>2. Brand Assets & Launcher Icon</span>
                          </h4>

                          <div className="grid grid-cols-2 gap-3.5">
                            {/* Controls */}
                            <div className="space-y-3">
                              <div>
                                <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Adaptive Shape</label>
                                <select
                                  value={playStoreIconShape}
                                  onChange={(e: any) => setPlayStoreIconShape(e.target.value)}
                                  className={`w-full px-2 py-1 text-xs rounded border outline-none cursor-pointer ${
                                    isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-800'
                                  }`}
                                >
                                  <option value="squircle">Squircle</option>
                                  <option value="circle">Circle</option>
                                  <option value="rounded-rect">Rounded Square</option>
                                </select>
                              </div>

                              <div>
                                <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Badge Letters</label>
                                <input
                                  type="text"
                                  maxLength={3}
                                  value={playStoreIconText}
                                  onChange={(e) => setPlayStoreIconText(e.target.value.toUpperCase())}
                                  placeholder="APP"
                                  className={`w-full px-2 py-1 text-xs font-bold rounded border outline-none text-center ${
                                    isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-800'
                                  }`}
                                />
                              </div>

                              <div>
                                <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Color Palette</label>
                                <div className="flex gap-2 items-center">
                                  <div className="flex flex-col items-center gap-0.5">
                                    <input
                                      type="color"
                                      value={playStoreIconBgColor}
                                      onChange={(e) => setPlayStoreIconBgColor(e.target.value)}
                                      className="w-7 h-7 rounded border border-slate-800 cursor-pointer"
                                    />
                                    <span className="text-[9px] text-slate-400">Bg</span>
                                  </div>

                                  <div className="flex flex-col items-center gap-0.5">
                                    <input
                                      type="color"
                                      value={playStoreIconTextColor}
                                      onChange={(e) => setPlayStoreIconTextColor(e.target.value)}
                                      className="w-7 h-7 rounded border border-slate-800 cursor-pointer"
                                    />
                                    <span className="text-[9px] text-slate-400">Emblem</span>
                                  </div>

                                  <div className="flex flex-col items-center gap-0.5">
                                    <input
                                      type="color"
                                      value={playStoreThemeBg}
                                      onChange={(e) => setPlayStoreThemeBg(e.target.value)}
                                      className="w-7 h-7 rounded border border-slate-800 cursor-pointer"
                                    />
                                    <span className="text-[9px] text-slate-400">Splash</span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* App Icon Visual Live Preview representation */}
                            <div className="flex flex-col items-center justify-center p-3 border border-indigo-500/10 rounded-xl bg-slate-900/50">
                              <span className="text-[9.5px] font-mono text-indigo-400 mb-2 uppercase tracking-wide">Live Asset Preview</span>
                              <div
                                style={{ backgroundColor: playStoreIconBgColor }}
                                className={`w-16 h-16 shadow-lg flex items-center justify-center border border-white/20 relative cursor-default select-none transition-all duration-200 ${
                                  playStoreIconShape === 'circle' ? 'rounded-full' :
                                  playStoreIconShape === 'squircle' ? 'rounded-2xl' : 'rounded-lg'
                                }`}
                              >
                                <div className="absolute inset-0 border border-white/10 rounded-[inherit] pointer-events-none"></div>
                                <span
                                  style={{ color: playStoreIconTextColor }}
                                  className="text-2xl font-bold font-sans tracking-tight drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]"
                                >
                                  {playStoreIconText || "APP"}
                                </span>
                              </div>
                              <span className="text-[9px] text-slate-400 font-mono mt-2">Launcher Emblem ({playStoreIconShape})</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Build actions block */}
                      <div className={`p-4 rounded-xl border flex flex-col gap-3 ${isDarkMode ? 'bg-slate-950/45 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                        {/* Integration parameters bar */}
                        <div className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left ${
                          isDarkMode ? 'bg-indigo-950/20 border-indigo-500/10' : 'bg-indigo-50/60 border-indigo-100'
                        }`}>
                          <div className="space-y-0.5">
                            <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider flex items-center gap-1.5">
                              <Github className="w-3.5 h-3.5" /> GitHub Actions Compiler Config
                            </span>
                            <p className="text-[11px] text-slate-300">
                              Repository: {githubOwner && githubRepo ? (
                                <strong className="text-emerald-400 font-mono">{githubOwner}/{githubRepo}</strong>
                              ) : (
                                <span className="text-amber-400 italic">Not set up (Draft prompts fallback)</span>
                              )}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setTestConnectionStatus('idle');
                              setTestConnectionMsg('');
                              setShowGithubWizard(true);
                            }}
                            className="px-3.5 py-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
                          >
                            <Settings className="w-3.5 h-3.5 text-indigo-400" />
                            <span>GitHub Settings</span>
                          </button>
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-500/10 pb-3">
                          <div>
                            <h4 className="font-bold text-slate-200 flex items-center gap-1.5">
                              <Code className="w-3.5 h-3.5 text-emerald-400" />
                              <span>3. Setup Compiler targets (APK + AAB)</span>
                            </h4>
                            <p className="text-[10.5px] text-slate-400 mt-0.5">Creates Gradle project structure with localized adaptive values.</p>
                          </div>

                          <label className="flex items-center gap-2 cursor-pointer select-none bg-indigo-600/10 hover:bg-indigo-600/20 px-3 py-1.5 rounded-lg border border-indigo-500/20 text-indigo-300 transition-all font-semibold">
                            <input
                              type="checkbox"
                              checked={playStoreGithubActionsWorkflow}
                              onChange={(e) => setPlayStoreGithubActionsWorkflow(e.target.checked)}
                              className="rounded text-indigo-500 focus:ring-0 border-slate-700 bg-slate-900"
                            />
                            <span className="text-[10.5px] flex items-center gap-1">
                              <Github className="w-3.5 h-3.5 text-white/80" /> Inbound GitHub Action CI Workflow
                            </span>
                          </label>
                        </div>

                        <div className="flex items-center gap-3 flex-wrap animate-fade-in">
                          <button
                            disabled={playStoreIsCompiling}
                            onClick={handleDownloadAndroidPlayStoreZip}
                            className={`flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs select-none shadow transition-all duration-200 ${
                              playStoreIsCompiling
                                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer hover:shadow-emerald-500/10 hover:scale-[1.01]'
                            }`}
                          >
                            <span>{playStoreIsCompiling ? "Compiling Packaging Sandboxes..." : "🛠️ Process & Compile Play Store Suite"}</span>
                          </button>

                          {playStoreDownloadUrl && (
                            <a
                              href={playStoreDownloadUrl}
                              download={playStoreDownloadFilename}
                              className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-extrabold text-xs bg-indigo-600 text-white hover:bg-indigo-500 shadow hover:shadow-indigo-500/20 hover:scale-[1.01] transition-all animate-bounce"
                            >
                              <Download className="w-4 h-4 shrink-0" />
                              <span>Download Standalone Gradle Project (.zip)</span>
                            </a>
                          )}
                        </div>

                        {/* Blinking Emulator Live Compiler Terminal overlay */}
                        {(playStoreIsCompiling || playStoreCompileLogs.length > 0) && (
                          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3.5 font-mono text-[10.5px] leading-relaxed text-indigo-300 shadow-inner">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2 shrink-0">
                              <span className="text-[9.5px] text-slate-500 uppercase font-bold flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${playStoreIsCompiling ? 'bg-amber-400 animate-ping' : 'bg-green-400'}`}></span>
                                WebView Platform Container Sandbox Output
                              </span>
                              <span className="text-[9px] text-slate-600">v1.2.0 - Gradle v8.2</span>
                            </div>
                            <div className="max-h-40 overflow-y-auto space-y-1 select-text scrollbar-thin scrollbar-thumb-slate-800">
                              {playStoreCompileLogs.map((logLine, idx) => (
                                <div key={idx} className={logLine.includes("❌") || logLine.includes("✖") ? "text-rose-400 font-semibold" : ""}>
                                  {logLine}
                                </div>
                              ))}
                              {playStoreIsCompiling && (
                                <div className="text-amber-3 w-fit text-amber-400 flex items-center gap-1 animate-pulse">
                                  <span>Compiling targets...</span>
                                  <span className="w-1 px-0.5 bg-amber-400 animate-[pulse_1s_infinite]">|</span>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                </div>

                {/* Footer buttons */}
                <div className="mt-4 pt-3 border-t border-indigo-500/10 flex justify-end shrink-0">
                  <button
                    onClick={() => setShowAndroidPackagerModal(false)}
                    className="px-4 py-2 font-bold text-xs bg-slate-800 dark:hover:bg-slate-700 text-slate-200 rounded-xl transition-all"
                  >
                    Close Wizard
                  </button>
                </div>
              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>

      {/* MOBILE AUDIT AND COMPILATION MONITOR PANEL */}
      <AnimatePresence>
        {showAuditPanel && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md" id="dialog_audit_status_modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className={`w-full max-w-xl rounded-2xl p-6 shadow-2xl border flex flex-col gap-4 max-h-[90vh] overflow-hidden ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white text-slate-800 border-slate-200'
              }`}
            >
              <div className="flex justify-between items-center pb-2 border-b border-slate-800/60">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  <div className="text-left">
                    <h3 className="text-sm font-bold tracking-tight">Android Play Store Ready Auditor</h3>
                    <p className="text-[10px] text-slate-400">Verifying and tracking mobile packaging compiler actions</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowAuditPanel(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-500/10 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              {/* Status List Steps */}
              <div className="flex flex-col gap-2.5">
                {(() => {
                  const renderStepStatus = (title: string, status: 'idle' | 'pending' | 'success' | 'failed', message: string) => {
                    let icon = null;
                    let bgClass = isDarkMode ? "bg-slate-950/40 border-slate-800/80 text-slate-500" : "bg-slate-50 border-slate-200 text-slate-400";
                    
                    if (status === 'pending') {
                      icon = <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin shrink-0" />;
                      bgClass = "bg-indigo-500/5 border-indigo-500/20 text-indigo-300 ring-1 ring-indigo-500/5";
                    } else if (status === 'success') {
                      icon = <Check className="w-4 h-4 text-emerald-400 shrink-0" />;
                      bgClass = "bg-emerald-500/5 border-emerald-500/20 text-emerald-300";
                    } else if (status === 'failed') {
                      icon = <X className="w-4 h-4 text-red-500 shrink-0" />;
                      bgClass = "bg-red-500/5 border-red-500/20 text-red-300";
                    } else {
                      icon = <Clock className="w-4 h-4 text-slate-500 shrink-0" />;
                    }

                    return (
                      <div className={`p-3 rounded-xl border flex items-start gap-3 transition-all duration-200 ${bgClass}`}>
                        <div className="mt-0.5 shrink-0">
                          {icon}
                        </div>
                        <div className="flex-1 min-w-0 text-left">
                          <h5 className="text-[11px] font-bold uppercase tracking-wider">{title}</h5>
                          {message && <p className="text-[10px] opacity-80 mt-0.5 leading-normal">{message}</p>}
                        </div>
                      </div>
                    );
                  };

                  return (
                    <div className="space-y-2.5">
                      {renderStepStatus("1. Starting Validation", auditStepValidation, auditStepValidationMsg || "Checks layout meta elements and design scoring metrics.")}
                      {renderStepStatus("2. Project Type Detected", auditStepProjType, auditStepProjTypeMsg || "Scans workspace layout files to classify ecosystem target.")}
                      {renderStepStatus("3. GitHub Actions CI Flow", auditStepWorkflow, auditStepWorkflowMsg || "Verifies PAT credentials and dispatches remote compilations.")}
                      {renderStepStatus("4. Build Export Status", auditStepExport, auditStepExportMsg || "Tracks compiling stages and parses direct bundle artifacts.")}
                    </div>
                  );
                })()}
              </div>

              {/* Direct Download Links for Compiled Packages */}
              {compiledArtifacts.length > 0 && (
                <div className={`p-3.5 rounded-xl border text-left flex flex-col gap-2.5 transition-all ${
                  isDarkMode ? 'bg-emerald-950/20 border-emerald-500/20 text-emerald-100' : 'bg-emerald-50 border-emerald-100 text-emerald-900'
                }`} id="compilation_artifacts_download_panel">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4.5 h-4.5 text-emerald-400 animate-pulse" />
                    <div>
                      <h4 className="text-xs font-bold">Android Packages Compiled successfully!</h4>
                      <p className="text-[10px] text-slate-400 font-medium leading-tight">Click to download optimized Play Store ready package artifacts:</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-0.5">
                    {compiledArtifacts.map((art) => {
                      const isApk = art.name.toLowerCase().includes('apk');
                      return (
                        <a
                          key={art.id}
                          href={art.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`flex items-center justify-between p-2 rounded-lg border transition-all cursor-pointer shadow-sm pr-3 ${
                            isDarkMode 
                              ? 'bg-slate-950 border-slate-800 hover:border-emerald-500/35 text-slate-200' 
                              : 'bg-white border-slate-200 hover:border-emerald-400 text-slate-8000'
                          }`}
                          id={`download_btn_${art.id}`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <div className={`p-1.5 rounded-md shrink-0 ${isApk ? 'bg-emerald-500/10 text-emerald-400' : 'bg-indigo-500/10 text-indigo-400'}`}>
                              <Github className="w-3.5 h-3.5" />
                            </div>
                            <div className="text-left font-mono text-[10px] min-w-0">
                              <span className="block font-bold text-[10px] truncate max-w-[130px]">{art.name}</span>
                              <span className="text-[8.5px] text-slate-400 font-normal">GitHub Download ZIP</span>
                            </div>
                          </div>
                          <Download className="w-3 h-3 text-slate-400 shrink-0 ml-1" />
                        </a>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Streaming logs component */}
              <div className="flex flex-col gap-1.5 flex-1 min-h-[140px] max-h-[200px]">
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] font-bold text-slate-400 uppercase tracking-widest">Process Audit Console Logs</span>
                  <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-slate-950 text-indigo-400 border border-slate-800">STREAMING</span>
                </div>
                <div 
                  ref={logsContainerRef}
                  className="flex-1 p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[10px] text-slate-300 overflow-y-auto space-y-1 select-text scrollbar-thin text-left"
                >
                  {auditLogs.length === 0 ? (
                    <span className="text-slate-600 block italic">Awaiting build triggers...</span>
                  ) : (
                    auditLogs.map((log, idx) => (
                      <div key={idx} className="leading-normal font-medium text-slate-300">
                        {log}
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex justify-end shrink-0 gap-3" id="audit_panel_actions">
                <button
                  type="button"
                  onClick={() => {
                    setShowAuditPanel(false);
                    setTestConnectionStatus('idle');
                    setTestConnectionMsg('');
                    setShowGithubWizard(true);
                  }}
                  className="px-4 py-2 font-bold text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                  id="audit_panel_edit_settings_btn"
                >
                  <Settings className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Edit Build Settings</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAuditPanel(false)}
                  className="px-4 py-2 font-bold text-xs bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all shadow-md shrink-0 cursor-pointer"
                  id="audit_panel_close_btn"
                >
                  Close Dialog
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GITHUB ACTIONS CI COMPILER WIZARD & SETTINGS DIALOG */}
      <AnimatePresence>
        {showGithubWizard && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md font-sans" id="github_wizard_modal_root">
            <motion.div
              initial={{ scale: 0.96, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 15 }}
              className={`w-full max-w-lg rounded-2xl p-6 shadow-2xl border flex flex-col gap-4 max-h-[92vh] overflow-y-auto scrollbar-thin ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white text-slate-800 border-slate-200'
              }`}
              id="github_wizard_modal_content"
            >
              <div className="flex justify-between items-center pb-2 border-b border-indigo-500/10" id="github_wizard_header">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
                    <Github className="w-5 h-5 animate-pulse" />
                  </div>
                  <div className="text-left">
                    <h3 className="text-sm font-bold tracking-tight text-white dark:text-white">GitHub CI Compiler Setup</h3>
                    <p className="text-[10px] text-slate-400">Configure OAuth tokens & triggers for automated Android Packaging Compilation</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowGithubWizard(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-500/15 cursor-pointer transition-colors"
                  id="github_wizard_close_btn"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              {/* Viewport Meta tag Notice card */}
              {(() => {
                const { hasViewport } = analyzeProjectForMobile();
                if (!hasViewport) {
                  return (
                    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-left text-[11px] text-amber-300">
                      <Sparkles className="w-4 h-4 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">Missing viewport scale meta tag detected:</span>
                        <p className="opacity-90 mt-0.5">We will automatically inject <code className="font-mono text-[9.5px] bg-amber-500/20 px-1 py-0.5 rounded text-white">&lt;meta name="viewport" ...&gt;</code> to your layout head during build validation.</p>
                      </div>
                    </div>
                  );
                }
                return null;
              })()}

              {/* Input Form Fields */}
              <div className="space-y-3.5" id="github_wizard_form">
                <div className="text-left">
                  <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="github_token_input">
                    Personal Access Token (PAT) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="github_token_input"
                    type="password"
                    value={githubToken}
                    onChange={(e) => setGithubToken(e.target.value)}
                    placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                    className={`w-full px-3 py-2 text-xs font-semibold rounded-lg border focus:ring-1 focus:ring-indigo-500 outline-none transition-all ${
                      isDarkMode ? 'bg-slate-950 border-slate-855 text-white' : 'bg-white border-slate-300 text-slate-800'
                    }`}
                  />
                  <p className="text-[9px] text-slate-400 mt-1">
                    Needs <code className="bg-slate-800 px-1 py-0.5 rounded text-[8.5px] text-slate-300">repo_workflow</code> write permissions scopes to authorize automated workflows remotely.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3.5">
                  <div className="text-left">
                    <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="github_username_input">
                      GitHub Username / Org <span className="text-rose-500">*</span>
                    </label>
                    <input
                      id="github_username_input"
                      type="text"
                      value={githubOwner}
                      onChange={(e) => setGithubOwner(e.target.value)}
                      placeholder="e.g. google-ai"
                      className={`w-full px-3 py-2 text-xs font-semibold rounded-lg border focus:ring-1 focus:ring-indigo-500 outline-none transition-all ${
                        isDarkMode ? 'bg-slate-950 border-slate-855 text-white' : 'bg-white border-slate-300 text-slate-800'
                      }`}
                    />
                  </div>

                  <div className="text-left">
                    <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="github_repo_input">
                      Repository Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      id="github_repo_input"
                      type="text"
                      value={githubRepo}
                      onChange={(e) => setGithubRepo(e.target.value)}
                      placeholder="e.g. my-applet-project"
                      className={`w-full px-3 py-2 text-xs font-semibold rounded-lg border focus:ring-1 focus:ring-indigo-500 outline-none transition-all ${
                        isDarkMode ? 'bg-slate-950 border-slate-855 text-white' : 'bg-white border-slate-300 text-slate-800'
                      }`}
                    />
                  </div>
                </div>

                {/* Advanced parameters accordian / toggle drawer */}
                <div className={`p-3 rounded-xl border ${isDarkMode ? 'bg-slate-950/40 border-slate-800/80' : 'bg-slate-50 border-slate-200'}`}>
                  <h4 className="text-[11px] font-bold uppercase text-slate-400 tracking-wider mb-2 flex items-center gap-1.5 justify-between">
                    <span>Advanced Workflow Parameters</span>
                    <span className="text-[9px] font-normal text-indigo-400 font-mono">Custom overrides</span>
                  </h4>
                  <div className="grid grid-cols-2 gap-3" id="github_wizard_advanced_fields">
                    <div className="text-left">
                      <label className="block text-[9.5px] font-semibold text-slate-450 uppercase mb-1" htmlFor="github_branch_input">Target Compilation Branch</label>
                      <input
                        id="github_branch_input"
                        type="text"
                        value={githubBranch}
                        onChange={(e) => setGithubBranch(e.target.value)}
                        placeholder="main"
                        className={`w-full px-2 py-1 text-[11px] font-semibold rounded border outline-none ${
                          isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-800'
                        }`}
                      />
                    </div>
                    <div className="text-left">
                      <label className="block text-[9.5px] font-semibold text-slate-450 uppercase mb-1" htmlFor="github_workflow_input">Workflow Filename</label>
                      <input
                        id="github_workflow_input"
                        type="text"
                        value={githubWorkflow}
                        onChange={(e) => setGithubWorkflow(e.target.value)}
                        placeholder="android-build.yml"
                        className={`w-full px-2 py-1 text-[11px] font-semibold rounded border outline-none ${
                          isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-300 text-slate-800'
                        }`}
                      />
                    </div>
                  </div>
                </div>

                {/* Visible readout field of current workflow file */}
                <div className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                  isDarkMode ? 'bg-indigo-950/15 border-indigo-500/25 text-slate-200' : 'bg-indigo-50 border-indigo-150 text-slate-750'
                }`} id="github_wizard_active_workflow_panel_readout">
                  <div className="space-y-0.5 text-left">
                    <span className="text-[10px] uppercase font-semibold text-indigo-400 tracking-wider block">
                      📄 Selected Compilation Workflow
                    </span>
                    <p className="font-mono text-xs font-bold text-indigo-300">
                      {githubWorkflow || 'android-build.yml'}
                    </p>
                  </div>
                  <span className="text-[9px] font-bold px-2.5 py-1 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/25 font-mono shadow-sm">
                    Workflow Target
                  </span>
                </div>
              </div>

              {/* Help tip block on retrieving keys */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/60 text-left" id="github_wizard_tips">
                <span className="text-[9.5px] font-bold text-indigo-400 uppercase tracking-widest block mb-1">💡 Token Configuration Quick Tutorial</span>
                <ol className="text-[10px] text-slate-400 space-y-1 list-decimal list-inside pl-1 leading-normal">
                  <li>Navigate to your GitHub account settings and locate <strong className="text-slate-300">Developer Settings</strong>.</li>
                  <li>Click <strong className="text-slate-300">Personal Access Tokens</strong> &rarr; <strong className="text-slate-300">Tokens (classic)</strong>.</li>
                  <li>Select <strong className="text-slate-300">Generate new token</strong>, name it, and check <code className="bg-slate-900 border border-slate-800 px-1 py-0.2 rounded text-[8.5px] text-slate-200 font-mono">workflow</code> parameter permissions.</li>
                  <li>Copy and paste your generated secret here inside the target fields in safe environments.</li>
                </ol>
              </div>

              {/* Live Connection Verification Panel */}
              {testConnectionStatus !== 'idle' && (
                <div className={`p-3 rounded-xl border flex items-start gap-2.5 text-left text-xs ${
                  testConnectionStatus === 'testing' ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-300' :
                  testConnectionStatus === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300' :
                  'bg-red-500/10 border-red-500/20 text-red-300'
                }`} id="github_wizard_test_connections_feedback">
                  {testConnectionStatus === 'testing' ? (
                    <RefreshCw className="w-4 h-4 animate-spin shrink-0 mt-0.5 text-indigo-400" />
                  ) : testConnectionStatus === 'success' ? (
                    <Check className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400 font-bold" />
                  ) : (
                    <X className="w-4 h-4 shrink-0 mt-0.5 text-red-400 font-bold" />
                  )}
                  <div>
                    <span className="font-bold uppercase text-[10.5px]">
                      {testConnectionStatus === 'testing' && "Verifying Connectivity..."}
                      {testConnectionStatus === 'success' && "Connection Approved!"}
                      {testConnectionStatus === 'failed' && "Accessibility Disrupted"}
                    </span>
                    <p className="text-[10px] opacity-90 mt-0.5 leading-relaxed">{testConnectionMsg}</p>
                  </div>
                </div>
              )}

              {/* Dialog control buttons */}
              <div className="pt-3 border-t border-indigo-500/10 flex items-center justify-between gap-3 shrink-0" id="github_wizard_actions">
                <button
                  type="button"
                  disabled={testConnectionStatus === 'testing'}
                  onClick={handleTestGithubConnection}
                  className="px-4 py-2 font-bold text-xs bg-slate-850 hover:bg-slate-850 text-indigo-300 border border-slate-800 hover:border-slate-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  id="github_wizard_verify_btn"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${testConnectionStatus === 'testing' ? 'animate-spin' : ''}`} />
                  <span>Test Connection</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowGithubWizard(false)}
                    className="px-3 py-2 font-bold text-xs bg-slate-805 hover:bg-slate-700 text-slate-350 rounded-xl border border-slate-700 transition-all cursor-pointer"
                    id="github_wizard_cancel_btn"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      // Save and do not build!
                      saveGithubSettings(githubToken.trim(), githubOwner.trim(), githubRepo.trim(), githubWorkflow, githubBranch);
                      setShowGithubWizard(false);
                      triggerLocalFeedback("GitHub build setup configurations updated.");
                    }}
                    disabled={!githubToken || !githubOwner || !githubRepo}
                    className="px-3 py-2 font-semibold text-xs bg-slate-805 hover:bg-slate-750 text-indigo-300 border border-slate-700 rounded-xl transition-all font-semibold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    id="github_wizard_save_settings_btn"
                  >
                    Save Settings
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      saveGithubSettings(githubToken.trim(), githubOwner.trim(), githubRepo.trim(), githubWorkflow, githubBranch);
                      setShowGithubWizard(false);
                      triggerLocalFeedback("GitHub build metrics established.");
                      handleAndroidPlayStoreAuditAndBuild(null);
                    }}
                    disabled={!githubToken || !githubOwner || !githubRepo}
                    className="px-3 py-2 font-extrabold text-xs bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition-all hover:scale-[1.015] shadow shadow-emerald-500/10 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    id="github_wizard_save_run_btn"
                  >
                    Save & Build APK
                  </button>
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* HELP DIAGNOSTIC GUIDE MODAL */}
      <AnimatePresence>
        {showHelpModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm" id="dialog_help_modal">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-md rounded-2xl p-6 shadow-2xl border ${
                isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white text-slate-800 border-slate-200'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <h3 className="text-sm font-bold flex items-center gap-1.5">
                  <Flame className="w-5 h-5 text-amber-400 fill-amber-400 animate-pulse" />
                  Code Preview Guide
                </h3>
                <button
                  onClick={() => setShowHelpModal(false)}
                  className="p-1 rounded-md hover:bg-slate-500/15"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              
              <div className="space-y-3.5 text-[11.5px] leading-relaxed text-slate-300">
                <p>
                  Welcome to <strong>AI App Builder</strong>. Build beautiful web interactive applications cleanly using combined code modules.
                </p>
                <div className="space-y-2 font-mono text-[10.5px]">
                  <div className="p-2.5 rounded bg-slate-950/80 flex items-start gap-2 border border-slate-850">
                    <span className="text-yellow-400">⚡</span>
                    <div>
                      <strong>Multi-file EditorTabs</strong>: Easily move between HTML layout content, custom styled CSS classes, and active custom Javascript triggers.
                    </div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-950/80 flex items-start gap-2 border border-slate-850">
                    <span className="text-emerald-400">⚡</span>
                    <div>
                      <strong>Line Numbers & indenting (Tab)</strong>: Use Tab key to instantly apply 2 spaces index cleanly inside textareas, maintaining high editor syntax aesthetics!
                    </div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-950/80 flex items-start gap-2 border border-slate-850">
                    <span className="text-indigo-400">⚡</span>
                    <div>
                      <strong>Offline Project Persistence</strong>: Click "Save Project" to store custom works inside indexed localStorage slots safely. Download unified single webpage file exports with no server bounds.
                    </div>
                  </div>
                  <div className="p-2.5 rounded bg-slate-950/80 flex items-start gap-2 border border-slate-850">
                    <span className="text-purple-400">⚡</span>
                    <div>
                      <strong>Interactive Console Monitor</strong>: Any <code>console.log()</code> statements or errors are intercepted in real-time and formatted inside the expandable debugger rail below.
                    </div>
                  </div>
                </div>
                <p className="text-center font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-400">
                  Built to work flawlessly on both desktops and mobile viewports.
                </p>
              </div>
              <div className="mt-5 border-t border-slate-800 pt-4 flex justify-end">
                <button
                  onClick={() => setShowHelpModal(false)}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-md"
                >
                  Start Creating
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FLOATING PWA INSTALLATION DRAWER/CARD */}
      <AnimatePresence>
        {isInstallable && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className={`fixed bottom-4 right-4 z-50 p-4 rounded-2xl shadow-2xl flex flex-col sm:flex-row items-center gap-4 border max-w-sm sm:max-w-md ${
              isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200/90'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-600 to-pink-500 flex items-center justify-center shrink-0 shadow-lg text-white font-mono font-bold text-xl">
                AI
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold truncate font-sans">Install AI App Builder</h4>
                <p className="text-[10px] text-slate-400 mt-0.5 leading-normal">
                  Natively install AI App Builder for fast offline access and enhanced workspace previewing on Android & Mobile!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
              <button
                onClick={() => setIsInstallable(false)}
                className="px-2.5 py-1.5 text-[10px] font-bold text-slate-400 hover:text-slate-200"
              >
                Later
              </button>
              <button
                onClick={triggerNativePwaInstall}
                className="px-3.5 py-1.5 text-[10px] font-extrabold bg-indigo-600 hover:bg-indigo-500 rounded-lg text-white flex items-center gap-1 transition-all shadow-md shrink-0 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Install</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FULL SCREEN IMMERSIVE PREVIEW SYSTEM */}
      <AnimatePresence>
        {isFullScreenPreview && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950 flex flex-col font-sans"
            id="fullscreen_immersive_preview"
          >
            {/* Elegant glass bar */}
            <div className={`flex items-center justify-between px-4 py-3 select-none shrink-0 border-b ${
              isDarkMode 
                ? 'bg-slate-900/95 border-slate-800 text-white' 
                : 'bg-white border-slate-200 text-slate-800 shadow-sm'
            }`}>
              <div className="flex items-center gap-3">
                <button
                  id="fullscreen_close_panel"
                  onClick={() => setIsFullScreenPreview(false)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                    isDarkMode 
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700/50' 
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-750 text-slate-700 border border-slate-200'
                  }`}
                  title="Return to Workspace Editor"
                >
                  <Minimize2 className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Exit Fullscreen</span>
                </button>
                <div className="h-4 w-px bg-slate-200 dark:bg-slate-800"></div>
                <div className="flex flex-col min-w-0">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400 font-mono">Simulating Presentation</span>
                  <span className="font-bold text-xs truncate max-w-[150px] sm:max-w-xs">{activeProjectName}</span>
                </div>
              </div>

              {/* Viewport Sizing Controls inside Fullscreen View */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-xl">
                <button
                  id="fullscreen_device_desktop"
                  onClick={() => setPreviewDevice('desktop')}
                  className={`p-1.5 rounded-lg transition-all ${
                    previewDevice === 'desktop'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
                  }`}
                  title="Desktop viewport"
                >
                  <Monitor className="w-3.5 h-3.5" />
                </button>
                <button
                  id="fullscreen_device_tablet"
                  onClick={() => setPreviewDevice('tablet')}
                  className={`p-1.5 rounded-lg transition-all ${
                    previewDevice === 'tablet'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
                  }`}
                  title="Tablet resolution frame (768px)"
                >
                  <Tablet className="w-3.5 h-3.5" />
                </button>
                <button
                  id="fullscreen_device_mobile"
                  onClick={() => setPreviewDevice('mobile')}
                  className={`p-1.5 rounded-lg transition-all ${
                    previewDevice === 'mobile'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
                  }`}
                  title="Mobile resolution frame (375px)"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Action operations inside fullscreen view */}
              <div className="flex items-center gap-2">
                <button
                  id="fullscreen_reload"
                  onClick={compilePreview}
                  className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/15 hover:bg-emerald-500/20 transition-all cursor-pointer"
                  title="Re-compile Sandbox"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Immersive Sandbox Simulator Area */}
            <div className={`flex-grow flex items-center justify-center p-3 sm:p-6 overflow-auto ${
              isDarkMode ? 'bg-slate-950' : 'bg-slate-100'
            }`}>
              <div
                className={`bg-white transition-all duration-300 relative flex flex-col shadow-2xl overflow-hidden rounded-2xl border ${
                  isDarkMode ? 'border-slate-800 shadow-black/80' : 'border-slate-300/60 shadow-slate-300/40'
                } ${
                  previewDevice === 'mobile'
                    ? 'w-[375px] h-[667px]'
                    : previewDevice === 'tablet'
                      ? 'w-[768px] h-[1024px] max-h-full'
                      : 'w-full h-full'
                }`}
              >
                <div className="bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-1.5 flex items-center justify-between shrink-0 select-none text-[10px] font-mono text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-550 bg-rose-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-550 bg-amber-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-550 bg-emerald-500"></span>
                  </div>
                  <div className="text-[9px] bg-slate-200 dark:bg-slate-950/80 px-4 py-0.5 rounded-lg border border-slate-250 dark:border-slate-800 text-slate-450 text-slate-400 font-bold tracking-wider uppercase">
                    {previewDevice === 'desktop' ? '100% Desktop Viewport' : previewDevice === 'tablet' ? '768px Tablet Viewport' : '375px Mobile Viewport'}
                  </div>
                  <div className="w-12"></div>
                </div>
                <iframe
                  id="fullscreen_sandbox"
                  key={`fs_${previewKey}`}
                  srcDoc={renderedCode}
                  title="Immersive Sandbox Live Preview Fullscreen"
                  sandbox="allow-scripts allow-modals allow-same-origin"
                  className="w-full flex-grow border-none bg-white"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ==================== AI REFINER DIALOG MODAL ==================== */}
      <AnimatePresence>
        {showRefinerModal && (
          <div key="refiner_modal_wrapper" className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Soft dark backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (!isGeneratingAi) setShowRefinerModal(false);
              }}
              className="absolute inset-0 bg-slate-950/65 backdrop-blur-sm"
            />
            
            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: 'spring', duration: 0.35 }}
              className={`relative w-full max-w-lg rounded-2xl border shadow-2xl p-6 overflow-hidden flex flex-col gap-4 font-sans ${
                isDarkMode 
                  ? 'bg-slate-900 border-slate-800 text-white' 
                  : 'bg-white border-slate-200 text-slate-800'
              }`}
            >
              {/* Close Button */}
              {!isGeneratingAi && (
                <button
                  type="button"
                  onClick={() => setShowRefinerModal(false)}
                  className={`absolute right-4 top-4 p-1 rounded-lg transition-all cursor-pointer ${
                    isDarkMode ? 'hover:bg-slate-800 text-slate-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              {/* Title & Banner */}
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-600 to-pink-500 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Sparkles className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold tracking-tight">Refine Workspace via Gemini</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 select-none font-mono">
                    Refactoring workspace: <span className="text-indigo-400 font-bold">{activeProjectName}</span>
                  </p>
                </div>
              </div>

              {/* Description guidelines */}
              <p className="text-xs text-slate-400 leading-relaxed font-normal">
                Describe the modifications or feature extensions you want to weave into this project. Our AI will selectively modify layout containers, stylesheet definitions, or interaction scripts without breaking other functional capabilities.
              </p>

              {/* Prompt Text Box */}
              <div className="relative">
                <textarea
                  id="modal_refinery_input"
                  rows={4}
                  value={refinerPrompt}
                  onChange={(e) => setRefinerPrompt(e.target.value)}
                  placeholder="e.g. Add a beautiful neon reset button, center it on screen, back-filled with micro-actions when completed..."
                  disabled={isGeneratingAi}
                  className={`w-full text-xs p-3.5 rounded-xl pr-10 border transition-all resize-none shadow-inner focus:outline-none focus:ring-1 ${
                    isDarkMode 
                      ? 'bg-slate-950 text-slate-100 border-slate-800 focus:border-indigo-500 focus:ring-indigo-500/25' 
                      : 'bg-slate-50 text-slate-800 border-slate-250 focus:border-indigo-400 focus:ring-indigo-400/25'
                  }`}
                  autoFocus
                />

                {/* Voice Button inside refinery prompt */}
                <button
                  type="button"
                  id="btn_refine_voice"
                  onClick={() => startVoiceRecognition('refine')}
                  disabled={isGeneratingAi}
                  className={`absolute right-3.5 bottom-3.5 p-1.5 rounded-full transition-all cursor-pointer ${
                    isListeningVoice && activeVoiceTarget === 'refine'
                      ? 'bg-red-500 text-white animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.7)]' 
                      : isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-900'
                  }`}
                  title="Tap to speak instructions"
                >
                  <Mic className="w-4 h-4" />
                </button>

                {/* Listening Overlay for Refinery */}
                {isListeningVoice && activeVoiceTarget === 'refine' && (
                  <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs rounded-xl flex flex-col items-center justify-center gap-1.5 text-center p-3.5 z-25 border border-red-500/30">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                      <span className="text-[11px] font-bold text-red-400 uppercase tracking-widest font-mono">Listening now...</span>
                    </div>
                    <p className="text-[10px] text-slate-300 font-medium max-w-[320px]">
                      {voiceLanguage === 'te-IN'
                        ? "స్పీకర్ కోసం రికార్డింగ్... తెలుగులో మాట్లాడండి"
                        : "Refining instructions auto-appending... Speak now!"}
                    </p>
                    <button
                      type="button"
                      onClick={() => setIsListeningVoice(false)}
                      className="mt-1 text-[9px] font-extrabold px-3 py-1 bg-red-950 text-red-200 border border-red-800/30 rounded-lg hover:bg-red-900/60 transition-all cursor-pointer"
                    >
                      Cancel Voice Capture
                    </button>
                  </div>
                )}
              </div>

              {/* Language Selector Overlay for Refinery Voice Inputs */}
              <div className={`flex items-center justify-between p-2 rounded-xl border ${
                isDarkMode ? 'bg-slate-950/20 border-slate-850' : 'bg-slate-50 border-slate-200'
              }`}>
                <span className="text-[10px] text-slate-500 flex items-center gap-1 font-semibold font-mono">
                  <Globe className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Voice Language (భాష):</span>
                </span>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => setVoiceLanguage('en-US')}
                    className={`text-[9.5px] font-extrabold px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                      voiceLanguage === 'en-US'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                        : isDarkMode
                          ? 'border-slate-800 text-slate-400 bg-slate-950 hover:bg-slate-900 hover:text-white'
                          : 'border-slate-205 text-slate-600 bg-white hover:bg-slate-100 hover:text-slate-905'
                    }`}
                  >
                    🇺🇸 English
                  </button>
                  <button
                    type="button"
                    onClick={() => setVoiceLanguage('te-IN')}
                    className={`text-[9.5px] font-extrabold px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                      voiceLanguage === 'te-IN'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                        : isDarkMode
                          ? 'border-slate-800 text-slate-400 bg-slate-950 hover:bg-slate-900 hover:text-white'
                          : 'border-slate-205 text-slate-600 bg-white hover:bg-slate-100 hover:text-slate-905'
                    }`}
                  >
                    🇮🇳 తెలుగు (Telugu)
                  </button>
                </div>
              </div>

              {/* Quick Suggestion Pills */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Inspiration suggestions:</span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { label: "🔥 Add Premium Animations", p: "Incorporate soft transitions, elastic scales, and keyframe slide effects for modern look." },
                    { label: "🎨 Convert Theme", p: "Convert visual color scheme to a premium deep space cyberpunk dark theme with glowing neon purple borders." },
                    { label: "🛠️ Input Validation", p: "Enrich inputs with boundary validation checks, and render nice in-canvas system logs when errors occurs." },
                    { label: "⏱️ Restart Option", p: "Add an elegant Reset action button to allow user to instantly clear and reset simulator parameters." }
                  ].map((s, idx) => (
                    <button
                      key={idx}
                      onClick={() => setRefinerPrompt(s.p)}
                      disabled={isGeneratingAi}
                      className={`text-[10px] px-2.5 py-1.5 rounded-lg border text-left transition-all cursor-pointer font-medium hover:scale-[1.01] ${
                        isDarkMode 
                          ? 'border-slate-800 text-slate-400 bg-slate-950/40 hover:border-slate-700 hover:text-white' 
                          : 'border-slate-205 text-slate-600 bg-slate-50 hover:border-slate-300 hover:text-slate-950 shadow-sm'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              {isGeneratingAi ? (
                <div className="mt-2 p-3 text-center rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex flex-col gap-2 items-center">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin" />
                    <span className="text-xs font-bold text-indigo-400">Gemini Refactoring App...</span>
                  </div>
                  <div className="text-[10px] text-indigo-300 font-mono italic animate-pulse">
                    &gt; {currentAiStep || 'Analyzing workspace...'}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-end gap-3.5 mt-2">
                  <button
                    type="button"
                    onClick={() => setShowRefinerModal(false)}
                    className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                      isDarkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-600'
                    }`}
                  >
                    Discard
                  </button>
                  <button
                    type="button"
                    id="btn_run_refine_generation"
                    onClick={() => handleAiGenerate(true, refinerPrompt)}
                    className="flex items-center gap-2 px-5 py-2.5 text-xs font-extrabold text-white rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 hover:scale-[1.01] transition-all cursor-pointer shadow-md shadow-indigo-500/20"
                  >
                    <Wand2 className="w-4 h-4" />
                    <span>Run Refactoring</span>
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================== AI CODE DIFFERENCES REVIEW BOARD ==================== */}
      <AnimatePresence>
        {showDiffModal && diffData && (
          <div key="diff_modal_wrapper" className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDiffModal(false)}
              className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 15 }}
              transition={{ type: 'spring', duration: 0.35 }}
              className={`relative w-full max-w-5xl rounded-2xl border shadow-2xl p-6 overflow-hidden flex flex-col gap-4 font-sans max-h-[90vh] md:max-h-none ${
                isDarkMode 
                  ? 'bg-slate-900 border-slate-800 text-white' 
                  : 'bg-white border-slate-200 text-slate-800'
              }`}
            >
              <button
                type="button"
                onClick={() => setShowDiffModal(false)}
                className={`absolute right-4 top-4 p-1 rounded-lg transition-all cursor-pointer ${
                  isDarkMode ? 'hover:bg-slate-800 text-slate-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'
                }`}
              >
                <X className="w-4 h-4" />
              </button>

              {/* Title Header */}
              <div className="flex items-center justify-between border-b border-indigo-500/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                    <Check className="w-5 h-5 stroke-[2.5]" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold tracking-tight">AI Code Revision Proposed</h3>
                    <div className="flex flex-wrap items-center gap-2 mt-1">
                      <span className="text-[10px] text-slate-500">Refactoring:</span>
                      <span className="text-[10px] font-bold text-indigo-400">{diffData.originalName}</span>
                      <ChevronRight className="w-3 h-3 text-slate-500" />
                      <span className="text-[10px] text-slate-500">Proposed:</span>
                      <span className="text-[10px] font-bold text-pink-400">{diffData.newName}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Selector segments tabs */}
              <div className="flex items-center justify-between flex-wrap gap-2 shrink-0 bg-slate-950/30 p-1 rounded-xl border border-slate-800/10">
                <div className="flex gap-1.5">
                  {(['html', 'css', 'js'] as const).map(tab => {
                    const origLinesCount = (tab === 'html' ? diffData.originalHtml : tab === 'css' ? diffData.originalCss : (diffData.originalJs || '')).split('\n').length;
                    const newLinesCount = (tab === 'html' ? diffData.newHtml : tab === 'css' ? diffData.newCss : (diffData.newJs || '')).split('\n').length;
                    return (
                      <button
                        key={tab}
                        onClick={() => setDiffTab(tab)}
                        className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                          diffTab === tab
                            ? 'bg-indigo-600 text-white font-extrabold shadow-md'
                            : isDarkMode 
                              ? 'text-slate-400 hover:text-white hover:bg-slate-850/55' 
                              : 'text-slate-600 hover:text-slate-955 hover:bg-slate-100'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${tab === 'html' ? 'bg-orange-500' : tab === 'css' ? 'bg-sky-500' : 'bg-yellow-400'}`}></span>
                        <span className="capitalize">{tab === 'js' ? 'JavaScript' : tab.toUpperCase()}</span>
                        <span className="text-[9px] opacity-60 font-medium font-mono">
                          {origLinesCount} &rarr; {newLinesCount}
                        </span>
                      </button>
                    );
                  })}
                </div>
                <div className="text-[11px] font-medium text-slate-500 italic pr-2 font-mono">
                  Reviewing file changes prior to sandbox write
                </div>
              </div>

              {/* Comparative Side-by-Side Diff Component view */}
              {(() => {
                const origLines = (diffTab === 'html' ? diffData.originalHtml : diffTab === 'css' ? diffData.originalCss : diffData.originalJs || '').split('\n');
                const newLines = (diffTab === 'html' ? diffData.newHtml : diffTab === 'css' ? diffData.newCss : diffTab === 'js' ? diffData.newJs : '').split('\n');
                const maxLines = Math.max(origLines.length, newLines.length);

                return (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-[300px] md:h-[350px] overflow-hidden select-text leading-tight w-full">
                    {/* Left panel: Original */}
                    <div className="flex flex-col h-full border rounded-xl overflow-hidden bg-slate-950/95 border-rose-950/40">
                      <div className="px-3 py-1.5 text-[10.5px] font-semibold text-rose-400 bg-rose-950/20 border-b border-rose-950/45 uppercase tracking-wider flex items-center justify-between shrink-0 font-mono">
                        <span>Original Workspace</span>
                        <span className="text-[9px] bg-rose-950/30 text-rose-405 px-1.5 py-0.2 rounded border border-rose-900/30 font-bold">CURRENT</span>
                      </div>
                      <div className="flex-grow overflow-auto p-3 font-mono text-[10.5px] leading-relaxed max-h-[310px] scrollbar-thin scrollbar-thumb-slate-850">
                        {Array.from({ length: maxLines }).map((_, idx) => {
                          const line = origLines[idx];
                          const isChanged = line !== undefined && line !== newLines[idx];
                          return (
                            <div 
                              key={idx} 
                              className={`flex ${
                                isChanged ? 'bg-red-955/25 text-rose-200 line-through decoration-red-900/40 opacity-75' : 'text-slate-500 opacity-60 hover:text-slate-400'
                              }`}
                            >
                              <span className="w-8 shrink-0 text-right pr-2 text-slate-700 select-none border-r border-slate-900/50 mr-2">{idx + 1}</span>
                              <span className="whitespace-pre overflow-x-hidden">{line !== undefined ? line : ''}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Right panel: Proposed */}
                    <div className="flex flex-col h-full border rounded-xl overflow-hidden bg-slate-950/95 border-emerald-950/40">
                      <div className="px-3 py-1.5 text-[10.5px] font-semibold text-emerald-400 bg-emerald-950/20 border-b border-emerald-950/45 uppercase tracking-wider flex items-center justify-between shrink-0 font-mono">
                        <span>AI Refactored Result</span>
                        <span className="text-[9px] bg-emerald-950/30 text-emerald-450 px-1.5 py-0.2 rounded border border-emerald-900/30 font-bold">PROPOSED</span>
                      </div>
                      <div className="flex-grow overflow-auto p-3 font-mono text-[10.5px] leading-relaxed max-h-[310px] scrollbar-thin scrollbar-thumb-slate-855">
                        {Array.from({ length: maxLines }).map((_, idx) => {
                          const line = newLines[idx];
                          const isChanged = line !== undefined && line !== origLines[idx];
                          return (
                            <div 
                              key={idx} 
                              className={`flex ${
                                isChanged ? 'bg-emerald-950/30 text-emerald-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              <span className="w-8 shrink-0 text-right pr-2 text-emerald-800 select-none border-r border-slate-900/50 mr-2">{idx + 1}</span>
                              <span className="whitespace-pre overflow-x-hidden">{line !== undefined ? line : ''}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Explanation note by Gemini */}
              {diffData.explanation && (
                <div className={`p-3.5 rounded-xl border text-[11px] leading-relaxed select-none ${
                  isDarkMode ? 'bg-indigo-950/15 border-indigo-900/25 text-indigo-200' : 'bg-indigo-50 border-indigo-150 text-indigo-700'
                }`}>
                  <div className="font-extrabold flex items-center gap-1.5 mb-1 text-[11.5px] uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse shrink-0" />
                    <span>Gemini Engineering Report:</span>
                  </div>
                  <p>{diffData.explanation}</p>
                </div>
              )}

              {/* Incremental AI Safeguard & Validation Guardrail Analysis */}
              {validationResult && (
                <div className={`p-4 rounded-xl border text-xs leading-relaxed font-sans ${
                  validationResult.severity === 'error'
                    ? 'bg-rose-950/20 border-rose-900/40 text-rose-200'
                    : validationResult.severity === 'warning'
                      ? 'bg-yellow-950/15 border-yellow-900/30 text-amber-200'
                      : 'bg-emerald-950/15 border-emerald-900/35 text-emerald-250'
                }`}>
                  <div className="flex items-center justify-between font-bold uppercase tracking-wider mb-2 select-none text-[11px]">
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>AI Incremental Guardrail & Validation:</span>
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold ${
                      validationResult.severity === 'error'
                        ? 'bg-rose-500/20 text-rose-405 border border-rose-500/30'
                        : validationResult.severity === 'warning'
                          ? 'bg-amber-500/20 text-amber-305 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-405 border border-emerald-500/10'
                    }`}>
                      {validationResult.severity.toUpperCase()}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    {/* Checks list */}
                    <div className="space-y-1 md:col-span-2 text-slate-300">
                      <div className="flex items-center gap-2">
                        <span className={validationResult.htmlValid ? "text-emerald-400 font-extrabold font-mono" : "text-rose-400 font-extrabold font-mono"}>
                          {validationResult.htmlValid ? "✓" : "✗"}
                        </span>
                        <span>HTML Layout Structure Intact</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={validationResult.jsValid ? "text-emerald-400 font-extrabold font-mono" : "text-rose-400 font-extrabold font-mono"}>
                          {validationResult.jsValid ? "✓" : "✗"}
                        </span>
                        <span>JavaScript Syntactical Integrity</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={validationResult.calculatorIntact ? "text-emerald-400 font-extrabold font-mono" : "text-amber-400 font-extrabold font-mono"}>
                          {validationResult.calculatorIntact ? "✓" : "✗"}
                        </span>
                        <span>Utility Elements / Calculator Buttons Intact</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={validationResult.missingIds.length === 0 ? "text-emerald-400 font-extrabold font-mono" : "text-amber-400 font-extrabold font-mono"}>
                          {validationResult.missingIds.length === 0 ? "✓" : "⚠"}
                        </span>
                        <span>Element Integrity Check ({validationResult.missingIds.length} elements removed)</span>
                      </div>
                    </div>

                    {/* Changes list / Error details */}
                    <div className="md:col-span-2 text-[10.5px] border-t md:border-t-0 md:border-l border-slate-800/40 pt-2 md:pt-0 pl-0 md:pl-3 space-y-1.5 overflow-y-auto max-h-[85px] leading-tight select-text">
                      {validationResult.htmlError && (
                        <div className="text-rose-400 font-mono text-[9px] bg-rose-950/30 p-1 rounded border border-rose-900/30">
                          HTML Error: {validationResult.htmlError}
                        </div>
                      )}
                      {validationResult.jsError && (
                        <div className="text-rose-400 font-mono text-[9px] bg-rose-950/30 p-1 rounded border border-rose-900/30">
                          JS Syntax: {validationResult.jsError}
                        </div>
                      )}
                      {validationResult.missingCalculatorElements.length > 0 && (
                        <div className="text-amber-400 bg-amber-950/10 p-1 rounded border border-amber-500/10">
                          ⚠ Removed calculator keys: <span className="font-mono bg-slate-950 px-1 py-0.5 rounded select-all text-[9.5px]">{validationResult.missingCalculatorElements.join(', ')}</span>
                        </div>
                      )}
                      {validationResult.missingIds.length > 0 && !validationResult.calculatorIntact && (
                        <div className="text-amber-300">
                          Removed Elements: {validationResult.missingIds.slice(0, 4).map(el => `<${el.tag} id="${el.id}">`).join(', ')} {validationResult.missingIds.length > 4 && '...'}
                        </div>
                      )}
                      {validationResult.addedIds.length > 0 && (
                        <div className="text-emerald-400 font-medium font-mono text-[9.5px]">
                          + Added Assets: {validationResult.addedIds.slice(0, 3).map(id => `#${id}`).join(', ')} {validationResult.addedIds.length > 3 && '...'}
                        </div>
                      )}
                      {validationResult.passed && (
                        <div className="text-emerald-400 font-medium mt-0.5">
                          ✓ Excellent! Code validation passed: all existing styling hooks, elements, buttons, and display blocks are 100% safe and intact.
                        </div>
                      )}
                    </div>
                  </div>

               </div>
              )}

              {/* Apply/Discard Actions */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 border-t border-slate-850 dark:border-slate-800/10 pt-4">
                
                {/* Visual Status Indicator on high-severity blocker */}
                <div className="flex items-center gap-2 text-[11px] text-slate-400 select-none">
                  {validationResult?.severity === 'error' && (
                    <span className="flex items-center gap-1 text-rose-400 font-bold animate-pulse">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>Syntactical Errors caught! Reject or edit AI prompt to refactor.</span>
                    </span>
                  )}
                  {validationResult?.severity === 'warning' && (
                    <span className="flex items-center gap-1 text-amber-400 font-medium animate-pulse">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0 text-amber-500" />
                      <span>Note: Some element IDs were removed. Verified safe to accept.</span>
                    </span>
                  )}
                  {validationResult?.severity === 'success' && (
                    <span className="flex items-center gap-1 text-emerald-400 font-medium">
                      <Check className="w-3.5 h-3.5 shrink-0" />
                      <span>This incremental refactoring is completely clean & safe!</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setShowDiffModal(false)}
                    className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                      isDarkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-605'
                    }`}
                  >
                    Reject & Discard
                  </button>
                  <button
                    type="button"
                    id="btn_accept_ai_refactor"
                    disabled={validationResult?.severity === 'error'}
                    onClick={() => {
                      const isPreset = PRESET_PROJECTS.some(p => p.id === activeProjectId);
                      
                      // 1. Record pre-AI rollback backup under active ID
                      recordVersion('auto', 'Prior to AI Suggestion', html, css, js);

                      // Apply Updates
                      setHtml(diffData.newHtml);
                      setCss(diffData.newCss);
                      setJs(diffData.newJs);
                      setActiveProjectName(diffData.newName);

                      let targetId = activeProjectId;

                      if (!isPreset) {
                        setProjects(prev => prev.map(p => {
                          if (p.id === activeProjectId) {
                            return {
                              ...p,
                              name: diffData.newName,
                              html: diffData.newHtml,
                              css: diffData.newCss,
                              javascript: diffData.newJs,
                              updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                            };
                          }
                          return p;
                        }));
                      } else {
                        const newId = 'ai_refine_' + Date.now();
                        const newUserProj: Project = {
                          id: newId,
                          name: diffData.newName,
                          html: diffData.newHtml,
                          css: diffData.newCss,
                          javascript: diffData.newJs,
                          category: activeCategory,
                          updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        };
                        setProjects(prev => [newUserProj, ...prev]);
                        setActiveProjectId(newId);
                        targetId = newId;
                      }

                      // 2. Record the resulting applied AI state
                      const aiLabel = diffData.explanation 
                        ? `AI: ${diffData.explanation.length > 30 ? (diffData.explanation.substring(0, 27) + '...') : diffData.explanation}` 
                        : 'AI Applied Refactor';
                      recordVersion('ai', aiLabel, diffData.newHtml, diffData.newCss, diffData.newJs, targetId);

                      setTimeout(() => {
                        compilePreview();
                        triggerLocalFeedback(`Refinement accepted! Auto-applied to sandbox.`);
                        setShowDiffModal(false);
                        setDiffData(null);
                      }, 50);
                    }}
                    className={`flex items-center gap-1.5 px-6 py-2.5 text-xs font-extrabold text-white rounded-xl shadow-md transition-all ${
                      validationResult?.severity === 'error'
                        ? 'bg-slate-700/60 text-slate-400 opacity-50 cursor-not-allowed border border-slate-800'
                        : 'bg-emerald-600 hover:bg-emerald-500 hover:scale-[1.01] active:scale-[0.99] cursor-pointer'
                    }`}
                  >
                    <Check className="w-4 h-4" />
                    <span>Accept & Apply Changes</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Premium iOS-style Floating Bottom Navigation for Mobile App Builders */}
      {isMobile && (
        <div id="navigation_mobile_bottom" className="fixed bottom-3 left-3 right-3 z-50 md:hidden bg-slate-900/95 dark:bg-slate-950/98 backdrop-blur-md border border-slate-800 rounded-2xl p-2 shadow-[0_16px_40px_rgba(0,0,0,0.5)]">
          <div className="flex items-center justify-between gap-1">
            
            {/* FILE TAB */}
            <button
              onClick={() => {
                setShowLoadPanel(true);
                setActiveMenuDropdown(null);
              }}
              className={`flex-1 flex flex-col items-center justify-center p-1.5 rounded-xl transition-all cursor-pointer ${
                showLoadPanel ? 'text-indigo-400 bg-slate-800/60' : 'text-slate-400 hover:text-indigo-300'
              }`}
            >
              <FolderOpen className="w-5 h-5 text-sky-400" />
              <span className="text-[9px] font-bold mt-1">File</span>
            </button>

            {/* AI TAB */}
            <button
              onClick={() => {
                const aiInput = document.getElementById('ai_prompt_input') as HTMLTextAreaElement;
                if (aiInput) {
                  aiInput.scrollIntoView({ behavior: 'smooth' });
                  aiInput.focus();
                }
              }}
              className="flex-1 flex flex-col items-center justify-center p-1.5 rounded-xl transition-all cursor-pointer text-slate-400 hover:text-indigo-300"
            >
              <Sparkles className="w-5 h-5 text-purple-400" />
              <span className="text-[9px] font-bold mt-1">AI</span>
            </button>

            {/* TEMPLATES TAB */}
            <button
              onClick={() => {
                setShowTemplatesGallery(true);
              }}
              className={`flex-1 flex flex-col items-center justify-center p-1.5 rounded-xl transition-all cursor-pointer ${
                showTemplatesGallery ? 'text-indigo-400 bg-slate-800/60' : 'text-slate-400 hover:text-indigo-300'
              }`}
            >
              <Code className="w-5 h-5 text-pink-400 animate-pulse" />
              <span className="text-[9px] font-bold mt-1">Templates</span>
            </button>

            {/* TOOLS TAB */}
            <button
              onClick={() => {
                setActiveMenuDropdown(activeMenuDropdown === 'tools_mobile' ? null : 'tools_mobile');
              }}
              className={`flex-1 flex flex-col items-center justify-center p-1.5 rounded-xl transition-all cursor-pointer ${
                activeMenuDropdown === 'tools_mobile' ? 'text-indigo-400 bg-slate-800/60' : 'text-slate-400 hover:text-indigo-300'
              }`}
            >
              <Wand2 className="w-5 h-5 text-emerald-400" />
              <span className="text-[9px] font-bold mt-1">Tools</span>
            </button>

            {/* MORE/VIEW TAB */}
            <button
              onClick={() => {
                setMobileActiveView(mobileActiveView === 'editor' ? 'preview' : 'editor');
              }}
              className={`flex-1 flex flex-col items-center justify-center p-1.5 rounded-xl transition-all cursor-pointer ${
                mobileActiveView === 'preview' ? 'text-indigo-400 bg-slate-800/50' : 'text-slate-400 hover:text-indigo-300'
              }`}
            >
              <div className="relative">
                <Laptop className="w-5 h-5 text-indigo-400" />
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
              </div>
              <span className="text-[9px] font-bold mt-1">
                {mobileActiveView === 'editor' ? 'View' : 'Code'}
              </span>
            </button>

          </div>

          {/* Mobile Tools Quick Actions Overlay sheet */}
          <AnimatePresence>
            {activeMenuDropdown === 'tools_mobile' && (
              <>
                <div 
                  className="fixed inset-0 bg-black/45 backdrop-blur-xs z-40" 
                  onClick={() => setActiveMenuDropdown(null)} 
                />
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 15 }}
                  className="absolute bottom-18 left-0 right-0 mx-2 bg-slate-900 border border-slate-800 rounded-2xl p-3 z-50 text-white font-sans flex flex-col gap-1 shadow-2xl"
                >
                  <p className="text-[10px] uppercase tracking-wider text-indigo-400 font-extrabold px-2.5 pb-1 select-none border-b border-slate-800/80 mb-1">
                    Mobile Tools
                  </p>
                  <button
                    onClick={() => { setActiveMenuDropdown(null); setShowVersionsPanel(true); }}
                    className="flex items-center gap-3 px-3 py-2.5 text-xs font-bold hover:bg-slate-800 rounded-xl transition-all text-left"
                  >
                    <History className="w-4 h-4 text-amber-400" />
                    <span>Version History</span>
                  </button>
                  <button
                    onClick={() => { setActiveMenuDropdown(null); setShowAndroidPackagerModal(true); }}
                    className="flex items-center gap-3 px-3 py-2.5 text-xs font-bold hover:bg-slate-800 rounded-xl transition-all text-left"
                  >
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span>Android Packaging</span>
                  </button>
                  <button
                    onClick={() => { setActiveMenuDropdown(null); setSettingsDropdownOpen(true); }}
                    className="flex items-center gap-3 px-3 py-2.5 text-xs font-bold hover:bg-slate-800 rounded-xl transition-all text-left"
                  >
                    <Settings className="w-4 h-4 text-slate-400" />
                    <span>Preferences Settings</span>
                  </button>
                  <button
                    onClick={() => { setActiveMenuDropdown(null); setShowHelpModal(true); }}
                    className="flex items-center gap-3 px-3 py-2.5 text-xs font-bold hover:bg-slate-800 rounded-xl transition-all text-left"
                  >
                    <HelpCircle className="w-4 h-4 text-indigo-400" />
                    <span>Help & Quick Diagnostic</span>
                  </button>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
