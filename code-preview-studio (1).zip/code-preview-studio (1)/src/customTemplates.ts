// Dedicated Custom Templates for AI Studio Builder menu system

export const TEMPLATE_CALCULATOR = {
  html: `<!-- Modern Neon Glass calculator -->
<div class="calculator-container">
  <div class="calculator-header">
    <div class="glass-orb orb-red"></div>
    <div class="glass-orb orb-amber"></div>
    <div class="glass-orb orb-emerald"></div>
    <span class="app-title">NEON CALC</span>
  </div>
  
  <div class="calculator-display">
    <div class="calc-history" id="calcHistory"></div>
    <div class="calc-screen" id="calcScreen">0</div>
  </div>
  
  <div class="calculator-keyboard">
    <button class="key action" onclick="pressClear()">AC</button>
    <button class="key action" onclick="pressDelete()">DEL</button>
    <button class="key operator" onclick="pressOperator('%')">%</button>
    <button class="key operator" onclick="pressOperator('/')">÷</button>
    
    <button class="key digit" onclick="pressNum('7')">7</button>
    <button class="key digit" onclick="pressNum('8')">8</button>
    <button class="key digit" onclick="pressNum('9')">9</button>
    <button class="key operator" onclick="pressOperator('*')">×</button>
    
    <button class="key digit" onclick="pressNum('4')">4</button>
    <button class="key digit" onclick="pressNum('5')">5</button>
    <button class="key digit" onclick="pressNum('6')">6</button>
    <button class="key operator" onclick="pressOperator('-')">-</button>
    
    <button class="key digit" onclick="pressNum('1')">1</button>
    <button class="key digit" onclick="pressNum('2')">2</button>
    <button class="key digit" onclick="pressNum('3')">3</button>
    <button class="key operator" onclick="pressOperator('+')">+</button>
    
    <button class="key digit double" onclick="pressNum('0')">0</button>
    <button class="key digit" onclick="pressNum('.')">.</button>
    <button class="key equals" onclick="pressEquals()">=</button>
  </div>
</div>`,
  css: `@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@500;700&display=swap');

body {
  background: radial-gradient(circle at center, #111827 0%, #030712 100%);
  color: #f3f4f6;
  font-family: 'Inter', system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
  padding: 20px;
}

.calculator-container {
  background: rgba(31, 41, 55, 0.45);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 28px;
  width: 100%;
  max-width: 340px;
  padding: 24px;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
}

.calculator-header {
  display: flex;
  align-items: center;
  gap: 7px;
  margin-bottom: 20px;
}

.glass-orb {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}
.orb-red { background: #ef4444; }
.orb-amber { background: #f59e0b; }
.orb-emerald { background: #10b981; }

.app-title {
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px;
  font-weight: 700;
  color: #64748b;
  margin-left: auto;
  letter-spacing: 1px;
}

.calculator-display {
  background: rgba(17, 24, 39, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 20px;
  padding: 20px;
  text-align: right;
  margin-bottom: 24px;
  min-height: 90px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.4);
}

.calc-history {
  color: #64748b;
  font-family: 'JetBrains Mono', monospace;
  font-size: 12px;
  min-height: 18px;
  word-break: break-all;
}

.calc-screen {
  color: #38bdf8;
  font-family: 'JetBrains Mono', monospace;
  font-size: 34px;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-shadow: 0 0 10px rgba(56, 189, 248, 0.2);
}

.calculator-keyboard {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
}

.key {
  border: 1px solid rgba(255, 255, 255, 0.04);
  background: rgba(55, 65, 81, 0.5);
  color: #f3f4f6;
  font-size: 18px;
  font-weight: 600;
  height: 58px;
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  align-items: center;
  justify-content: center;
  user-select: none;
}

.key:hover {
  background: rgba(75, 85, 99, 0.7);
  transform: translateY(-2px);
  border-color: rgba(255, 255, 255, 0.1);
}

.key:active {
  transform: translateY(1px);
}

.key.action {
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
  border-color: rgba(239, 68, 68, 0.15);
}
.key.action:hover {
  background: rgba(239, 68, 68, 0.25);
  color: #f87171;
}

.key.operator {
  background: rgba(245, 158, 11, 0.1);
  color: #fbbf24;
  border-color: rgba(245, 158, 11, 0.15);
}
.key.operator:hover {
  background: rgba(245, 158, 11, 0.25);
}

.key.digit {
  background: rgba(31, 41, 55, 0.6);
}

.key.double {
  grid-column: span 2;
  border-radius: 16px;
}

.key.equals {
  background: linear-gradient(135deg, #6366f1, #a855f7);
  color: #ffffff;
  font-weight: 700;
  border: none;
  box-shadow: 0 4px 14px rgba(99, 102, 241, 0.35);
}
.key.equals:hover {
  background: linear-gradient(135deg, #4f46e5, #9333ea);
  box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
}`,
  javascript: `let currentVal = '0';
let historyVal = '';
let resetOnNextNum = false;

const screen = document.getElementById('calcScreen');
const history = document.getElementById('calcHistory');

function updateDisplay() {
  screen.innerText = currentVal;
  history.innerText = historyVal;
}

function pressClear() {
  currentVal = '0';
  historyVal = '';
  resetOnNextNum = false;
  updateDisplay();
}

function pressDelete() {
  if (currentVal.length > 1) {
    currentVal = currentVal.slice(0, -1);
  } else {
    currentVal = '0';
  }
  updateDisplay();
}

function pressNum(num) {
  if (resetOnNextNum) {
    currentVal = '';
    resetOnNextNum = false;
  }
  if (currentVal === '0' && num !== '.') {
    currentVal = num;
  } else {
    if (num === '.' && currentVal.includes('.')) return;
    currentVal += num;
  }
  updateDisplay();
}

function pressOperator(op) {
  if (currentVal === '0' && historyVal !== '') {
    // just swap operator
    const idx = historyVal.lastIndexOf(' ');
    historyVal = historyVal.substring(0, idx) + ' ' + op;
  } else {
    historyVal = currentVal + ' ' + op;
    currentVal = '0';
  }
  updateDisplay();
}

function pressEquals() {
  if (!historyVal || currentVal === '') return;
  const parts = historyVal.split(' ');
  const prev = parseFloat(parts[0]);
  const curr = parseFloat(currentVal);
  const operator = parts[1];
  let res = 0;
  
  if (isNaN(prev) || isNaN(curr)) return;
  
  switch(operator) {
    case '+': res = prev + curr; break;
    case '-': res = prev - curr; break;
    case '*': res = prev * curr; break;
    case '/': res = curr !== 0 ? prev / curr : 'Error'; break;
    case '%': res = prev % curr; break;
    default: return;
  }
  
  historyVal = prev + ' ' + operator + ' ' + curr + ' =';
  currentVal = String(res);
  resetOnNextNum = true;
  updateDisplay();
  historyVal = '';
}`
};

export const TEMPLATE_NOTES = {
  html: `<!-- Dynamic Sticky Notes Board -->
<div class="notes-app">
  <div class="app-header">
    <div class="brand">
      <span class="icon">📝</span>
      <div>
        <h1>Notes Canvas</h1>
        <p class="subtitle">Quick interactive persistent workspace scratchpad</p>
      </div>
    </div>
    
    <button class="new-note-btn" onclick="addNote()">
      <span>+ Add New Note</span>
    </button>
  </div>
  
  <div class="notes-board" id="notesBoard">
    <!-- Inline populated sticky notes -->
  </div>
</div>`,
  css: `@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;650;800&display=swap');

body {
  background: #0f172a;
  color: #f1f5f9;
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  margin: 0;
  padding: 30px;
}

.notes-app {
  max-width: 1100px;
  margin: 0 auto;
}

.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 35px;
  background: rgba(30, 41, 59, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.04);
  padding: 20px 24px;
  border-radius: 20px;
  backdrop-filter: blur(10px);
}

.brand {
  display: flex;
  align-items: center;
  gap: 15px;
}

.brand .icon {
  font-size: 28px;
}

.brand h1 {
  font-size: 20px;
  font-weight: 800;
  margin: 0;
  color: #38bdf8;
}

.brand .subtitle {
  font-size: 11px;
  color: #64748b;
  margin: 4px 0 0 0;
}

.new-note-btn {
  background: linear-gradient(135deg, #0284c7, #0f172a);
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.08);
  padding: 10px 20px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 4px 15px rgba(2, 132, 199, 0.2);
}

.new-note-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(2, 132, 199, 0.35);
  border-color: rgba(56, 189, 248, 0.4);
}

.notes-board {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 25px;
}

.note-card {
  border-radius: 20px;
  padding: 20px;
  position: relative;
  min-height: 200px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-shadow: 0 10px 30px rgba(0,0,0,0.25);
  transition: all 0.25s ease;
  border: 1px solid rgba(255,255,255,0.06);
}

.note-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 35px rgba(0,0,0,0.4);
}

.note-card.color-0 { background: linear-gradient(135deg, #2e1065, #1e1b4b); }
.note-card.color-1 { background: linear-gradient(135deg, #064e3b, #022c22); }
.note-card.color-2 { background: linear-gradient(135deg, #7c2d12, #431407); }
.note-card.color-3 { background: linear-gradient(135deg, #1e3a8a, #172554); }

.note-textarea {
  background: transparent;
  border: none;
  width: 100%;
  height: 120px;
  color: #f1f5f9;
  font-family: inherit;
  font-size: 14px;
  resize: none;
  outline: none;
  line-height: 1.6;
}

.note-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 15px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  padding-top: 12px;
}

.note-date {
  font-family: monospace;
  font-size: 10px;
  color: #64748b;
  letter-spacing: 0.5px;
}

.note-delete {
  background: transparent;
  border: none;
  color: #f87171;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  padding: 4px 8px;
  border-radius: 6px;
  transition: all 0.2s;
}

.note-delete:hover {
  background: rgba(239, 68, 68, 0.15);
  color: #ef4444;
}`,
  javascript: `let savedNotes = [];
try {
  savedNotes = JSON.parse(localStorage.getItem('notes_canvas_data') || '[]');
} catch(e) {
  savedNotes = [];
}

function saveNotesToStorage() {
  localStorage.setItem('notes_canvas_data', JSON.stringify(savedNotes));
}

function renderNotesBoard() {
  const board = document.getElementById('notesBoard');
  board.innerHTML = '';
  
  if (savedNotes.length === 0) {
    board.innerHTML = \`
      <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px; color: #64748b; border: 2px dashed rgba(255,255,255,0.05); border-radius: 20px;">
        <span style="font-size: 40px; display: block; margin-bottom: 12px;">🗒️</span>
        <h3 style="margin: 0; font-size: 16px; color: #cbd5e1;">Your Canvas is Empty</h3>
        <p style="font-size: 12px; margin: 6px 0 0 0;">Create a sticky note and pin down your ideas!</p>
      </div>
    \`;
    return;
  }
  
  savedNotes.forEach((note, idx) => {
    const cardColorClass = 'color-' + (note.colorIdx || 0);
    const card = document.createElement('div');
    card.className = 'note-card ' + cardColorClass;
    card.innerHTML = \`
      <textarea class="note-textarea" oninput="updateNoteContent(\${idx}, this.value)" placeholder="Type details here...">\${note.text}</textarea>
      <div class="note-footer">
        <span class="note-date">\${note.date}</span>
        <button class="note-delete" onclick="deleteNote(\${idx})">Delete</button>
      </div>
    \`;
    board.appendChild(card);
  });
}

function addNote() {
  const currentTimestamp = new Date().toLocaleDateString([], { month: 'short', day: 'numeric' }) + " " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const randomColorIdx = Math.floor(Math.random() * 4);
  
  savedNotes.unshift({
    text: '',
    date: currentTimestamp,
    colorIdx: randomColorIdx
  });
  
  saveNotesToStorage();
  renderNotesBoard();
}

function updateNoteContent(idx, value) {
  savedNotes[idx].text = value;
  saveNotesToStorage();
}

function deleteNote(idx) {
  savedNotes.splice(idx, 1);
  saveNotesToStorage();
  renderNotesBoard();
}

// Kickstart
document.addEventListener('DOMContentLoaded', () => {
  if (savedNotes.length === 0) {
    addNote();
  } else {
    renderNotesBoard();
  }
});
renderNotesBoard();`
};

export const TEMPLATE_QUIZ = {
  html: `<!-- Interactive Space Quiz App Sandbox -->
<div class="trivia-universe">
  <div class="quiz-card">
    <div class="quiz-visualizer">
      <div class="visualizer-bar" id="visualizerBar"></div>
    </div>
    
    <div class="quiz-body" id="triviaArea">
      <div class="step-label" id="stepLabel">Question 1 of 5</div>
      <h2 class="question-text" id="questionText">Is light gravity responsive?</h2>
      
      <div class="options-layout" id="optionsLayout">
        <!-- Interactive option buttons -->
      </div>
    </div>
    
    <div class="quiz-footer">
      <span class="trivia-badge">🌌 COSMOS BOARD</span>
      <span class="score-badge" id="scoreBadge">SCORE: 0</span>
    </div>
  </div>
</div>`,
  css: `@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;700;800&display=swap');

body {
  background: radial-gradient(circle at 50% 50%, #0c1020 0%, #04060c 100%);
  color: #f8fafc;
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  margin: 0;
  padding: 10px;
}

.trivia-universe {
  width: 100%;
  max-width: 500px;
}

.quiz-card {
  background: rgba(13, 18, 36, 0.8);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 30px 60px rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(15px);
}

.quiz-visualizer {
  height: 6px;
  background: #10162a;
}

.visualizer-bar {
  height: 100%;
  width: 20%;
  background: linear-gradient(90deg, #7c3aed, #ec4899);
  transition: width 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.quiz-body {
  padding: 30px;
}

.step-label {
  font-family: monospace;
  font-size: 11px;
  font-weight: 700;
  color: #d946ef;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  margin-bottom: 12px;
}

.question-text {
  font-size: 18px;
  font-weight: 800;
  line-height: 1.5;
  margin: 0 0 25px 0;
  color: #f1f5f9;
}

.options-layout {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.option-btn {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.06);
  color: #cbd5e1;
  text-align: left;
  padding: 16px 20px;
  border-radius: 16px;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.option-btn:hover {
  background: rgba(255, 255, 255, 0.08);
  border-color: rgba(139, 92, 246, 0.4);
  color: #ffffff;
  transform: translateX(2px);
}

.option-btn.correct {
  background: rgba(16, 185, 129, 0.15);
  border-color: #10b981;
  color: #34d399;
}

.option-btn.wrong {
  background: rgba(239, 68, 68, 0.15);
  border-color: #ef4444;
  color: #f87171;
}

.quiz-footer {
  border-top: 1px solid rgba(255, 255, 255, 0.04);
  padding: 18px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(4, 6, 12, 0.4);
}

.trivia-badge {
  font-size: 10px;
  font-weight: 800;
  color: #64748b;
  letter-spacing: 1px;
}

.score-badge {
  background: rgba(139, 92, 246, 0.15);
  border: 1px solid rgba(139, 92, 246, 0.3);
  color: #8b5cf6;
  font-family: monospace;
  font-size: 11px;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 6px;
}

.restart-action {
  background: linear-gradient(135deg, #7c3aed, #db2777);
  color: white;
  border: none;
  font-weight: 700;
  border-radius: 12px;
  padding: 12px 24px;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.2s;
}

.restart-action:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 20px rgba(124, 58, 237, 0.4);
}`,
  javascript: `const triviaSet = [
  {
    question: "What is the approximate age of our Universe?",
    options: ["4.5 Billion years", "13.8 Billion years", "20 Billion years", "9.3 Billion years"],
    correctIdx: 1
  },
  {
    question: "Which solar system planet is least dense (would float in water)?",
    options: ["Uranus", "Neptune", "Saturn", "Jupiter"],
    correctIdx: 2
  },
  {
    question: "Which heavy element is generated during the final moments before massive supernovas?",
    options: ["Iron", "Lead", "Carbon", "Gold"],
    correctIdx: 0
  },
  {
    question: "What type of cosmic object is Sagittarius A*?",
    options: ["Red Giant Star", "Supermassive Black Hole", "Neutron Star", "Spiral Galaxy"],
    correctIdx: 1
  },
  {
    question: "How long does light roughly take to travel from our Sun to Planet Earth?",
    options: ["8 seconds", "8 minutes", "8 hours", "1 year"],
    correctIdx: 1
  }
];

let activeIdx = 0;
let userQuizScore = 0;
let levelAnswered = false;

function loadTriviaLevel() {
  levelAnswered = false;
  const bar = document.getElementById('visualizerBar');
  const label = document.getElementById('stepLabel');
  const qText = document.getElementById('questionText');
  const layout = document.getElementById('optionsLayout');
  const score = document.getElementById('scoreBadge');
  
  if (activeIdx >= triviaSet.length) {
    showCompletedFrame();
    return;
  }
  
  const activeLevel = triviaSet[activeIdx];
  bar.style.width = ((activeIdx / triviaSet.length) * 100) + '%';
  label.innerText = 'Question ' + (activeIdx + 1) + ' of ' + triviaSet.length;
  qText.innerText = activeLevel.question;
  score.innerText = 'SCORE: ' + (userQuizScore * 10);
  
  layout.innerHTML = '';
  activeLevel.options.forEach((opt, idx) => {
    const btn = document.createElement('button');
    btn.className = 'option-btn';
    btn.innerHTML = '<span>' + opt + '</span><span class="indicator"></span>';
    btn.onclick = () => verifyActiveOption(idx, btn);
    layout.appendChild(btn);
  });
}

function verifyActiveOption(idx, btn) {
  if (levelAnswered) return;
  levelAnswered = true;
  const activeLevel = triviaSet[activeIdx];
  const btns = document.querySelectorAll('.option-btn');
  
  if (idx === activeLevel.correctIdx) {
    btn.classList.add('correct');
    userQuizScore++;
  } else {
    btn.classList.add('wrong');
    btns[activeLevel.correctIdx].classList.add('correct');
  }
  
  setTimeout(() => {
    activeIdx++;
    loadTriviaLevel();
  }, 1600);
}

function showCompletedFrame() {
  const bar = document.getElementById('visualizerBar');
  const area = document.getElementById('triviaArea');
  const score = document.getElementById('scoreBadge');
  
  bar.style.width = '100%';
  score.innerText = 'SCORE: ' + (userQuizScore * 10);
  
  area.innerHTML = \`
    <div style="text-align: center; padding: 25px 0;">
      <div style="font-size: 52px; margin-bottom: 12px; animation: bounce 1.5s infinite;">🪐</div>
      <h3 style="font-weight: 800; font-size: 20px; color: #f1f5f9; margin: 0 0 8px 0;">Cosmos Voyage Complete!</h3>
      <p style="color: #64748b; font-size: 13px; margin: 0 0 25px 0;">You successfully scored <strong>\${userQuizScore * 10} points</strong> (\${userQuizScore} out of \${triviaSet.length} answers correct).</p>
      <button class="restart-action" onclick="resetTriviaJourney()">Voyage Again</button>
    </div>
  \`;
}

function resetTriviaJourney() {
  activeIdx = 0;
  userQuizScore = 0;
  
  document.getElementById('triviaArea').innerHTML = \`
    <div class="step-label" id="stepLabel">Question 1 of 5</div>
    <h2 class="question-text" id="questionText">Is light gravity responsive?</h2>
    <div class="options-layout" id="optionsLayout"></div>
  \`;
  
  loadTriviaLevel();
}

window.onload = loadTriviaLevel;
loadTriviaLevel();`
};

export const TEMPLATE_TODO = {
  html: `<!-- Clean Modern Interactive Focus Task Manager -->
<div class="todo-app-wrapper">
  <div class="app-card">
    <div class="header-section">
      <div class="status-dot"></div>
      <h2>Strategic Focus Board</h2>
      <p>Organize, clean, and resolve priority items systematically</p>
    </div>
    
    <form class="interaction-form" onsubmit="handleAddTask(event)">
      <input type="text" id="todoField" placeholder="Describe next actionable step..." required />
      <button type="submit">Enlist</button>
    </form>
    
    <div class="filter-pills">
      <button class="pill active" onclick="updateFilter('all', this)">All</button>
      <button class="pill" onclick="updateFilter('active', this)">Pending</button>
      <button class="pill" onclick="updateFilter('completed', this)">Cleaned</button>
    </div>
    
    <ul class="task-collection" id="taskCollection">
      <!-- To-Do items populated iteratively -->
    </ul>
    
    <div class="stats-panel">
      <span id="pendingStatCount">0 actions remaining</span>
      <button class="clear-action" onclick="clearCompletedTasks()">Clear Completed</button>
    </div>
  </div>
</div>`,
  css: `@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');

body {
  background: #020617;
  color: #f1f5f9;
  font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
  margin: 0;
  padding: 40px 15px;
  display: flex;
  justify-content: center;
}

.todo-app-wrapper {
  width: 100%;
  max-width: 460px;
}

.app-card {
  background: #0f172a;
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 24px;
  padding: 26px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.45);
}

.header-section {
  position: relative;
  margin-bottom: 24px;
}

.status-dot {
  width: 6px;
  height: 6px;
  background: #3b82f6;
  border-radius: 50%;
  position: absolute;
  top: 8px;
  left: -14px;
  box-shadow: 0 0 10px #3b82f6;
}

.header-section h2 {
  font-size: 18px;
  font-weight: 800;
  margin: 0 0 4px 0;
  color: #f8fafc;
}

.header-section p {
  font-size: 11.5px;
  color: #64748b;
  margin: 0;
  line-height: 1.4;
}

.interaction-form {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.interaction-form input {
  flex-grow: 1;
  background: #020617;
  border: 1px solid rgba(255, 255, 255, 0.07);
  color: #ffffff;
  border-radius: 12px;
  padding: 12px 16px;
  font-size: 13px;
  outline: none;
  transition: all 0.2s;
}

.interaction-form input:focus {
  border-color: #3b82f6;
}

.interaction-form button {
  background: linear-gradient(135deg, #1d4ed8, #1e40af);
  color: white;
  border: none;
  font-weight: 700;
  border-radius: 12px;
  font-size: 13px;
  padding: 0 18px;
  cursor: pointer;
  transition: opacity 0.2s;
}

.interaction-form button:hover {
  opacity: 0.95;
}

.filter-pills {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}

.pill {
  background: transparent;
  border: none;
  color: #64748b;
  font-weight: 700;
  font-size: 11.5px;
  padding: 6px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  letter-spacing: 0.5px;
}

.pill:hover {
  color: #cbd5e1;
}

.pill.active {
  background: rgba(59, 130, 246, 0.1);
  color: #3b82f6;
}

.task-collection {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: 260px;
  overflow-y: auto;
}

.task-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid rgba(255,255,255,0.03);
  padding: 12px 16px;
  border-radius: 12px;
  transition: all 0.2s;
}

.task-item.completed {
  opacity: 0.55;
  background: transparent;
}

.task-item.completed span {
  text-decoration: line-through;
  color: #64748b;
}

.task-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.todo-checkbox {
  width: 17px;
  height: 17px;
  accent-color: #3b82f6;
  cursor: pointer;
}

.delete-action {
  background: transparent;
  border: none;
  color: #f87171;
  font-weight: 700;
  font-size: 15px;
  cursor: pointer;
  opacity: 0.4;
  transition: opacity 0.2s;
}

.task-item:hover .delete-action {
  opacity: 1;
}

.stats-panel {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11.5px;
  color: #64748b;
  margin-top: 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  padding-top: 14px;
}

.clear-action {
  background: transparent;
  border: none;
  color: #ef4444;
  cursor: pointer;
  font-size: 11.5px;
  font-weight: 600;
}
.clear-action:hover {
  text-decoration: underline;
}
`,
  javascript: `let tasks = [];
try {
  tasks = JSON.parse(localStorage.getItem('focus_board_tasks') || '[]');
} catch(e) {
  tasks = [];
}
let activeFilter = 'all';

function saveTasksToStorage() {
  localStorage.setItem('focus_board_tasks', JSON.stringify(tasks));
}

function renderFocusBoard() {
  const container = document.getElementById('taskCollection');
  container.innerHTML = '';
  
  let filtered = tasks;
  if (activeFilter === 'active') {
    filtered = tasks.filter(t => !t.completed);
  } else if (activeFilter === 'completed') {
    filtered = tasks.filter(t => t.completed);
  }
  
  if (filtered.length === 0) {
    container.innerHTML = \`
      <div style="text-align: center; color: #64748b; font-size: 12px; padding: 30px; font-style: italic;">
        No items matching category
      </div>
    \`;
  } else {
    filtered.forEach((task) => {
      const li = document.createElement('li');
      li.className = 'task-item' + (task.completed ? ' completed' : '');
      li.innerHTML = \`
        <div class="task-left">
          <input type="checkbox" class="todo-checkbox" \${task.completed ? 'checked' : ''} onchange="toggleTask(\${task.id})" />
          <span>\${task.text}</span>
        </div>
        <button class="delete-action" onclick="removeTask(\${task.id})">×</button>
      \`;
      container.appendChild(li);
    });
  }
  
  const pendingCount = tasks.filter(t => !t.completed).length;
  document.getElementById('pendingStatCount').innerText = pendingCount + ' item' + (pendingCount === 1 ? '' : 's') + ' pending';
}

function handleAddTask(e) {
  e.preventDefault();
  const input = document.getElementById('todoField');
  const txt = input.value.trim();
  if (!txt) return;
  
  tasks.unshift({
    id: Date.now(),
    text: txt,
    completed: false
  });
  
  input.value = '';
  saveTasksToStorage();
  renderFocusBoard();
}

function toggleTask(id) {
  const item = tasks.find(t => t.id === id);
  if (item) {
    item.completed = !item.completed;
    saveTasksToStorage();
    renderFocusBoard();
  }
}

function removeTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  saveTasksToStorage();
  renderFocusBoard();
}

function updateFilter(type, buttonEl) {
  activeFilter = type;
  document.querySelectorAll('.pill').forEach(b => b.classList.remove('active'));
  buttonEl.classList.add('active');
  renderFocusBoard();
}

function clearCompletedTasks() {
  tasks = tasks.filter(t => !t.completed);
  saveTasksToStorage();
  renderFocusBoard();
}

// Initial bootstrap
document.addEventListener('DOMContentLoaded', () => {
  if (tasks.length === 0) {
    tasks = [
      { id: 1, text: 'Review visual metrics dashboard', completed: false },
      { id: 2, text: 'Configure custom asset loaders', completed: true }
    ];
  }
  renderFocusBoard();
});
renderFocusBoard();`
};
