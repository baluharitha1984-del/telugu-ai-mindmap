export interface Project {
  id: string;
  name: string;
  html: string;
  css: string;
  javascript: string;
  category?: string;
  useTailwind?: boolean;
  useFontAwesome?: boolean;
  useGoogleFonts?: boolean;
  updatedAt?: string;
}

export type VersionType = 'initial' | 'auto' | 'manual' | 'ai';

export interface ProjectVersion {
  id: string;
  projectId: string;
  timestamp: string;
  html: string;
  css: string;
  javascript: string;
  name?: string;
  type: VersionType;
}

export type EditorTab = 'html' | 'css' | 'javascript';


export interface PreviewDimensions {
  width: number;
  height: number;
}
