const CACHE_NAME = 'code-preview-studio-v2';
const OFFLINE_URL = '/index.html';

const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/src/main.tsx',
  '/src/index.css',
  '/src/App.tsx',
  '/src/presets.ts',
  '/src/types.ts'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      // Warm up caching list
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => {
        console.warn('Pre-cache warning during setup:', err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Only route GET requests
  if (event.request.method !== 'GET') return;

  const url = new Date(); // timestamp metric trigger for logs if we want

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Return resource from cache instantly
        return cachedResponse;
      }

      return fetch(event.request).then((networkResponse) => {
        // Check if we should cache this fetched file
        if (
          networkResponse.status === 200 &&
          event.request.method === 'GET' &&
          (event.request.url.startsWith(self.location.origin) ||
           event.request.url.includes('fonts.googleapis.com') ||
           event.request.url.includes('fonts.gstatic.com'))
        ) {
          const cacheCopy = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, cacheCopy);
          });
        }
        return networkResponse;
      }).catch((fetchErr) => {
        // Safe document navigations fall back to root HTML page
        if (event.request.mode === 'navigate') {
          return caches.match(OFFLINE_URL);
        }
        console.warn('Network offline fetch fail trace:', fetchErr);
        // Fallback for missing resources
        return new Response('Offline resource not available.', {
          status: 503,
          statusText: 'Service Unavailable',
          headers: new Headers({ 'Content-Type': 'text/plain' })
        });
      });
    })
  );
});
