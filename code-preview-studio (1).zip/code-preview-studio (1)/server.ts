import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { PRESET_PROJECTS } from "./src/presets";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Please declare it in the Settings > Secrets menu.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

async function generateContentWithRetry(client: GoogleGenAI, params: {
  contents: string;
  config: any;
}, maxRetries = 3) {
  let lastError: any = null;
  const models = ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"];

  for (const model of models) {
    let attempt = 0;
    // Fast-failover logic: For severe server demand spikes or unavailabilities,
    // minimize retries on the exact same cluster to avoid excessive user drag.
    let modelMaxRetries = maxRetries;

    while (attempt < modelMaxRetries) {
      try {
        console.log(`[Gemini API] Requesting ${model} (attempt ${attempt + 1}/${modelMaxRetries})...`);
        const response = await client.models.generateContent({
          ...params,
          model,
        });
        return response;
      } catch (err: any) {
        lastError = err;
        attempt++;
        const errMsg = (err?.message || String(err)).toLowerCase();
        const statusCode = String(err?.status || err?.statusCode || err?.code || "");
        
        // Detect daily quota limit or payment exhaustion which retrying will never resolve
        const isHardQuotaExceeded = 
          statusCode.includes("429") && (
            errMsg.includes("quota exceeded") || 
            errMsg.includes("exceeded your current quota") || 
            errMsg.includes("billing") || 
            errMsg.includes("requestsperday") || 
            errMsg.includes("perday") ||
            errMsg.includes("freetier") ||
            errMsg.includes("limit: 20")
          );

        if (isHardQuotaExceeded) {
          console.warn(`[Gemini API] Hard daily/billing quota exhaustion detected for ${model}. Bypassing retries.`);
          break; // Exit the loop for this model immediately without slow retry delays
        }

        const isOverloadedOrDemandSpike = 
          statusCode.includes("503") || 
          errMsg.includes("503") ||
          errMsg.includes("unavailable") || 
          errMsg.includes("demand") || 
          errMsg.includes("temporary") ||
          errMsg.includes("overloaded");

        const isTransient = 
          isOverloadedOrDemandSpike ||
          statusCode.includes("429") ||
          errMsg.includes("429") || 
          errMsg.includes("exhausted");

        // If the model is currently experiencing high demand or overload,
        // reduce its maximum retry count to 1 or 2 attempts. This lets the scheduler
        // fail over to the next candidate model (e.g. flash-lite) much faster!
        if (isOverloadedOrDemandSpike && modelMaxRetries > 2) {
          console.info(`[Gemini API] Capacity overload detected on ${model}. Reducing try limits to enable fast-failover.`);
          modelMaxRetries = 2;
        }

        if (isTransient && attempt < modelMaxRetries) {
          // Adjust backoff delay: slightly shorter/more responsive for load spikes so we can clear or shift fast.
          const isDemandSpike = isOverloadedOrDemandSpike;
          const delayBase = isDemandSpike ? 800 : 1500;
          const delay = Math.pow(2, attempt) * delayBase + Math.random() * 300;
          
          console.warn(`[Gemini API] Transient error (status/code: ${statusCode}): "${err?.message || err}". Retrying same model in ${Math.round(delay)}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          console.warn(`[Gemini API] Model ${model} failed non-transiently, is severely overloaded, or ran out of retries. Error: "${err?.message || err}". Trying next fallback if available.`);
          break;
        }
      }
    }
  }
  throw lastError;
}

// Search prompt keywords for offline matching
function matchLocalPreset(promptText: string) {
  const p = promptText.toLowerCase();
  
  if (p.includes("clock") || p.includes("time") || p.includes("neon") || p.includes("hour") || p.includes("ampm")) {
    return PRESET_PROJECTS.find(proj => proj.id === 'neon-clock');
  }
  if (p.includes("ball") || p.includes("gravity") || p.includes("physic") || p.includes("particle") || p.includes("bounce")) {
    return PRESET_PROJECTS.find(proj => proj.id === 'bouncing-balls');
  }
  if (p.includes("color") || p.includes("palette") || p.includes("swatch") || p.includes("hex") || p.includes("generator")) {
    return PRESET_PROJECTS.find(proj => proj.id === 'cool-color-generator');
  }
  if (p.includes("snake") || p.includes("game") || p.includes("arcade") || p.includes("retro") || p.includes("score")) {
    return PRESET_PROJECTS.find(proj => proj.id === 'snake-game');
  }
  if (p.includes("timer") || p.includes("pomodoro") || p.includes("focus") || p.includes("alarm") || p.includes("rain")) {
    return PRESET_PROJECTS.find(proj => proj.id === 'pomodoro-timer');
  }
  return null;
}

function handleOfflineGenerateFallback(prompt: string, errorMsg: string) {
  const matched = matchLocalPreset(prompt);
  if (matched) {
    return {
      html: matched.html,
      css: matched.css,
      javascript: matched.javascript,
      appName: `${matched.name} (Offline-Matched)`,
      explanation: `⚠️ Note: Shared Gemini API quota reached. I successfully matched your query offline and loaded the high-fidelity pre-compiled "${matched.name}" preset template!`
    };
  }

  // General programmatic fallback
  return {
    appName: `${prompt.trim().substring(0, 24)} (Local Workspace)`,
    explanation: `⚠️ Shared Gemini API Limit met. Started dynamic local notepad fallback so you can continue code writing!`,
    html: `<!-- Local Recovery Sandbox Frame -->
<div class="max-w-2xl mx-auto p-6 bg-slate-900/85 border border-indigo-500/20 rounded-3xl backdrop-blur-md shadow-2xl text-center space-y-6">
  <div class="inline-flex p-3 rounded-2xl bg-amber-500/10 text-amber-400 mb-2">
    <svg class="w-8 h-8 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
  </div>
  
  <div class="space-y-2">
    <h1 class="text-xl font-bold font-sans tracking-tight text-white uppercase">${prompt.toUpperCase()}</h1>
    <p class="text-xs text-slate-400 max-w-md mx-auto">The Gemini API is currently unavailable or quota-limited. Rest assured, we have recovered into local offline workbench mode!</p>
  </div>

  <!-- Interactive Sandbox Notepad Card -->
  <div class="p-5 bg-slate-950/60 border border-slate-800 rounded-2xl text-left space-y-4">
    <label class="block text-[10px] font-bold uppercase tracking-wider text-indigo-400 font-mono">Dynamic Local Clipboard</label>
    <textarea id="local-notepad" class="w-full h-32 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500" placeholder="Type notes or code drafts here... Your entries are fully persisted inside this session's sandbox!"></textarea>
    
    <div class="flex justify-between items-center text-xs text-slate-400 font-mono">
      <span id="char-counter">0 characters</span>
      <button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-sans font-bold transition-all" onclick="saveToLocalNotepad()">Save Input</button>
    </div>
  </div>

  <div class="pt-4 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
    <span class="flex items-center gap-1.5 font-mono"><span class="w-2 h-2 rounded-full bg-amber-500"></span> Local Mode Active</span>
    <span class="text-[11px] italic">Tip: Configure custom GEMINI_API_KEY in platform Settings to regain real-time AI capabilities!</span>
  </div>
</div>`,
    css: `/* Local Recovery Workspace styles */
body {
  margin: 0;
  padding: 0;
  background-color: #030712;
  background-image: radial-gradient(circle at 50% 50%, #1e1b4b 0%, #030712 100%);
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  color: #f3f4f6;
  font-family: 'Inter', system-ui, sans-serif;
}`,
    javascript: `// Local Notepad Handlers
const notepad = document.getElementById('local-notepad');
if (notepad) {
  notepad.value = localStorage.getItem('local_sandbox_notes') || '';
  updateCounter();
  notepad.addEventListener('input', updateCounter);
}

function updateCounter() {
  const count = notepad.value.length;
  document.getElementById('char-counter').innerText = count + ' characters';
}

function saveToLocalNotepad() {
  localStorage.setItem('local_sandbox_notes', notepad.value);
  console.log("Notepad persisted locally! 💾 Session contents saved.");
}`
  };
}

function handleOfflineChatFallback(messages: any[], errorMsg: string) {
  const lastUserMsg = messages[messages.length - 1];
  const query = (lastUserMsg?.content || lastUserMsg?.text || '').trim();
  const queryLower = query.toLowerCase();
  
  const matched = matchLocalPreset(query);
  if (matched) {
    return {
      response: `### 🚀 Loaded Offline Template: **${matched.name}**\n\nThe Gemini API encountered a limit, but I detected keywords matching our premium pre-built template! I have successfully loaded it into your active workspace.\n\nYou can now run, test, or inspect this template's clean offline design directly!`,
      modified: true,
      html: matched.html,
      css: matched.css,
      javascript: matched.javascript,
      summary: `- **Offline Swapping**: Automatically swapped workspace content to the "${matched.name}" template.`
    };
  }

  // Helpful Markdown explanation
  const explanation = `### ⚠️ Gemini API Quota Limit Met (Daily free tier exhausted)

The server cannot connect to the Gemini API services right now:
\`\`\`text
${errorMsg}
\`\`\`

#### 🔧 How to restore real-time AI generations:
1. **Configure your own key**: Go to the **Settings** menu at the top-right of your AI Studio environment. Open the secrets panel and add your personal \`GEMINI_API_KEY\` to resume instant unthrottled generation.
2. **Access local offline templates**: Try typing queries with keywords like **'clock'**, **'bounce'**, **'palette'**, **'snake'**, or **'timer'**. I will automatically swap those complete, fully functional, beautifully designed projects straight into your workspace!
3. **Manual Code Editing**: Select any of the **HTML**, **CSS**, or **JS** editor tabs in the workspace main section, edit code manually, and tap **Run Sandbox** (the blue play button) to render the preview instantly!`;

  return {
    response: explanation,
    modified: false,
    html: null,
    css: null,
    javascript: null,
    summary: ""
  };
}

function unescapeJSONString(str: string): string {
  return str
    .replace(/\\n/g, "\n")
    .replace(/\\t/g, "\t")
    .replace(/\\r/g, "\r")
    .replace(/\\b/g, "\b")
    .replace(/\\f/g, "\f")
    .replace(/\\"/g, '"')
    .replace(/\\\//g, "/")
    .replace(/\\u([0-9a-fA-F]{4})/g, (match, grp) => String.fromCharCode(parseInt(grp, 16)))
    .replace(/\\\\/g, "\\");
}

function extractKeysFromMalformedJSON(jsonStr: string): any {
  const result: any = {
    html: "",
    css: "",
    javascript: "",
    appName: "Interactive App Builder Result",
    explanation: "",
    clarificationRequired: false,
    clarificationMessage: "",
    response: "",
    modified: false,
    summary: ""
  };

  const keyList = new Set([
    "html",
    "css",
    "javascript",
    "appName",
    "explanation",
    "clarificationRequired",
    "clarificationMessage",
    "response",
    "modified",
    "summary"
  ]);

  const regex = /(?:^|[,{\r\n])\s*"([a-zA-Z0-9_]+)"\s*:\s*/g;
  const matches: { key: string; matchStart: number; valStartIdx: number }[] = [];

  let match;
  while ((match = regex.exec(jsonStr)) !== null) {
    const key = match[1];
    if (keyList.has(key)) {
      matches.push({
        key,
        matchStart: match.index,
        valStartIdx: match.index + match[0].length
      });
    }
  }

  const finalMatches: typeof matches = [];
  const seenKeys = new Set<string>();
  for (const m of matches) {
    if (!seenKeys.has(m.key)) {
      finalMatches.push(m);
      seenKeys.add(m.key);
    }
  }

  finalMatches.sort((a, b) => a.valStartIdx - b.valStartIdx);

  for (let i = 0; i < finalMatches.length; i++) {
    const current = finalMatches[i];
    const next = finalMatches[i + 1];
    let valPart = "";

    if (next) {
      valPart = jsonStr.substring(current.valStartIdx, next.matchStart).trim();
      if (valPart.endsWith(",")) {
        valPart = valPart.substring(0, valPart.length - 1).trim();
      }
    } else {
      valPart = jsonStr.substring(current.valStartIdx).trim();
      if (valPart.endsWith("}")) {
        valPart = valPart.substring(0, valPart.length - 1).trim();
      }
    }

    if (current.key === "modified" || current.key === "clarificationRequired") {
      result[current.key] = valPart.includes("true");
    } else {
      if (valPart.startsWith('"')) valPart = valPart.substring(1);
      if (valPart.endsWith('"')) valPart = valPart.substring(0, valPart.length - 1);
      result[current.key] = unescapeJSONString(valPart);
    }
  }

  return result;
}

function healJsonStringLiterals(jsonStr: string): string {
  let result = "";
  let insideString = false;
  let escapeActive = false;

  for (let i = 0; i < jsonStr.length; i++) {
    const char = jsonStr[i];

    if (insideString) {
      if (escapeActive) {
        result += char;
        escapeActive = false;
      } else if (char === "\\") {
        result += char;
        escapeActive = true;
      } else if (char === '"') {
        result += char;
        insideString = false;
      } else if (char === "\n") {
        result += "\\n";
      } else if (char === "\r") {
        result += "\\r";
      } else if (char === "\t") {
        result += "\\t";
      } else {
        result += char;
      }
    } else {
      result += char;
      if (char === '"') {
        insideString = true;
      }
    }
  }
  return result;
}

function tryRepairJSON(text: string): any {
  let cleaned = text.trim();
  
  if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```(?:json)?\n?/, "");
    cleaned = cleaned.replace(/```$/, "");
    cleaned = cleaned.trim();
  }

  // Preprocess: Clean unescaped literal control characters/newlines inside double quotes
  try {
    cleaned = healJsonStringLiterals(cleaned);
  } catch (healErr) {
    console.warn("JSON healing preprocessing failed:", healErr);
  }

  // Preprocess: Remove invalid trailing commas within objects or arrays
  try {
    cleaned = cleaned.replace(/,(\s*[}\]])/g, "$1");
  } catch (commaErr) {
    console.warn("Trailing commas cleaning failed:", commaErr);
  }

  try {
    return JSON.parse(cleaned);
  } catch (err) {
    console.warn("[JSON Parse] Standard parsing failed, falling back to key-value extraction...", err);
    try {
      return extractKeysFromMalformedJSON(cleaned);
    } catch (fallbackErr: any) {
      console.error("[JSON Parse] Extraction parsing also failed:", fallbackErr);
      throw new Error(`Invalid JSON syntax returned from Gemini API: ${fallbackErr.message || String(fallbackErr)}`);
    }
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '20mb' }));

  // AI Code generation endpoint
  app.post("/api/generate", async (req, res) => {
    const { prompt, currentHtml, currentCss, currentJs, category, templateName } = req.body || {};
    try {
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
      }

      const client = getGeminiClient();
      const isEditing = !!(currentHtml && currentHtml.trim());

      const systemInstruction = `You are AI App Builder, an elite full-stack autonomous engineer that builds/modifies highly functional, responsive, and visually stunning web applications inside a client-side sandbox.
Your absolute directive is to respond with a clean, standard JSON payload matching the target responseSchema precisely.

JSON schema requirements:
1. "html": Rich HTML content. Do NOT include html, head, body, style, script, or doctype tags. Instead, use modern semantic containers styled with Tailwind CSS (which is fully compiled in the sandbox automatically).
2. "css": Specialized CSS (e.g., custom animations, effects, glassmorphic styles, custom variables). Do not repeat standard classes.
3. "javascript": Robust pure client-side interactivity scripts containing event listeners.
4. "appName": A short, polished, human-friendly application title based on the user's prompt.
5. "explanation": A clear, bullet-pointed engineering summary prioritizing what was modified, what was added, and what was preserved.
6. "clarificationRequired": Boolean. Set to true ONLY if the edit request is extremely vague, completely unclear, majorly contradictory, or directly conflicts with the existing app features.
7. "clarificationMessage": String. Polite detailed question asking the user for clarification if clarificationRequired is true.

CRITICAL INCREMENTAL REVISION MANDATES:
${isEditing ? `--- MODE: INCREMENTAL APP EDITING (EDIT EXISTING APP) ---
You are EDITING an existing application. Follow these rules strictly:
- NEVER recreate the entire app from scratch. Analyze the current HTML, CSS, and JS reference first.
- ONLY identify and update the requested components, layout areas, or stylesheets.
- PRESERVE all existing screens, features, settings, workflows, buttons, menus, layouts, and client-side data.
- Do NOT remove, drop, or overwrite unrelated code/elements. Any unrequested change is a critical failure.
- MAINTAIN 100% backward compatibility so old structures continue to work seamlessly.
- For voice edit commands (which may have minor speech transcript typos or colloquialisms), identify the affected visual/functional area and surgically update only that.
- BEFORE applying changes, show a summary of what will be modified/added, and what was preserved inside the "explanation" field as beautiful Markdown bullet points.
- IF THE EDIT REQUEST IS UNCLEAR, majorly contradictory, or conflicts with active functionality, do NOT replace code. Set "clarificationRequired" to true and ask for clarification inside "clarificationMessage".` : `--- MODE: CREATE NEW APP ---
You are CREATING a brand new application. Follow these rules:
- Generate the complete application normally based on the prompt.
- Design with generous negative space, high contrast, responsive grid layouts, and smooth hover actions.
- Ensure "clarificationRequired" remains false.`}

Visual Identity & Spacing:
- Design with generous negative space, high contrast, balanced font scales, rounded card borders (rounded-2xl or rounded-xl), elegant padding, and smooth state hover actions.
- Functional Indicators: Create real functional code (no mock alerts; instead render in-canvas status indicators or beautiful logs if actions require output). Include interactive DOM values, delete/edit mechanisms for items, and toggle triggers.
- Fully Unique HTML IDs: Every button, form, input, or important interactive box must feature a clear unique id parameter for scripting access.`;

      const contents = `
User Guidance Prompt: ${prompt}
App Category: ${category || 'Utility Tools'}
Involved Base Template: ${templateName || 'Empty'}

[Existing Sandbox Workspace Content for Reference/Refactoring (Available ONLY when editing)]
Current HTML Content:
${currentHtml || ''}

Current CSS Styling Content:
${currentCss || ''}

Current JS Interactivity Content:
${currentJs || ''}
`;

      const response = await generateContentWithRetry(client, {
        contents,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              html: { type: Type.STRING, description: "Active body template markup" },
              css: { type: Type.STRING, description: "Specific typography and customized visual animation stylesheet" },
              javascript: { type: Type.STRING, description: "Sandbox interactivity scripts containing event listeners" },
              appName: { type: Type.STRING, description: "A creative, short name for the generated app" },
              explanation: { type: Type.STRING, description: "A detailed engineering report of what was changed and preserved." },
              clarificationRequired: { type: Type.BOOLEAN, description: "Set to true ONLY if the edit prompt is completely unclear or conflicts with existing functionality." },
              clarificationMessage: { type: Type.STRING, description: "Polite query asking the user to clarify their edit request." }
            },
            required: ["html", "css", "javascript", "appName", "explanation"]
          }
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error("Unable to extract a generation result. Please try again.");
      }

      const generatedData = tryRepairJSON(text);
      res.json(generatedData);
    } catch (error: any) {
      console.error("AI Generation Fallback Triggered:", error);
      try {
        if (currentHtml && currentHtml.trim().length > 0) {
          // If we are editing/refining an existing project, do NOT drop/replace their code with the offline local recovery pad!
          // Throw a descriptive HTTP error so the frontend is safely notified without disrupting any active user modifications.
          const isQuota = (error?.message || String(error)).toLowerCase().includes("quota") || String(error?.status || "").includes("429");
          const errorMsg = isQuota
            ? "Gemini API Quota exhausted (Daily limit of 20 reached). Please configure your personal GEMINI_API_KEY in the Settings > Secrets menu at the top-right to instantly resume coding!"
            : `AI Refinement failed: ${error.message || String(error)}`;
          return res.status(429).json({ error: errorMsg });
        }
        const fallback = handleOfflineGenerateFallback(prompt, error.message || String(error));
        return res.json(fallback);
      } catch (fallbackError) {
        return res.status(500).json({ error: error.message || "Failed to compile AI response." });
      }
    }
  });

  // AI Project-Aware Chat Assistant endpoint
  app.post("/api/chat", async (req, res) => {
    const { messages, currentHtml, currentCss, currentJs, projectName, category } = req.body || {};
    try {
      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: "Messages array is required." });
      }

      const client = getGeminiClient();

      const systemInstruction = `You are AI Chat Assistant for AI App Builder.
You are given the user's latest query, the previous conversation history, and the active sandboxed project files: HTML body, custom CSS styles, and interactive client-side JavaScript.

Your primary capabilities:
1. Explain how the project code works, answer technical programming questions, brainstorm features, or design systems.
2. Directly modify or rewrite the active project's files (HTML, CSS, JS) if the user's latest message requests changes, style updates, additions, layouts, resets, or feature enhancements.

If the user *explicitly or implicitly* requests to change, fix, style, add to, or modify the active project:
- If the edit request is extremely vague, completely unclear, majorly contradictory, or directly conflicts with the existing app features:
  * Do NOT set "modified" to true and do NOT replace the code.
  * Set "modified" to false.
  * In your "response" (using polite conversational Markdown), ask the user for clarification about their intent.
- Otherwise, if proceeding with the edit:
  * Set "modified" to true.
  * NEVER recreate the entire app from scratch. Analyze the active files first.
  * Modify ONLY the requested components or sections. Support targeted incremental updates.
  * PRESERVE all existing screens, features, settings, workflows, buttons, menus, layouts, and client-side data.
  * Do NOT remove or overwrite unrelated code/elements. Keep it 100% stable and backward compatible.
  * For voice-derived instructions, detect what affected area the user meant and surgically update only that.
  * Include a comprehensive Markdown bullet list in the "summary" field detailing exactly what was updated/added, and what was preserved.
  * Return the full rewritten "html", "css", and "javascript" payloads keeping unmodified code fully intact.

If the user's query is only historical, conceptual, theoretical, or a general question *not* asking to modify the code:
- Set "modified" to false.
- Keep "html", "css", and "javascript" as empty strings or null.
- Set "summary" to an empty string.
- Set "response" to a rich, informative, beautifully structured explanation of their query in Markdown.`;

      // Structure conversation history and state
      const latestUserMessage = messages[messages.length - 1];
      const conversationHistory = messages.slice(0, messages.length - 1);
      
      const formattedHistory = conversationHistory.map((m: any) => {
        return `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content || m.text}`;
      }).join('\n\n');

      const contents = `
[Active Sandbox Project State]
Project Title: ${projectName || 'Untitled App'}
Category: ${category || 'Utility Tools'}

Current HTML body:
\`\`\`html
${currentHtml || ''}
\`\`\`

Current CSS stylesheets:
\`\`\`css
${currentCss || ''}
\`\`\`

Current JS interactivity script:
\`\`\`javascript
${currentJs || ''}
\`\`\`

[Conversation Timeline]
${formattedHistory ? `--- Previous Chat History ---\n${formattedHistory}\n----------------------------` : ''}

User's Latest Query (Process this message):
"${latestUserMessage.content || latestUserMessage.text}"
`;

      const response = await generateContentWithRetry(client, {
        contents,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              response: { type: Type.STRING, description: "Main conversational text response in Markdown format." },
              modified: { type: Type.BOOLEAN, description: "Whether the active project code has been modified." },
              html: { type: Type.STRING, description: "Rewritten full HTML if modified is true, otherwise empty/null." },
              css: { type: Type.STRING, description: "Rewritten full CSS if modified is true, otherwise empty/null." },
              javascript: { type: Type.STRING, description: "Rewritten full JS if modified is true, otherwise empty/null." },
              summary: { type: Type.STRING, description: "Markdown list summarizing code additions or replacements if modified is true, otherwise empty/null." }
            },
            required: ["response", "modified"]
          }
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error("Unable to extract chat assistance result. Please try again.");
      }

      const parsedData = tryRepairJSON(text);
      res.json(parsedData);
    } catch (error: any) {
      console.error("AI Chat Fallback Triggered:", error);
      try {
        const fallback = handleOfflineChatFallback(messages, error.message || String(error));
        return res.json(fallback);
      } catch (fallbackError) {
        return res.status(500).json({ error: error.message || "Failed to compile AI Chat response." });
      }
    }
  });

  // Vite integration middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Custom global JSON error handler to prevent default Express HTML crash pages
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("[Express Endpoint Crash Catch]:", err);
    res.status(err.status || err.statusCode || 500).json({
      error: err.message || "An internal server error occurred while processing the request."
    });
  });

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI App Builder Server booted on http://0.0.0.0:${PORT}`);
  });
}

startServer();
